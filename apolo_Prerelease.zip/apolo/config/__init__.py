"""
config/__init__.py — Re-exporta todas as configurações de config.py

PROBLEMA RESOLVIDO:
    Python prioriza pacotes (pastas com __init__.py) sobre módulos (arquivos .py)
    quando ambos têm o mesmo nome. Por isso, 'import config' carregava esta pasta
    vazia em vez de config.py, causando AttributeError em qualquer attr do config.

SOLUÇÃO:
    Este __init__.py importa e re-exporta tudo de config.py usando importlib,
    evitando importação circular e preservando a pasta config/ intacta.
    Qualquer código que faça 'import config' ou 'from config import X' funciona
    normalmente sem nenhuma outra alteração.
"""

import importlib.util
import os as _os

# Caminho absoluto para config.py (um nível acima desta pasta)
_config_py = _os.path.join(_os.path.dirname(_os.path.dirname(__file__)), "config.py")

# Carrega config.py como módulo isolado
_spec = importlib.util.spec_from_file_location("_config_real", _config_py)
_mod  = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)

# Re-exporta todos os atributos públicos para este namespace
# Assim 'import config; config.APOLO_NAME' funciona normalmente
for _attr in dir(_mod):
    if not _attr.startswith("__"):
        globals()[_attr] = getattr(_mod, _attr)

# Limpeza — remove variáveis auxiliares do namespace público
del _os, _config_py, _spec, _mod, _attr
