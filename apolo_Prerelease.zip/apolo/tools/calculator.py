"""tools/calculator.py — Calculadora segura com eval restrito"""

import re
import math
from utils.logger import log

# Funções matemáticas permitidas
FUNCOES_PERMITIDAS = {
    "abs":   abs,
    "round": round,
    "min":   min,
    "max":   max,
    "sum":   sum,
    "pow":   pow,
    "sqrt":  math.sqrt,
    "log":   math.log,
    "log10": math.log10,
    "sin":   math.sin,
    "cos":   math.cos,
    "tan":   math.tan,
    "pi":    math.pi,
    "e":     math.e,
    "ceil":  math.ceil,
    "floor": math.floor,
}

# Conversões de unidades
CONVERSOES = {
    # Temperatura
    ("celsius",    "fahrenheit"): lambda v: v * 9/5 + 32,
    ("fahrenheit", "celsius"):    lambda v: (v - 32) * 5/9,
    ("celsius",    "kelvin"):     lambda v: v + 273.15,
    ("kelvin",     "celsius"):    lambda v: v - 273.15,
    # Distância
    ("km",    "milhas"):  lambda v: v * 0.621371,
    ("milhas","km"):      lambda v: v * 1.60934,
    ("metros","pés"):     lambda v: v * 3.28084,
    ("pés",   "metros"):  lambda v: v * 0.3048,
    # Peso
    ("kg",    "libras"):  lambda v: v * 2.20462,
    ("libras","kg"):      lambda v: v * 0.453592,
    # Moeda (valores aproximados — sem API)
    ("dolar", "real"):    lambda v: v * 5.10,
    ("real",  "dolar"):   lambda v: v / 5.10,
    ("euro",  "real"):    lambda v: v * 5.55,
    ("real",  "euro"):    lambda v: v / 5.55,
}


class Calculator:

    def calcular(self, expressao: str) -> str:
        """Avalia uma expressão matemática de forma segura."""
        # Limpa a expressão
        expr = expressao.strip()
        expr = expr.replace("×", "*").replace("÷", "/").replace("^", "**")
        expr = expr.replace(",", ".")  # vírgula decimal → ponto

        # Verifica caracteres permitidos
        if not re.match(r'^[\d\s\+\-\*\/\(\)\.\%\*\s\w]+$', expr):
            return "Expressão inválida. Use apenas números e operadores (+, -, *, /, **, %)."

        try:
            resultado = eval(expr, {"__builtins__": {}}, FUNCOES_PERMITIDAS)
            # Formata resultado
            if isinstance(resultado, float):
                if resultado == int(resultado):
                    return f"{int(resultado)}"
                return f"{resultado:.6g}"
            return str(resultado)
        except ZeroDivisionError:
            return "Erro: divisão por zero."
        except Exception as e:
            return f"Não consegui calcular '{expressao}': {e}"

    def converter(self, valor: float, de: str, para: str) -> str:
        """Converte entre unidades."""
        de_norm   = de.lower().strip()
        para_norm = para.lower().strip()

        for (origem, destino), fn in CONVERSOES.items():
            if de_norm in origem and para_norm in destino:
                resultado = fn(valor)
                return f"{valor} {de} = {resultado:.4g} {para}"

        return f"Conversão de '{de}' para '{para}' não disponível."
