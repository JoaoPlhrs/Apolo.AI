"""
tools/youtube_music.py — Busca e toca música no YouTube automaticamente

Fluxo:
  1. Busca o vídeo via YouTube Data API v3 (com a API key do .env)
  2. Pega o videoId do primeiro resultado
  3. Abre https://youtube.com/watch?v=ID — toca automaticamente no browser

A chave fica no .env e nunca aparece no código-fonte.

Uso:
    from tools.youtube_music import tocar_musica
    tocar_musica("Bohemian Rhapsody Queen")
    # → Abre o YouTube no vídeo exato, começa a tocar automaticamente
"""

import urllib.request
import urllib.parse
import json
import webbrowser
from utils.env_loader import env
from utils.logger import log

# URL base da YouTube Data API v3
_API_URL = "https://www.googleapis.com/youtube/v3/search"

# Timeout da requisição
_TIMEOUT = 6


def _buscar_video_id(query: str, api_key: str) -> str | None:
    """
    Busca o ID do vídeo mais relevante na YouTube API.

    Args:
        query:   termo de busca (ex: "Bohemian Rhapsody Queen")
        api_key: chave da YouTube Data API v3

    Returns:
        videoId (str) ou None se não encontrar
    """
    params = urllib.parse.urlencode({
        "part":       "snippet",
        "q":          query,
        "type":       "video",
        "maxResults": 1,
        "key":        api_key,
        # Filtra para vídeos de música (melhora relevância)
        "videoCategoryId": "10",
    })
    url = f"{_API_URL}?{params}"

    try:
        req  = urllib.request.Request(
            url,
            headers={"User-Agent": "APOLO/1.0"}
        )
        resp  = urllib.request.urlopen(req, timeout=_TIMEOUT)
        dados = json.loads(resp.read().decode("utf-8"))

        items = dados.get("items", [])
        if not items:
            log.warning(f"[YouTube] Nenhum resultado para: '{query}'")
            return None

        video_id = items[0]["id"].get("videoId")
        titulo   = items[0]["snippet"].get("title", "")
        canal    = items[0]["snippet"].get("channelTitle", "")
        log.info(f"[YouTube] Encontrado: '{titulo}' — {canal} (id: {video_id})")
        return video_id

    except urllib.error.HTTPError as e:
        if e.code == 403:
            log.error("[YouTube] API key inválida ou quota excedida (403)")
        elif e.code == 400:
            log.error("[YouTube] Requisição inválida (400) — verifique a API key")
        else:
            log.error(f"[YouTube] HTTP {e.code}: {e}")
        return None

    except Exception as e:
        log.error(f"[YouTube] Erro na busca: {e}")
        return None


def tocar_musica(musica: str) -> str:
    """
    Abre o YouTube no vídeo exato da música e toca automaticamente.

    Args:
        musica: nome da música (ex: "Bohemian Rhapsody Queen")

    Returns:
        Mensagem de status para o APOLO falar
    """
    musica = musica.strip()
    if not musica:
        webbrowser.open("https://www.youtube.com")
        return "Abrindo YouTube."

    # Carrega a API key: .env tem prioridade, fallback embutido
    _FALLBACK_KEY = "AIzaSyDgTUQaieec7D6_9eZY6tyjn6tDI0PAcNs"
    api_key = env.get("YOUTUBE_API_KEY") or _FALLBACK_KEY

    # Busca o ID do vídeo via API
    video_id = _buscar_video_id(musica, api_key)

    if video_id:
        # URL direta para o vídeo — browser abre e toca automaticamente
        url = f"https://www.youtube.com/watch?v={video_id}"
        webbrowser.open(url)
        return f"Tocando '{musica}' no YouTube. {url}"

    # API falhou — fallback para busca
    log.warning(f"[YouTube] Fallback para busca manual: '{musica}'")
    url = f"https://www.youtube.com/search?q={urllib.parse.quote(musica)}&autoplay=1"
    webbrowser.open(url)
    return f"Abrindo '{musica}' no YouTube. {url}"


def buscar_videos(query: str, max_results: int = 5) -> list[dict]:
    """
    Retorna lista de vídeos para uma busca.
    Útil para mostrar opções ao usuário.

    Returns:
        Lista de {"titulo", "canal", "id", "url"}
    """
    _FALLBACK_KEY = "AIzaSyDgTUQaieec7D6_9eZY6tyjn6tDI0PAcNs"
    api_key = env.get("YOUTUBE_API_KEY") or _FALLBACK_KEY
    if not api_key:
        return []

    params = urllib.parse.urlencode({
        "part":       "snippet",
        "q":          query,
        "type":       "video",
        "maxResults": max_results,
        "key":        api_key,
    })
    url = f"{_API_URL}?{params}"

    try:
        req   = urllib.request.Request(url, headers={"User-Agent": "APOLO/1.0"})
        resp  = urllib.request.urlopen(req, timeout=_TIMEOUT)
        dados = json.loads(resp.read().decode("utf-8"))

        resultados = []
        for item in dados.get("items", []):
            vid_id = item["id"].get("videoId", "")
            if vid_id:
                resultados.append({
                    "titulo": item["snippet"].get("title", ""),
                    "canal":  item["snippet"].get("channelTitle", ""),
                    "id":     vid_id,
                    "url":    f"https://www.youtube.com/watch?v={vid_id}",
                })
        return resultados

    except Exception as e:
        log.warning(f"[YouTube] buscar_videos falhou: {e}")
        return []
