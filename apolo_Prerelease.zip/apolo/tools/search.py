"""
tools/search.py — Pesquisa na internet com resposta real

Fontes em ordem de prioridade:
  1. Wikipedia PT-BR — melhor para fatos, pessoas, lugares, conceitos
  2. DuckDuckGo Instant Answer — respostas rápidas e cálculos
  3. Fallback — abre o Google no navegador se ambos falharem

Sem API key. Sem cadastro. 100% gratuito.

Uso:
    from tools.search import pesquisar
    resultado = pesquisar("capital do Brasil")
    # → "Brasília é a capital federal do Brasil..."
"""

import urllib.request
import urllib.parse
import json
import re
from utils.logger import log


# Timeout das requisições
TIMEOUT = 6

# Headers que simulam browser comum (evita bloqueio de bots)
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept":          "application/json, text/html",
    "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
}


def _get(url: str) -> dict | str | None:
    """Faz requisição GET e retorna JSON (dict) ou texto (str)."""
    try:
        req  = urllib.request.Request(url, headers=HEADERS)
        resp = urllib.request.urlopen(req, timeout=TIMEOUT)
        raw  = resp.read().decode("utf-8", errors="replace")
        ct   = resp.headers.get("Content-Type", "")
        if "json" in ct:
            return json.loads(raw)
        return raw
    except Exception as e:
        log.debug(f"[Search] GET falhou {url[:60]}: {e}")
        return None


def _limpar(texto: str) -> str:
    """Remove HTML e espaços extras de um texto."""
    texto = re.sub(r"<[^>]+>", " ", texto)
    texto = re.sub(r"\s{2,}", " ", texto)
    return texto.strip()


# ── Fonte 1: Wikipedia PT-BR ──────────────────────────────────────────────────

def _buscar_wikipedia(consulta: str) -> str | None:
    """
    Usa a API REST da Wikipedia para buscar um resumo do artigo.
    Funciona bem para: pessoas, lugares, eventos, conceitos, ciência.
    """
    # Primeiro tenta busca direta pelo título
    titulo = consulta.strip().replace(" ", "_")
    url    = f"https://pt.wikipedia.org/api/rest_v1/page/summary/{urllib.parse.quote(titulo)}"
    dados  = _get(url)

    if isinstance(dados, dict) and dados.get("extract"):
        extract = dados["extract"]
        # Limita a 2 frases para resposta concisa
        frases = re.split(r"(?<=[.!?])\s+", extract)
        return " ".join(frases[:2]).strip()

    # Se falhou, tenta a API de busca da Wikipedia para encontrar o artigo certo
    url_busca = (
        "https://pt.wikipedia.org/w/api.php?"
        f"action=query&list=search&srsearch={urllib.parse.quote(consulta)}"
        f"&format=json&srlimit=1&utf8=1"
    )
    dados_busca = _get(url_busca)
    if isinstance(dados_busca, dict):
        resultados = dados_busca.get("query", {}).get("search", [])
        if resultados:
            titulo_certo = resultados[0].get("title", "")
            if titulo_certo and titulo_certo.lower() != consulta.lower():
                # Recursão com o título correto encontrado
                url2  = (f"https://pt.wikipedia.org/api/rest_v1/page/summary/"
                         f"{urllib.parse.quote(titulo_certo.replace(' ', '_'))}")
                dados2 = _get(url2)
                if isinstance(dados2, dict) and dados2.get("extract"):
                    frases = re.split(r"(?<=[.!?])\s+", dados2["extract"])
                    return " ".join(frases[:2]).strip()

    return None


# ── Fonte 2: DuckDuckGo Instant Answer ───────────────────────────────────────

def _buscar_duckduckgo(consulta: str) -> str | None:
    """
    Usa a API pública do DuckDuckGo Instant Answers.
    Funciona bem para: cálculos, conversões, fatos rápidos.
    """
    url   = (f"https://api.duckduckgo.com/?q={urllib.parse.quote(consulta)}"
             f"&format=json&no_redirect=1&no_html=1&skip_disambig=1")
    dados = _get(url)

    if not isinstance(dados, dict):
        return None

    # Prioridade: Answer > AbstractText > Definition > RelatedTopics
    for campo in ("Answer", "AbstractText", "Definition"):
        val = dados.get(campo, "").strip()
        if val and len(val) > 10:
            return _limpar(val)[:400]

    # RelatedTopics
    topics = dados.get("RelatedTopics", [])
    for t in topics:
        if isinstance(t, dict) and t.get("Text"):
            return _limpar(t["Text"])[:300]

    return None


# ── API pública ───────────────────────────────────────────────────────────────

def pesquisar(consulta: str, abrir_browser: bool = True) -> str:
    """
    Pesquisa uma consulta e retorna uma resposta em texto.

    Fluxo:
      1. Tenta Wikipedia PT-BR
      2. Tenta DuckDuckGo Instant Answer
      3. Se ambos falharem e abrir_browser=True, abre o Google

    Args:
        consulta:      texto para pesquisar
        abrir_browser: se True, abre o Google como fallback

    Returns:
        String com a resposta encontrada, ou mensagem de fallback.
    """
    consulta = consulta.strip()
    if not consulta:
        return "Não recebi nenhuma consulta para pesquisar."

    log.info(f"[Search] Pesquisando: '{consulta}'")

    # 1. Wikipedia
    resp = _buscar_wikipedia(consulta)
    if resp:
        log.info(f"[Search] Resultado da Wikipedia: {resp[:60]}...")
        return resp

    # 2. DuckDuckGo
    resp = _buscar_duckduckgo(consulta)
    if resp:
        log.info(f"[Search] Resultado do DuckDuckGo: {resp[:60]}...")
        return resp

    # 3. Fallback: abre o Google
    log.info(f"[Search] Sem resultado — abrindo Google")
    if abrir_browser:
        import webbrowser
        url = f"https://www.google.com/search?q={urllib.parse.quote(consulta)}"
        webbrowser.open(url)
        return (f"Não encontrei uma resposta direta sobre '{consulta}'. "
                f"Abri o Google para você ver os resultados.")

    return f"Não encontrei informações sobre '{consulta}'."


def pesquisar_rapido(consulta: str) -> str:
    """
    Versão sem fallback de browser — só retorna texto.
    Útil quando o APOLO quer injetar o resultado no LLM.
    """
    return pesquisar(consulta, abrir_browser=False)
