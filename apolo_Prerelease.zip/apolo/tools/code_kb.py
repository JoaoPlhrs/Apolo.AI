"""
tools/code_kb.py — Banco de conhecimento em programação do APOLO

Cobre Python, HTML, CSS e JavaScript com:
  - Boas práticas e exemplos reais
  - O que NÃO fazer (antipatterns)
  - Lógica por trás de cada conceito
  - Como fazer o código corretamente

É injetado automaticamente no system prompt quando o usuário
faz perguntas sobre código/programação.
"""

CODE_KB = """
=== BANCO DE CONHECIMENTO: PROGRAMAÇÃO ===

Você é EXPERT em Python, HTML, CSS e JavaScript. Use os exemplos e princípios abaixo.

───────────────────────────────────────────────
PYTHON
───────────────────────────────────────────────

[LÓGICA] Python é interpretado, tipagem dinâmica, tudo é objeto. Prioriza legibilidade (PEP8).
O GIL impede paralelismo real em threads — use multiprocessing para CPU-bound, asyncio para I/O-bound.

[BOA PRÁTICA] List comprehension em vez de loop com append:
  # ✅ Correto
  quadrados = [x**2 for x in range(10) if x % 2 == 0]

  # ❌ Evitar
  quadrados = []
  for x in range(10):
      if x % 2 == 0:
          quadrados.append(x**2)

[BOA PRÁTICA] Context managers para recursos:
  # ✅ Correto — fecha automaticamente
  with open("arquivo.txt", encoding="utf-8") as f:
      conteudo = f.read()

  # ❌ Errado — risco de memory leak
  f = open("arquivo.txt")
  conteudo = f.read()
  f.close()

[BOA PRÁTICA] Dataclasses para modelos de dados:
  from dataclasses import dataclass, field
  
  @dataclass
  class Usuario:
      nome: str
      idade: int
      tags: list = field(default_factory=list)  # ← mutable default SEMPRE assim
  
  # ❌ NUNCA: tags: list = []  (compartilha entre instâncias!)

[BOA PRÁTICA] F-strings (mais rápidas e legíveis):
  nome = "Carlos"
  # ✅ f-string
  msg = f"Olá, {nome}! Você tem {len(nome)} letras no nome."
  # ❌ .format() é mais verboso
  msg = "Olá, {}!".format(nome)

[BOA PRÁTICA] Exceções específicas, nunca bare except:
  # ✅ Captura só o que espera
  try:
      valor = int(input("Número: "))
  except ValueError as e:
      print(f"Entrada inválida: {e}")

  # ❌ Engole qualquer erro, incluindo bugs reais
  try:
      valor = int(input())
  except:
      pass

[BOA PRÁTICA] Generators para grandes volumes de dados (não carrega tudo na RAM):
  def ler_linhas_grandes(path):
      with open(path) as f:
          for linha in f:            # ← generator, não readlines()
              yield linha.strip()

[BOA PRÁTICA] Type hints para clareza e IDE support:
  def calcular_imc(peso: float, altura: float) -> float:
      return peso / (altura ** 2)

[BOA PRÁTICA] Dicionários com .get() evitam KeyError:
  config = {"debug": True}
  modo = config.get("modo", "produção")  # fallback seguro

[ANTIPATTERN] Variável mutável como argumento default:
  # ❌ Bug clássico Python
  def adicionar(item, lista=[]):
      lista.append(item)
      return lista
  
  # ✅ Correto
  def adicionar(item, lista=None):
      if lista is None:
          lista = []
      lista.append(item)
      return lista

[ANTIPATTERN] Comparar com True/False/None explicitamente:
  # ❌
  if ativo == True:
  if valor == None:
  
  # ✅
  if ativo:
  if valor is None:

[ASYNC] Use asyncio para operações de I/O concorrentes:
  import asyncio
  import aiohttp
  
  async def buscar(url: str) -> str:
      async with aiohttp.ClientSession() as session:
          async with session.get(url) as resp:
              return await resp.text()
  
  async def main():
      urls = ["https://api1.com", "https://api2.com"]
      resultados = await asyncio.gather(*[buscar(u) for u in urls])

───────────────────────────────────────────────
HTML
───────────────────────────────────────────────

[LÓGICA] HTML é estrutura semântica, não visual. O navegador cria o DOM a partir dele.
Use tags pelo significado, não pela aparência.

[BOA PRÁTICA] Semântica correta:
  <!-- ✅ Semântico -->
  <header><nav><ul><li><a href="/sobre">Sobre</a></li></ul></nav></header>
  <main><article><h1>Título</h1><p>Conteúdo</p></article></main>
  <footer><p>&copy; 2025</p></footer>

  <!-- ❌ Sopa de divs -->
  <div class="header"><div class="nav">...</div></div>

[BOA PRÁTICA] Sempre use atributo alt em imagens:
  <!-- ✅ Acessibilidade e SEO -->
  <img src="logo.png" alt="Logo da empresa XYZ" width="200" height="60">
  <!-- Decorativa: alt vazio (não omitir) -->
  <img src="divider.png" alt="">

[BOA PRÁTICA] Labels associados a inputs (acessibilidade):
  <!-- ✅ for + id -->
  <label for="email">E-mail</label>
  <input type="email" id="email" name="email" required autocomplete="email">

  <!-- ❌ Sem associação -->
  E-mail: <input type="text">

[BOA PRÁTICA] Meta tags essenciais:
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Descrição para SEO, 150-160 chars">
  <title>Título da Página | Site</title>

[BOA PRÁTICA] Carregamento de scripts:
  <!-- ✅ defer: não bloqueia parse do HTML, executa em ordem -->
  <script src="app.js" defer></script>
  <!-- async: não bloqueia, executa quando baixar (sem garantia de ordem) -->
  <script src="analytics.js" async></script>
  <!-- ❌ Evitar no <head> sem defer/async — bloqueia renderização -->

[ANTIPATTERN] Inline styles (dificulta manutenção):
  <!-- ❌ -->
  <p style="color: red; font-size: 16px; margin: 10px">Texto</p>
  <!-- ✅ -->
  <p class="alerta">Texto</p>

───────────────────────────────────────────────
CSS
───────────────────────────────────────────────

[LÓGICA] CSS aplica estilos em cascata. Especificidade define qual regra vence:
inline > #id > .classe > tag. Use custom properties (variáveis) para manutenção.

[BOA PRÁTICA] Custom Properties (variáveis CSS):
  :root {
    --cor-primaria: #1a6cf5;
    --cor-texto: #e8eaf2;
    --espaco-base: 8px;
    --radius: 8px;
  }
  
  .botao {
    background: var(--cor-primaria);
    padding: calc(var(--espaco-base) * 1.5) calc(var(--espaco-base) * 3);
    border-radius: var(--radius);
  }

[BOA PRÁTICA] Flexbox para layout 1D:
  .nav {
    display: flex;
    align-items: center;      /* eixo cruzado */
    justify-content: space-between; /* eixo principal */
    gap: 16px;
  }

[BOA PRÁTICA] Grid para layout 2D:
  .dashboard {
    display: grid;
    grid-template-columns: 260px 1fr 220px; /* sidebar | main | aside */
    grid-template-rows: 52px 1fr;
    height: 100vh;
  }

[BOA PRÁTICA] Mobile-first com media queries:
  /* Base: mobile */
  .container { padding: 16px; }
  
  /* Tablet+ */
  @media (min-width: 768px) {
    .container { padding: 24px; max-width: 1200px; margin: 0 auto; }
  }

[BOA PRÁTICA] Transições suaves:
  .botao {
    background: #1a6cf5;
    transition: background 0.2s ease, transform 0.15s ease;
  }
  .botao:hover { background: #0d4fc4; transform: translateY(-1px); }
  .botao:active { transform: translateY(0); }

[BOA PRÁTICA] box-sizing border-box globalmente:
  *, *::before, *::after { box-sizing: border-box; }

[ANTIPATTERN] !important em excesso:
  /* ❌ Sinal de especificidade mal planejada */
  .texto { color: red !important; }
  /* ✅ Resolva aumentando especificidade ou reestruturando */

[ANTIPATTERN] Posicionamento absoluto para layout geral:
  /* ❌ Quebra em telas diferentes */
  .menu { position: absolute; top: 60px; left: 200px; }
  /* ✅ Use flex/grid para posicionar elementos de layout */

───────────────────────────────────────────────
JAVASCRIPT
───────────────────────────────────────────────

[LÓGICA] JS é single-threaded com event loop. Operações assíncronas (fetch, setTimeout)
vão para a Web API, e os callbacks voltam via callback queue quando a call stack esvazia.

[BOA PRÁTICA] Sempre use const/let, nunca var:
  const PI = 3.14;          // não reatribuível
  let contador = 0;          // reatribuível, escopo de bloco
  // var tem escopo de função e hoisting — evitar totalmente

[BOA PRÁTICA] Async/Await em vez de .then().catch():
  // ✅ Mais legível
  async function buscarUsuario(id) {
    try {
      const res = await fetch(`/api/usuarios/${id}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      console.error("Erro ao buscar usuário:", err);
      return null;
    }
  }

  // ❌ Callback hell / promise chain difícil de manter
  fetch("/api/usuarios/1")
    .then(r => r.json())
    .then(data => { ... })
    .catch(e => { ... });

[BOA PRÁTICA] Destructuring e spread:
  const { nome, idade, cidade = "SP" } = usuario;  // com default
  const novoUsuario = { ...usuario, cidade: "RJ" }; // spread (não muta original)
  const [primeiro, ...resto] = lista;

[BOA PRÁTICA] Optional chaining e nullish coalescing:
  const nome = usuario?.perfil?.nome ?? "Anônimo";
  // Sem opcional: const nome = usuario && usuario.perfil && usuario.perfil.nome || "Anônimo"

[BOA PRÁTICA] Array methods funcionais:
  const adultos = usuarios
    .filter(u => u.idade >= 18)
    .map(u => ({ ...u, categoria: "adulto" }))
    .sort((a, b) => a.nome.localeCompare(b.nome));

[BOA PRÁTICA] Event delegation (um listener para muitos elementos):
  // ✅ Um listener na lista, não um por item
  document.querySelector("#lista").addEventListener("click", (e) => {
    const item = e.target.closest("[data-id]");
    if (item) removerItem(item.dataset.id);
  });

[BOA PRÁTICA] Debounce para inputs de busca:
  function debounce(fn, ms) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), ms);
    };
  }
  inputBusca.addEventListener("input", debounce(buscar, 300));

[BOA PRÁTICA] localStorage com try/catch (pode falhar em modo privado):
  function salvarLocal(chave, valor) {
    try {
      localStorage.setItem(chave, JSON.stringify(valor));
    } catch { /* modo privado ou storage cheio */ }
  }
  function lerLocal(chave, padrao = null) {
    try {
      const v = localStorage.getItem(chave);
      return v !== null ? JSON.parse(v) : padrao;
    } catch { return padrao; }
  }

[ANTIPATTERN] Modificar DOM em loop (reflow/repaint por item):
  // ❌ Lento — N reflows
  itens.forEach(item => {
    document.body.innerHTML += `<div>${item}</div>`;
  });
  
  // ✅ Um só reflow com fragment
  const frag = document.createDocumentFragment();
  itens.forEach(item => {
    const div = document.createElement("div");
    div.textContent = item;
    frag.appendChild(div);
  });
  document.body.appendChild(frag);

[ANTIPATTERN] == em vez de ===:
  // ❌ Coerção de tipo — surpreendente
  0 == "0"   // true
  null == undefined // true
  // ✅ Sempre ===
  0 === "0"  // false

[ANTIPATTERN] Não tratar erros em promises:
  // ❌ Promise rejeitada silenciosa
  fetch("/api/dados").then(r => r.json()).then(usar);
  // ✅
  fetch("/api/dados").then(r => r.json()).then(usar).catch(console.error);

=== FIM DO BANCO DE CONHECIMENTO ===
"""

# Palavras-chave que ativam a injeção do KB no system prompt
KEYWORDS = [
    "python", "javascript", "js", "html", "css",
    "código", "codigo", "função", "funcao", "classe", "class",
    "array", "lista", "dict", "dicionário", "dicionario",
    "async", "await", "promise", "fetch", "api",
    "flex", "grid", "layout", "estilo", "selector",
    "variável", "variavel", "loop", "for", "while",
    "programa", "programar", "programação", "programacao",
    "bug", "erro", "exception", "debug", "refactor",
    "frontend", "backend", "web", "site",
    "como faço", "como fazer", "como criar", "como usar",
    "melhor forma", "boa prática", "antipattern",
]


def relevante(texto: str) -> bool:
    """Retorna True se a pergunta é sobre programação."""
    t = texto.lower()
    return any(k in t for k in KEYWORDS)
