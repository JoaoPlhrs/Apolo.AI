"""
tools/document_analyzer.py — Análise de documentos e extração de dados

Capacidades:
  - Resumir documentos longos (PDF, TXT, texto colado)
  - Extrair campos específicos: protocolo, data, valor, nome, CPF
  - Ler arquivo do disco e analisar com LLM
  - Responder perguntas sobre o conteúdo de um documento

Uso:
    from tools.document_analyzer import DocumentAnalyzer
    da = DocumentAnalyzer(llm_engine)

    # Resumir texto
    da.resumir("texto longo aqui...")

    # Extrair dados de um arquivo
    da.analisar_arquivo("/caminho/para/recibo.pdf")

    # Extrair campo específico
    da.extrair_campo("numero de protocolo", "texto do documento...")
"""

import os
import re
from utils.logger import log

# Campos conhecidos para extração automática
CAMPOS_CONHECIDOS = {
    "protocolo":    [r"protocolo[:\s]+([A-Z0-9\-/]+)", r"n[úu]mero[:\s]+([A-Z0-9\-/]+)"],
    "data":         [r"(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})", r"data[:\s]+(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})"],
    "valor":        [r"R\$\s*([\d.,]+)", r"valor[:\s]+R?\$?\s*([\d.,]+)"],
    "cpf":          [r"CPF[:\s]*([\d.\-]+)", r"(\d{3}\.\d{3}\.\d{3}\-\d{2})"],
    "cnpj":         [r"CNPJ[:\s]*([\d.\/\-]+)", r"(\d{2}\.\d{3}\.\d{3}\/\d{4}\-\d{2})"],
    "nome":         [r"nome[:\s]+([A-Za-záàâãéèêíïóôõöúûüçÁÀÂÃÉÈÊÍÏÓÔÕÖÚÛÜÇ\s]+)(?:\n|,|\.|\|)"],
    "email":        [r"([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})"],
    "telefone":     [r"(?:tel|fone|phone)[:\s]*([\d\s()\-+]+)", r"(\(?\d{2}\)?\s?\d{4,5}[\-\s]\d{4})"],
    "cep":          [r"CEP[:\s]*(\d{5}[\-]?\d{3})"],
    "vencimento":   [r"vencimento[:\s]+(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})"],
    "numero_nf":    [r"nota\s+fiscal[:\s]+n[°o]?\s*(\d+)", r"NF[:\s]+(\d+)"],
}


class DocumentAnalyzer:
    """Analisa documentos e extrai informações usando LLM + regex."""

    # Limite de caracteres para enviar ao LLM de uma vez
    MAX_CHARS_LLM = 3000

    def __init__(self, llm_engine=None):
        self.llm = llm_engine

    def set_llm(self, llm_engine):
        """Injeta o LLMEngine após inicialização."""
        self.llm = llm_engine

    # ── Leitura de arquivo ────────────────────────────────────────────────────

    def ler_arquivo(self, caminho: str) -> str | None:
        """
        Lê o conteúdo de um arquivo de texto ou PDF.

        Suporta: .txt, .md, .py, .json, .csv, .pdf (requer PyPDF2 ou pdfplumber)

        Returns:
            Texto extraído ou None se falhar
        """
        caminho = os.path.expanduser(caminho.strip())
        if not os.path.exists(caminho):
            log.warning(f"[Doc] Arquivo não encontrado: {caminho}")
            return None

        ext = os.path.splitext(caminho)[1].lower()

        # Arquivos de texto
        if ext in (".txt", ".md", ".py", ".json", ".csv", ".html", ".xml", ".log"):
            try:
                with open(caminho, encoding="utf-8", errors="replace") as f:
                    return f.read()
            except Exception as e:
                log.error(f"[Doc] Erro ao ler {caminho}: {e}")
                return None

        # PDF
        if ext == ".pdf":
            return self._ler_pdf(caminho)

        # Fallback: tenta como texto
        try:
            with open(caminho, encoding="utf-8", errors="replace") as f:
                return f.read()
        except Exception:
            return None

    def _ler_pdf(self, caminho: str) -> str | None:
        """Extrai texto de PDF. Tenta pdfplumber, depois PyPDF2."""
        # Tenta pdfplumber (melhor qualidade)
        try:
            import pdfplumber
            with pdfplumber.open(caminho) as pdf:
                paginas = []
                for pg in pdf.pages:
                    txt = pg.extract_text()
                    if txt:
                        paginas.append(txt)
            texto = "\n\n".join(paginas)
            log.info(f"[Doc] PDF lido com pdfplumber: {len(texto)} chars")
            return texto
        except ImportError:
            pass
        except Exception as e:
            log.warning(f"[Doc] pdfplumber falhou: {e}")

        # Tenta PyPDF2
        try:
            import PyPDF2
            with open(caminho, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                paginas = [pg.extract_text() or "" for pg in reader.pages]
            texto = "\n\n".join(p for p in paginas if p.strip())
            log.info(f"[Doc] PDF lido com PyPDF2: {len(texto)} chars")
            return texto
        except ImportError:
            log.warning("[Doc] Instale pdfplumber ou PyPDF2: pip install pdfplumber")
        except Exception as e:
            log.warning(f"[Doc] PyPDF2 falhou: {e}")

        return None

    # ── Análise com LLM ───────────────────────────────────────────────────────

    def resumir(self, texto: str, estilo: str = "conciso") -> str:
        """
        Resume um texto usando o LLM.

        Args:
            texto:  conteúdo a resumir
            estilo: "conciso" (3-5 frases) | "detalhado" | "pontos" (bullet points)

        Returns:
            Resumo em português
        """
        if not texto or not texto.strip():
            return "Nenhum texto fornecido para resumir."

        if not self.llm:
            # Sem LLM: resumo por truncagem simples
            return self._resumo_simples(texto)

        instrucoes = {
            "conciso":   "Resuma em 3 a 5 frases curtas e objetivas.",
            "detalhado": "Faça um resumo detalhado destacando todos os pontos importantes.",
            "pontos":    "Liste os pontos principais em formato de tópicos numerados.",
        }
        instrucao = instrucoes.get(estilo, instrucoes["conciso"])

        # Trunca para não exceder contexto
        texto_trunc = texto[:self.MAX_CHARS_LLM]
        if len(texto) > self.MAX_CHARS_LLM:
            texto_trunc += f"\n\n[... texto truncado, {len(texto)-self.MAX_CHARS_LLM} caracteres omitidos]"

        prompt = (
            f"{instrucao} Responda em português.\n\n"
            f"DOCUMENTO:\n{texto_trunc}"
        )

        try:
            return self.llm.gerar(prompt)
        except Exception as e:
            log.error(f"[Doc] Erro no LLM: {e}")
            return self._resumo_simples(texto)

    def analisar_arquivo(self, caminho: str, pergunta: str = "") -> str:
        """
        Lê um arquivo e o analisa com o LLM.

        Args:
            caminho:  caminho do arquivo
            pergunta: pergunta específica sobre o documento (opcional)

        Returns:
            Análise/resposta do LLM
        """
        texto = self.ler_arquivo(caminho)
        if not texto:
            return f"Não consegui ler o arquivo: {caminho}"

        nome = os.path.basename(caminho)
        log.info(f"[Doc] Analisando: {nome} ({len(texto)} chars)")

        if pergunta:
            return self.responder_sobre(texto, pergunta, nome)
        else:
            return self.resumir(texto)

    def responder_sobre(self, texto: str, pergunta: str,
                        nome_doc: str = "documento") -> str:
        """
        Responde uma pergunta sobre um documento.

        Args:
            texto:    conteúdo do documento
            pergunta: pergunta do usuário
            nome_doc: nome do documento para contexto

        Returns:
            Resposta baseada no documento
        """
        if not self.llm:
            # Sem LLM: tenta extração por regex
            campo = self._detectar_campo(pergunta)
            if campo:
                resultado = self.extrair_campo(campo, texto)
                return resultado or f"Não encontrei '{campo}' no documento."
            return "LLM não disponível para responder perguntas sobre documentos."

        texto_trunc = texto[:self.MAX_CHARS_LLM]
        prompt = (
            f"Com base no documento '{nome_doc}', responda em português de forma direta.\n\n"
            f"PERGUNTA: {pergunta}\n\n"
            f"DOCUMENTO:\n{texto_trunc}"
        )
        try:
            return self.llm.gerar(prompt)
        except Exception as e:
            log.error(f"[Doc] Erro no LLM: {e}")
            return "Erro ao processar o documento."

    # ── Extração por regex ────────────────────────────────────────────────────

    def extrair_campo(self, campo: str, texto: str) -> str | None:
        """
        Extrai um campo específico do texto usando regex.

        Args:
            campo: nome do campo ("protocolo", "data", "valor", "cpf", etc.)
            texto: texto do documento

        Returns:
            Valor extraído ou None
        """
        campo_norm = campo.lower().strip()

        # Busca nas regras conhecidas
        for chave, padroes in CAMPOS_CONHECIDOS.items():
            if chave in campo_norm or campo_norm in chave:
                for pat in padroes:
                    match = re.search(pat, texto, re.IGNORECASE)
                    if match:
                        valor = match.group(1).strip()
                        log.info(f"[Doc] Campo '{chave}' encontrado: {valor}")
                        return valor

        # Busca genérica: "campo: valor"
        pat_generico = rf"{re.escape(campo_norm)}[:\s]+([^\n\r,;|]+)"
        match = re.search(pat_generico, texto, re.IGNORECASE)
        if match:
            return match.group(1).strip()

        return None

    def extrair_todos_campos(self, texto: str) -> dict[str, str]:
        """
        Extrai todos os campos conhecidos de um texto automaticamente.

        Returns:
            Dict {campo: valor} com os campos encontrados
        """
        resultado = {}
        for campo, padroes in CAMPOS_CONHECIDOS.items():
            for pat in padroes:
                match = re.search(pat, texto, re.IGNORECASE)
                if match:
                    resultado[campo] = match.group(1).strip()
                    break
        return resultado

    def extrair_e_formatar(self, texto: str) -> str:
        """
        Extrai todos os campos e retorna uma string formatada.
        Útil para mostrar ao usuário o que foi encontrado no documento.
        """
        campos = self.extrair_todos_campos(texto)
        if not campos:
            return "Nenhum campo estruturado encontrado no documento."

        linhas = ["Dados encontrados no documento:"]
        nomes_pt = {
            "protocolo": "Protocolo", "data": "Data", "valor": "Valor",
            "cpf": "CPF", "cnpj": "CNPJ", "nome": "Nome",
            "email": "E-mail", "telefone": "Telefone", "cep": "CEP",
            "vencimento": "Vencimento", "numero_nf": "Nota Fiscal",
        }
        for campo, valor in campos.items():
            nome_exib = nomes_pt.get(campo, campo.capitalize())
            linhas.append(f"  {nome_exib}: {valor}")
        return "\n".join(linhas)

    # ── Utilitários ───────────────────────────────────────────────────────────

    def _resumo_simples(self, texto: str, max_chars: int = 300) -> str:
        """Resumo por truncagem quando LLM não está disponível."""
        limpo = re.sub(r"\s{2,}", " ", texto.strip())
        if len(limpo) <= max_chars:
            return limpo
        # Corta na última frase completa
        trunc = limpo[:max_chars]
        ult_ponto = max(trunc.rfind("."), trunc.rfind("!"), trunc.rfind("?"))
        if ult_ponto > 100:
            trunc = trunc[:ult_ponto + 1]
        return trunc + " [resumo truncado]"

    def _detectar_campo(self, pergunta: str) -> str | None:
        """Detecta qual campo o usuário quer extrair da pergunta."""
        p = pergunta.lower()
        mapeamento = {
            "protocolo": ["protocolo", "número", "código", "id"],
            "data":       ["data", "quando", "dia", "mês"],
            "valor":      ["valor", "preço", "quanto", "total", "r$"],
            "cpf":        ["cpf", "cadastro de pessoa"],
            "cnpj":       ["cnpj", "cadastro nacional"],
            "nome":       ["nome", "pessoa", "cliente", "paciente"],
            "email":      ["email", "e-mail", "correio"],
            "telefone":   ["telefone", "celular", "fone", "contato"],
            "vencimento": ["vencimento", "vence", "validade"],
        }
        for campo, palavras in mapeamento.items():
            if any(w in p for w in palavras):
                return campo
        return None
