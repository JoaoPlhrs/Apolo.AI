"""tools/weather.py — Clima via Open-Meteo (gratuito, sem API key)"""

import requests
from utils.logger import log

# Cidades brasileiras mais comuns
CIDADES: dict[str, tuple[float, float]] = {
    "são paulo":        (-23.5505, -46.6333),
    "sao paulo":        (-23.5505, -46.6333),
    "rio de janeiro":   (-22.9068, -43.1729),
    "belo horizonte":   (-19.9167, -43.9345),
    "brasília":         (-15.7801, -47.9292),
    "brasilia":         (-15.7801, -47.9292),
    "curitiba":         (-25.4284, -49.2733),
    "porto alegre":     (-30.0346, -51.2177),
    "salvador":         (-12.9714, -38.5014),
    "fortaleza":        (-3.7172,  -38.5434),
    "manaus":           (-3.1190,  -60.0217),
    "recife":           (-8.0476,  -34.8770),
    "belém":            (-1.4558,  -48.5044),
    "belem":            (-1.4558,  -48.5044),
    "goiânia":          (-16.6864, -49.2643),
    "goiania":          (-16.6864, -49.2643),
    "florianópolis":    (-27.5954, -48.5480),
    "florianopolis":    (-27.5954, -48.5480),
    "campinas":         (-22.9056, -47.0608),
    "vitória":          (-20.3155, -40.3128),
    "vitoria":          (-20.3155, -40.3128),
}

CODIGOS_CLIMA = {
    0:  "céu limpo ☀️",
    1:  "predominantemente limpo 🌤️",
    2:  "parcialmente nublado ⛅",
    3:  "nublado ☁️",
    45: "com neblina 🌫️",
    48: "com geada 🌫️",
    51: "garoa leve 🌦️",
    53: "garoa moderada 🌦️",
    55: "garoa intensa 🌧️",
    61: "chuva leve 🌧️",
    63: "chuva moderada 🌧️",
    65: "chuva forte 🌧️",
    71: "neve leve 🌨️",
    80: "pancadas de chuva 🌦️",
    95: "com trovoadas ⛈️",
    99: "com granizo ⛈️",
}


class WeatherTool:
    BASE_URL = "https://api.open-meteo.com/v1/forecast"

    def consultar(self, cidade: str = None) -> str:
        cidade_normalizada = (cidade or "são paulo").lower().strip()
        coords = CIDADES.get(cidade_normalizada)

        if not coords:
            # Tenta correspondência parcial
            for chave, coord in CIDADES.items():
                if cidade_normalizada in chave or chave in cidade_normalizada:
                    coords = coord
                    break

        if not coords:
            return f"Não tenho dados de clima para '{cidade}'. Cidades disponíveis: São Paulo, Rio de Janeiro, Belo Horizonte, Brasília..."

        lat, lon = coords
        try:
            resp = requests.get(self.BASE_URL, params={
                "latitude":           lat,
                "longitude":          lon,
                "current":            "temperature_2m,relative_humidity_2m,weathercode,windspeed_10m",
                "daily":              "temperature_2m_max,temperature_2m_min,precipitation_sum",
                "timezone":           "America/Sao_Paulo",
                "forecast_days":      1,
            }, timeout=5)
            resp.raise_for_status()
            dados = resp.json()

            atual  = dados["current"]
            daily  = dados["daily"]
            temp   = atual["temperature_2m"]
            umidade= atual["relative_humidity_2m"]
            codigo = atual["weathercode"]
            vento  = atual["windspeed_10m"]
            max_t  = daily["temperature_2m_max"][0]
            min_t  = daily["temperature_2m_min"][0]
            chuva  = daily["precipitation_sum"][0]

            descricao = CODIGOS_CLIMA.get(codigo, "condição desconhecida")
            nome_cidade = cidade.title() if cidade else "São Paulo"

            return (
                f"{nome_cidade} está {descricao}. "
                f"Temperatura atual: {temp:.0f}°C (máx {max_t:.0f}°C / mín {min_t:.0f}°C). "
                f"Umidade: {umidade}%. Vento: {vento:.0f} km/h. "
                f"Chuva esperada hoje: {chuva:.1f} mm."
            )

        except requests.Timeout:
            return "Tempo esgotado ao consultar o clima. Verifique sua conexão."
        except Exception as e:
            log.warning(f"Erro ao consultar clima: {e}")
            return "Não consegui obter informações de clima no momento."
