"""
╔══════════════════════════════════════════════════════════╗
║  APOLO v2.5 — Assistente Inteligente Local               ║
║  Gemma 4 · Wake Word Local · Offline-First               ║
╚══════════════════════════════════════════════════════════╝

Uso:
    python main.py              → modo texto (sem microfone)
    python main.py --voz        → modo voz (STT + TTS)
    python main.py --sem-tts    → modo texto, sem síntese de voz
    python main.py --debug      → logs detalhados
"""

import sys
import os
import signal

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rich.console import Console
from rich.panel   import Panel
from rich.text    import Text

console = Console()


# ── Banner ────────────────────────────────────────────────────────────────────

def banner():
    from core.version import get_version
    console.print(Panel(
        Text.from_markup(
            "[bold cyan]APOLO[/] — Algoritmo de Processamento Operado por Lógica Operacional\n"
            f"[dim]{get_version(full=True)} · Gemma 4 · Offline-First[/]"
        ),
        border_style="cyan",
        padding=(0, 2),
    ))
    console.print(
        "[dim]Comandos: 'sair' encerra | 'limpar' reseta | --voz ativa microfone[/]\n"
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    banner()

    usar_voz  = "--voz"    in sys.argv or "-v" in sys.argv
    usar_tts  = "--sem-tts" not in sys.argv
    debug     = "--debug"  in sys.argv

    if debug:
        import logging
        logging.getLogger("apolo").setLevel(logging.DEBUG)

    # ── Dispatcher (núcleo) ───────────────────────────────────────────────────
    console.print("[dim]Carregando APOLO...[/]")
    try:
        from core.dispatcher import Dispatcher
        dp = Dispatcher()
    except ConnectionError as e:
        console.print(f"[bold red]ERRO:[/] {e}")
        console.print("[yellow]→[/] Inicie o Ollama:  [cyan]ollama serve[/]")
        console.print("[yellow]→[/] Baixe o modelo:   [cyan]ollama pull gemma4:e4b[/]")
        sys.exit(1)

    # ── TTS ───────────────────────────────────────────────────────────────────
    tts = None
    if usar_tts:
        try:
            from voice.tts import TTSEngine
            tts = TTSEngine()
            console.print(f"[green]✓[/] TTS: {tts._engine_name}")
        except Exception as e:
            console.print(f"[yellow]⚠ TTS desativado:[/] {e}")

    # ── STT ───────────────────────────────────────────────────────────────────
    stt = None
    if usar_voz:
        try:
            from voice.stt import STTEngine
            stt = STTEngine()
            console.print("[green]✓[/] STT: Whisper pronto")
        except Exception as e:
            console.print(f"[yellow]⚠ STT desativado:[/] {e}")
            usar_voz = False

    # ── Wake Word (background) ────────────────────────────────────────────────
    wake = None
    try:
        from voice.wake_word import WakeWordDetector
        from voice.feedback  import Feedback

        def ao_ativar():
            """
            Chamado quando a wake word é detectada.
            Dá feedback e imediatamente escuta o restante da frase.
            """
            Feedback.on_activate()

            # Captura o restante da fala na mesma frase (ex: "Apolo abre o YouTube")
            from voice.listener import listen_after_wakeword
            texto = listen_after_wakeword(timeout=5, phrase_limit=5)

            if texto:
                # Fala foi capturada — processa como comando normal
                Feedback.on_processing()
                resposta = dp.processar(texto)
                _responder(resposta, tts, console)
            elif stt:
                # listen_after_wakeword falhou — tenta com STT completo como fallback
                _ciclo_voz(dp, tts, stt, console)

        wake = WakeWordDetector(callback=ao_ativar)
        wake.start()
        console.print(
            f"[green]✓[/] Wake word '[bold]Apolo[/]' | "
            f"backend: {wake.backend}"
        )
    except Exception as e:
        console.print(f"[yellow]⚠ Wake word:[/] {e}")

    # ── Callback de lembretes ─────────────────────────────────────────────────
    def alerta_lembrete(msg: str):
        console.print(f"\n[bold yellow]🔔 {msg}[/]")
        if tts:
            tts.speak(msg)

    dp.planner.scheduler.definir_callback(alerta_lembrete)

    # ── Ctrl+C ────────────────────────────────────────────────────────────────
    signal.signal(
        signal.SIGINT,
        lambda s, f: _encerrar(wake, stt, dp)
    )

    # ── Saudação inicial ──────────────────────────────────────────────────────
    from utils.time_utils import get_greeting
    nome     = dp.perfil.get("nome") or ""
    saudacao = (
        f"{get_greeting()} "
        f"{'Olá ' + nome + '! ' if nome else ''}"
        "APOLO pronto. Como posso ajudar?"
    )
    console.print(f"[bold green]{saudacao}[/]\n")
    if tts:
        tts.speak(saudacao)

    # ═══════════════════════════════════════════════════════════════
    # Loop principal
    # ═══════════════════════════════════════════════════════════════
    while True:
        try:
            # ── Entrada: voz ou texto ─────────────────────────────
            if usar_voz and stt:
                entrada = _capturar_voz(stt)
                if not entrada:
                    continue
            else:
                entrada = console.input("[bold cyan]Você:[/] ").strip()

            if not entrada:
                continue

            # ── Feedback de processamento ─────────────────────────
            from voice.feedback import Feedback
            Feedback.on_processing()

            # ── Processar ─────────────────────────────────────────
            resposta = dp.processar(entrada)

            # ── Tratar comandos especiais ─────────────────────────
            if resposta == "__SAIR__":
                despedida = "Até logo! Foi um prazer ajudar."
                console.print(f"[bold cyan]APOLO:[/] {despedida}\n")
                if tts:
                    tts.speak(despedida, block=True)
                break

            elif resposta == "__LIMPAR__":
                dp.contexto.limpar()
                msg = "Histórico apagado. Nova conversa iniciada."
                console.print(f"[bold cyan]APOLO:[/] {msg}\n")
                if tts:
                    tts.speak(msg)

            elif resposta == "__LAYOUT__":
                _mostrar_layout(wake)

            else:
                _responder(resposta, tts, console)

        except KeyboardInterrupt:
            break
        except EOFError:
            break
        except Exception as e:
            from voice.feedback import Feedback
            Feedback.on_error(str(e))
            if debug:
                import traceback
                traceback.print_exc()

    _encerrar(wake, stt, dp)


# ═══════════════════════════════════════════════════════════════════════════════
# Funções auxiliares
# ═══════════════════════════════════════════════════════════════════════════════

def _capturar_voz(stt) -> str:
    """
    Captura áudio do microfone com feedback visual (barra de áudio).
    Retorna o texto transcrito.
    """
    from voice.feedback import Feedback
    import pyaudio, wave, tempfile, os

    Feedback.on_listening()

    RATE  = 16000
    CHUNK = 1024
    DUR   = 6

    try:
        pa     = pyaudio.PyAudio()
        stream = pa.open(
            format=pyaudio.paInt16, channels=1,
            rate=RATE, input=True, frames_per_buffer=CHUNK,
        )
        frames = []
        for _ in range(int(RATE / CHUNK * DUR)):
            data = stream.read(CHUNK, exception_on_overflow=False)
            frames.append(data)
            Feedback.feed_audio(data)   # alimenta a barra de áudio

        stream.stop_stream()
        stream.close()
        pa.terminate()
        Feedback.on_listening_stop()

        # Salva e transcreve
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            path = f.name

        with wave.open(path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(RATE)
            wf.writeframes(b"".join(frames))

        segs, _ = stt.modelo.transcribe(
            path, language="pt", beam_size=5, vad_filter=True
        )
        texto = " ".join(s.text for s in segs).strip()
        os.unlink(path)

    except Exception:
        # Fallback para o método simples do STTEngine
        Feedback.on_listening_stop()
        texto = stt.escutar()

    Feedback.on_heard(texto)
    return texto


def _ciclo_voz(dp, tts, stt, console):
    """Ciclo de escuta ativa disparado após wake word."""
    if not stt:
        try:
            from voice.stt import STTEngine
            stt = STTEngine()
        except Exception:
            return

    texto = _capturar_voz(stt)
    if not texto:
        return

    from voice.feedback import Feedback
    Feedback.on_processing()
    resposta = dp.processar(texto)
    _responder(resposta, tts, console)


def _responder(resposta: str, tts, console):
    """Exibe e fala a resposta."""
    from voice.feedback import Feedback
    Feedback.on_done()
    console.print(f"[bold cyan]APOLO:[/] {resposta}\n")
    if tts and resposta not in ("__SAIR__", "__LIMPAR__"):
        tts.speak(resposta)


def _mostrar_layout(wake=None):
    """Exibe painel de status do APOLO no terminal."""
    import sys
    from core.version import get_version
    from utils.time_utils import get_current_time
    import config

    # Detecta suporte a cores
    usa_cor = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
    C  = "[96m"  # ciano
    G  = "[92m"  # verde
    Y  = "[93m"  # amarelo
    B  = "[1m"   # negrito
    D  = "[2m"   # dim
    R  = "[0m"   # reset
    def c(t, cor): return f"{cor}{t}{R}" if usa_cor else t

    t      = get_current_time()
    hora   = f"{t['hora']:02d}:{t['minuto']:02d}"
    status_wake = "ativo" if (wake and wake.is_running) else "texto"
    backend     = wake.backend if (wake and wake.backend) else "—"

    linha = "─" * 38
    print()
    print(c(f"╔{linha}╗", C))
    print(c(f"║{'APOLO — Painel de Status':^38}║", C + B))
    print(c(f"╠{linha}╣", C))
    def linha_painel(chave, valor, cor_val):
        pad = 22  # espaço para o valor (sem contar escape ANSI)
        val_col = c(valor, cor_val)
        print(c("║", C) + f"  {chave:<14} " + val_col + " " * max(0, pad - len(valor)) + c("║", C))

    linha_painel("Nome",       "APOLO",               B)
    linha_painel("Versão",     get_version(),          G)
    linha_painel("Status",     "● Ativo",              G)
    linha_painel("Wake word",  f"{config.WAKE_WORD} ({status_wake})", Y)
    linha_painel("Backend WW", backend or "—",         D)
    linha_painel("Hora atual", hora,                   C)
    linha_painel("Modelo LLM", config.OLLAMA_MODEL,    D)
    print(c(f"╚{linha}╝", C))
    print()


def _encerrar(wake, stt, dp):
    """Encerra todos os módulos de forma limpa."""
    try:
        if wake: wake.stop()
        if stt:  stt.fechar()
        dp.planner.scheduler.parar()
    except Exception:
        pass
    console.print("[dim]APOLO encerrado.[/]")
    sys.exit(0)


if __name__ == "__main__":
    main()
