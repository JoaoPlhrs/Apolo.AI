"""
core/dispatcher.py — Roteador central do APOLO (pre-alpha 2 — versão completa)

Pipeline de processamento:
  1. CustomCommands  → frases exatas/similares têm prioridade máxima
  2. Learning        → respostas aprendidas por feedback
  3. Routines        → rotinas automáticas ("bom dia", "modo estudo")
  4. AppCommands     → abertura de apps/sites (YouTube, Spotify, etc.)
  5. MemóriaComandos → "me chamo", "lembre que", etc.
  6. Intent/Planner  → comandos de sistema (clima, hora, arquivo)
  7. LLM             → Gemma 4 com contexto de memória
"""

from core.llm_engine import LLMEngine
from core.context_manager import ContextManager
from core.version import get_version
from core.status import Status
from core.online_mode import OnlineMode
from memory.vector_store import VectorMemory
from memory.user_profile import UserProfile
from memory.long_term import LongTermMemory
from memory.context_memory import ContextMemory
from memory.learning import Learning
from agents.intent_parser import IntentParser
from agents.planner import Planner
from agents.routines import RoutineManager
from agents.dev_mode import DevMode
from commands.custom_commands import CustomCommands
from commands.app_commands import AppCommands
from voice.feedback import Feedback
from utils.logger import log
import config

# Padrões de rotina detectados por frase
GATILHOS_ROTINA = {
    "bom dia":          "bom dia",
    "boa noite":        "boa noite",
    "modo estudo":      "modo estudo",
    "modo trabalho":    "modo trabalho",
    "ver notícias":     "notícias",
    "ver noticias":     "notícias",
    "notícias de hoje": "notícias",
}

# Padrões de abertura de apps via AppCommands
GATILHOS_APP = {
    "abre o youtube":       lambda: AppCommands.open_youtube(),
    "abrir youtube":        lambda: AppCommands.open_youtube(),
    "abre youtube":         lambda: AppCommands.open_youtube(),
    "abre o spotify":       lambda: AppCommands.open_spotify(),
    "abrir spotify":        lambda: AppCommands.open_spotify(),
    "abre spotify":         lambda: AppCommands.open_spotify(),
    "abre o vscode":        lambda: AppCommands.open_vscode(),
    "abrir vscode":         lambda: AppCommands.open_vscode(),
    "abre o discord":       lambda: AppCommands.open_discord(),
    "abre o telegram":      lambda: AppCommands.open_telegram(),
    "abre o instagram":     lambda: AppCommands.open_instagram(),
    "abre o chatgpt":       lambda: AppCommands.open_chatgpt(),
    "abre o github":        lambda: AppCommands.open_github(),
    "abre o gmail":         lambda: AppCommands.open_gmail(),
    "abre o chrome":        lambda: AppCommands.open_chrome(),
    "abre o whatsapp":      lambda: AppCommands.open_whatsapp(),
}

# Padrões de modo dev
GATILHOS_DEV = [
    "gera código", "gere código", "crie código", "escreve código",
    "explica esse código", "explique esse código", "review do código",
    "corrija esse código",
]

# Padrões de modo online/offline
GATILHOS_ONLINE = {
    "ativa modo online":    lambda: OnlineMode.enable() and "Modo online ativado.",
    "desativa modo online": lambda: (OnlineMode.disable(), "Modo offline.")[1],
    "busca na web":         None,   # tratado separadamente
    "pesquisa na internet": None,
}


class Dispatcher:
    # Cooldown de execução: evita processar o mesmo comando duas vezes
    # quando wake word + loop principal disparam juntos
    _COOLDOWN_CMDS  = 1.5   # segundos mínimos entre comandos idênticos

    def __init__(self):
        log.info(f"Iniciando APOLO {get_version(full=True)}...")
        Status.set("idle")

        self.llm       = LLMEngine()
        self.contexto  = ContextManager()
        self.memoria   = VectorMemory()
        self.ltm       = LongTermMemory()
        self.ctx_mem   = ContextMemory()
        self.perfil    = UserProfile()
        self.intent    = IntentParser()
        self.planner   = Planner()

        # Controle de duplicatas
        self._ultimo_texto: str   = ""
        self._ultimo_ts:    float = 0.0

        # Injetar referências nos singletons
        RoutineManager.set_llm(self.llm)
        RoutineManager.set_perfil(self.perfil)
        DevMode.set_llm(self.llm)

        # DocumentAnalyzer e AdvancedScheduler
        from tools.document_analyzer import DocumentAnalyzer
        from agents.advanced_scheduler import AdvancedScheduler
        self.doc_analyzer = DocumentAnalyzer(self.llm)
        self.adv_scheduler = AdvancedScheduler()

        log.info(f"APOLO pronto! Backend: {self.memoria.backend_name}")

    # ══════════════════════════════════════════════════════════════════════════
    # Pipeline principal
    # ══════════════════════════════════════════════════════════════════════════

    def processar(self, texto: str) -> str:
        texto = texto.strip()
        if not texto:
            return ""

        # ── Proteção contra execução duplicada ────────────────────────────────
        import time as _time
        agora = _time.time()
        if (texto == self._ultimo_texto and
                agora - self._ultimo_ts < self._COOLDOWN_CMDS):
            log.debug(f"[Dispatcher] Comando duplicado ignorado: '{texto[:40]}'")
            return ""
        self._ultimo_texto = texto
        self._ultimo_ts    = agora
        # ─────────────────────────────────────────────────────────────────────

        log.info(f"Entrada: {texto}")
        Status.set("processando")
        t = texto.lower()

        # ── 1. Comandos personalizados (máxima prioridade) ────────────────────
        resp_custom = CustomCommands.check(texto)
        if resp_custom:
            Feedback.on_custom(texto[:40])
            return self._finalizar(texto, resp_custom)

        # ── 2. Respostas aprendidas ───────────────────────────────────────────
        resp_aprendida = Learning.retrieve_learned_response(texto)
        if resp_aprendida:
            log.info("[Dispatcher] Usando resposta aprendida")
            return self._finalizar(texto, resp_aprendida)

        # ── 3. Rotinas ────────────────────────────────────────────────────────
        for gatilho, nome_rotina in GATILHOS_ROTINA.items():
            if gatilho in t:
                Feedback.on_routine(nome_rotina)
                resultados = RoutineManager.run_routine(nome_rotina)
                resposta   = " ".join(r for r in resultados if r)
                if not resposta:
                    resposta = f"Rotina '{nome_rotina}' executada."
                return self._finalizar(texto, resposta)

        # ── 4. Apps específicos (AppCommands) ─────────────────────────────────
        for gatilho, fn in GATILHOS_APP.items():
            if gatilho in t:
                Feedback.on_command(gatilho)
                resposta = fn()
                return self._finalizar(texto, resposta)

        # ── 5. Modo Dev ───────────────────────────────────────────────────────
        resp_dev = self._checar_dev(texto, t)
        if resp_dev:
            return self._finalizar(texto, resp_dev)

        # ── 6. Modo Online ────────────────────────────────────────────────────
        resp_online = self._checar_online(texto, t)
        if resp_online:
            return self._finalizar(texto, resp_online)

        # ── 7. Comandos de memória ("me chamo", "lembre que") ─────────────────
        resp_mem = self._checar_comando_memoria(texto, t)
        if resp_mem:
            return self._finalizar(texto, resp_mem)

        # ── 8. Intent / Planner (comandos de sistema) ─────────────────────────
        intencao = self.intent.analisar(texto)
        log.info(f"Intencao: {intencao['tipo']}")
        if intencao["tipo"] != "chat":
            resultado = self.planner.executar(intencao)
            if resultado["executado"]:
                Feedback.on_command(intencao["tipo"])
                return self._finalizar(texto, resultado["resposta"])

        # ── 9. LLM (Gemma 4) ──────────────────────────────────────────────────
        memorias = self._montar_contexto(texto)
        historico = self.contexto.get_historico()
        self.contexto.adicionar_usuario(texto)
        resposta = self.llm.gerar(texto, historico=historico, memoria=memorias)
        self.contexto.adicionar_assistente(resposta)
        self._aprender(texto, resposta)
        return self._finalizar(texto, resposta)

    # ── Verificações especializadas ───────────────────────────────────────────

    def _checar_dev(self, texto: str, t: str) -> str | None:
        for g in GATILHOS_DEV:
            if g in t:
                if "gera" in t or "crie" in t or "escreve" in t:
                    lang = "python"
                    for l in ["javascript", "js", "java", "c++", "rust", "go", "html", "sql"]:
                        if l in t:
                            lang = l
                            break
                    prompt = texto
                    for g2 in ["gera código", "gere código", "crie código", "escreve código",
                               f"em {lang}", "um", "uma"]:
                        prompt = prompt.replace(g2, "").strip()
                    return DevMode.generate_code(prompt, lang)

                elif "explica" in t or "explique" in t:
                    # Extrai código do texto (entre ``` ou após "explica")
                    import re
                    match = re.search(r"```.*?```", texto, re.DOTALL)
                    code  = match.group(0) if match else texto.split("explica", 1)[-1].strip()
                    return DevMode.explain_code(code)

                elif "review" in t:
                    import re
                    match = re.search(r"```.*?```", texto, re.DOTALL)
                    code  = match.group(0) if match else texto
                    return DevMode.review_code(code)
        return None

    def _checar_online(self, texto: str, t: str) -> str | None:
        if "ativa modo online" in t:
            ok = OnlineMode.enable()
            return "Modo online ativado! Posso buscar informações na web." if ok \
                   else "Sem conexão com a internet no momento."

        if "desativa modo online" in t or "modo offline" in t:
            OnlineMode.disable()
            return "Voltei ao modo offline."

        if OnlineMode.is_online():
            if any(x in t for x in ["busca na web", "pesquisa na internet",
                                     "procura na web", "o que está acontecendo"]):
                consulta = texto.split("web", 1)[-1].strip() or texto
                res = OnlineMode.search_summary(consulta)
                if res:
                    return self.llm.gerar(f"Com base nesta informação da web: {res}\n"
                                          f"Responda de forma concisa: {consulta}")
        return None

    def _checar_comando_memoria(self, texto: str, t: str) -> str | None:
        for g in ["me chamo ", "meu nome e ", "meu nome é ", "pode me chamar de "]:
            if g in t:
                nome = texto.split(g, 1)[1].strip().split()[0].capitalize()
                self.ltm.save_fact("usuario", "nome", nome)
                self.ltm.save("nome_usuario", nome,
                              type_=LongTermMemory.TYPE_FACT, importance=9)
                self.perfil.atualizar("nome", nome)
                self.ctx_mem.save_context(f"O usuário se chama {nome}.", importance=9)
                return f"Anotado! Vou te chamar de {nome}."

        for g in ["moro em ", "sou de ", "minha cidade e ", "minha cidade é "]:
            if g in t:
                cidade = texto.split(g, 1)[1].strip().split(",")[0].strip()
                self.ltm.save_fact("usuario", "cidade", cidade)
                self.perfil.atualizar("cidade", cidade)
                self.ctx_mem.save_context(f"O usuário mora em {cidade}.", importance=8)
                return f"Entendido! Registrei que você mora em {cidade}."

        for g in ["lembre que ", "lembra que ", "anota que ", "salva que "]:
            if t.startswith(g):
                fato = texto[len(g):].strip()
                self.ltm.save(f"fato_{abs(hash(fato)) % 9999}",
                              fato, type_=LongTermMemory.TYPE_KNOWLEDGE, importance=7)
                self.memoria.salvar(fato, metadata={"tipo": "fato_salvo"})
                self.ctx_mem.save_context(fato, importance=7)
                return f"Anotado: '{fato}'"

        # Ensinar resposta
        if "quando eu disser" in t and "você responde" in t:
            try:
                frase    = texto.split("quando eu disser")[1].split("você responde")[0].strip().strip('"\'')
                resposta = texto.split("você responde")[1].strip().strip('"\'')
                Learning.save_feedback(frase, resposta, source="user")
                CustomCommands.add(frase, resposta)
                return f"Entendido! Quando você disser '{frase}', eu responderei com '{resposta}'."
            except Exception:
                pass

        if any(x in t for x in ["o que voce sabe", "o que você sabe", "o que lembra de mim"]):
            ctx = self.ltm.get_user_context()
            return f"Sei sobre você: {ctx}" if ctx else \
                   "Ainda não sei muita coisa sobre você. Me conta mais!"

        return None

    # ── Contexto para LLM ─────────────────────────────────────────────────────

    def _montar_contexto(self, texto: str) -> list[str]:
        memorias = []
        ctx_ltm  = self.ltm.get_user_context()
        ctx_perf = self.perfil.get_contexto()
        ctx_cont = self.ctx_mem.retrieve_as_text(texto, top_k=3)

        if ctx_ltm:
            memorias.append(f"[Memória] {ctx_ltm}")
        if ctx_perf:
            memorias.append(f"[Perfil] {ctx_perf}")
        if ctx_cont:
            memorias.append(f"[Contexto] {ctx_cont}")
        memorias.extend(self.memoria.buscar(texto))

        if OnlineMode.is_online():
            web = OnlineMode.search_summary(texto)
            if web:
                memorias.append(f"[Web] {web}")

        return memorias

    # ── Utilitários ───────────────────────────────────────────────────────────

    def _aprender(self, entrada: str, resposta: str):
        if len(entrada) > 15:
            self.memoria.salvar(
                f"Usuario: {entrada} | APOLO: {resposta[:150]}",
                metadata={"tipo": "conversa"}
            )
            self.ctx_mem.save_context(
                f"Usuário perguntou '{entrada}' e APOLO respondeu '{resposta[:80]}'",
                importance=2
            )

    def _finalizar(self, entrada: str, saida: str) -> str:
        self.contexto.adicionar_usuario(entrada)
        self.contexto.adicionar_assistente(saida)
        Status.set("respondendo")
        Feedback.on_done(saida)
        return saida

    def processar_stream(self, texto: str,
                         on_chunk: callable = None,
                         on_done:  callable = None) -> str:
        """
        Versão streaming do processar().

        Para comandos (hora, abrir app, etc.): retorna resposta normal.
        Para chat com LLM: entrega chunks em tempo real via on_chunk.

        Args:
            texto:    entrada do usuário
            on_chunk: fn(chunk: str) — chamado a cada pedaço do LLM
            on_done:  fn(texto_completo: str) — chamado ao terminar

        Returns:
            Texto completo da resposta
        """
        texto = texto.strip()
        if not texto:
            return ""

        # Proteção anti-duplicata
        import time as _time
        agora = _time.time()
        if (texto == self._ultimo_texto and
                agora - self._ultimo_ts < self._COOLDOWN_CMDS):
            return ""
        self._ultimo_texto = texto
        self._ultimo_ts    = agora

        t = texto.lower()
        Status.set("processando")

        # 1-8: comandos que retornam imediatamente (sem streaming)
        resp_comando = self._checar_comandos(texto, t)
        if resp_comando is not None:
            if on_done:
                on_done(resp_comando)
            return self._finalizar(texto, resp_comando)

        # 9: LLM com streaming real
        memorias  = self._montar_contexto(texto)
        historico = self.contexto.get_historico()
        self.contexto.adicionar_usuario(texto)

        resposta = self.llm.gerar_stream_callback(
            texto,
            historico = historico,
            memoria   = memorias,
            on_chunk  = on_chunk,
            on_done   = on_done,
        )
        self.contexto.adicionar_assistente(resposta)
        self._aprender(texto, resposta)
        return self._finalizar(texto, resposta)

    def _checar_comandos(self, texto: str, t: str):
        """
        Verifica todas as camadas de comando (1-8).
        Retorna a resposta se encontrou comando, None se deve ir para o LLM.
        """
        # Camada 1: CustomCommands
        resp = CustomCommands.check(texto)
        if resp:
            Feedback.on_custom(texto[:40])
            return resp

        # Camada 2: Learning
        resp = Learning.retrieve_learned_response(texto)
        if resp:
            return resp

        # Camada 3: Rotinas
        for gatilho, nome_rotina in GATILHOS_ROTINA.items():
            if gatilho in t:
                Feedback.on_routine(nome_rotina)
                resultados = RoutineManager.run_routine(nome_rotina)
                return " ".join(r for r in resultados if r) or f"Rotina executada."

        # Camada 4: Apps
        for gatilho, fn in GATILHOS_APP.items():
            if gatilho in t:
                Feedback.on_command(gatilho)
                return fn()

        # Camada 5: Dev
        resp = self._checar_dev(texto, t)
        if resp:
            return resp

        # Camada 6: Online
        resp = self._checar_online(texto, t)
        if resp:
            return resp

        # Camada 7: Memória
        resp = self._checar_comando_memoria(texto, t)
        if resp:
            return resp

        # Camada 8: Intent/Planner
        intencao = self.intent.analisar(texto)
        if intencao["tipo"] != "chat":
            resultado = self.planner.executar(intencao)
            if resultado["executado"]:
                Feedback.on_command(intencao["tipo"])
                return resultado["resposta"]

        # Camada extra: documento colado diretamente (texto longo)
        # Detecta se o usuário colou um documento para resumir/analisar
        if len(texto) > 400 and not t.startswith(("toca", "abre", "pesquis")):
            palavras_doc = ["protocolo", "cpf", "cnpj", "valor", "r$",
                           "nota fiscal", "vencimento", "contrato", "documento"]
            if any(p in t for p in palavras_doc):
                campos = self.doc_analyzer.extrair_e_formatar(texto)
                return campos

        return None   # vai para LLM

    def _montar_contexto(self, texto: str) -> list[str]:
        """Monta lista de memórias para injetar no LLM."""
        memorias = []
        ctx_ltm  = self.ltm.get_user_context()
        ctx_perf = self.perfil.get_contexto()
        ctx_cont = self.ctx_mem.retrieve_as_text(texto, top_k=3)
        if ctx_ltm:  memorias.append(f"[Memoria] {ctx_ltm}")
        if ctx_perf: memorias.append(f"[Perfil] {ctx_perf}")
        if ctx_cont: memorias.append(f"[Contexto] {ctx_cont}")
        memorias.extend(self.memoria.buscar(texto))
        if OnlineMode.is_online():
            web = OnlineMode.search_summary(texto)
            if web:
                memorias.append(f"[Web] {web}")
        return memorias

