"""
core/online_mode.py — Modo online ativável para o APOLO

Quando online:
  - Busca na web via DuckDuckGo (sem API key)
  - Notícias em tempo real
  - Fallback para LLM local quando offline

Uso:
    from core.online_mode import OnlineMode
    OnlineMode.enable()
    OnlineMode.is_online()    → True
    resultado = OnlineMode.search("notícias hoje")
"""

import threading
import time
import urllib.request
import urllib.parse
import json
from utils.logger import log


class _OnlineMode:
    """Singleton — gerencia estado e operações online."""

    CHECK_URL     = "https://8.8.8.8"   # Google DNS — checa conectividade
    CHECK_TIMEOUT = 3

    def __init__(self):
        self._ativo    = False
        self._lock     = threading.Lock()
        self._ultimo_check = 0.0
        self._tem_internet = False

    # ── Controle ──────────────────────────────────────────────────────────────

    def enable(self):
        """Ativa o modo online."""
        if not self._checar_internet():
            log.warning("[Online] Sem conexão com a internet.")
            return False
        with self._lock:
            self._ativo = True
        log.info("[Online] Modo online ativado.")
        return True

    def disable(self):
        """Desativa o modo online (volta ao offline-first)."""
        with self._lock:
            self._ativo = False
        log.info("[Online] Modo online desativado.")

    def is_online(self) -> bool:
        """Retorna True se modo online está ativo E há conexão."""
        with self._lock:
            ativo = self._ativo
        if not ativo:
            return False
        # Re-verifica conexão a cada 60s
        if time.time() - self._ultimo_check > 60:
            self._tem_internet = self._checar_internet()
        return self._tem_internet

    def toggle(self) -> bool:
        """Alterna entre online e offline. Retorna novo estado."""
        if self.is_online():
            self.disable()
            return False
        else:
            return self.enable()

    # ── Funcionalidades online ─────────────────────────────────────────────────

    def search(self, query: str, max_results: int = 3) -> list[dict]:
        """
        Busca na web via DuckDuckGo Instant Answer API.
        Sem API key — 100% gratuito.

        Returns:
            Lista de {"title": str, "snippet": str, "url": str}
        """
        if not self.is_online():
            return []

        try:
            url     = f"https://api.duckduckgo.com/?q={urllib.parse.quote(query)}&format=json&no_redirect=1"
            req     = urllib.request.Request(url, headers={"User-Agent": "APOLO/1.0"})
            resp    = urllib.request.urlopen(req, timeout=5)
            dados   = json.loads(resp.read().decode())

            resultados = []

            # AbstractText (resposta direta da API)
            if dados.get("AbstractText"):
                resultados.append({
                    "title":   dados.get("Heading", query),
                    "snippet": dados["AbstractText"][:300],
                    "url":     dados.get("AbstractURL", ""),
                })

            # RelatedTopics
            for t in dados.get("RelatedTopics", [])[:max_results]:
                if isinstance(t, dict) and t.get("Text"):
                    resultados.append({
                        "title":   t.get("Text", "")[:80],
                        "snippet": t.get("Text", "")[:300],
                        "url":     t.get("FirstURL", ""),
                    })
                if len(resultados) >= max_results:
                    break

            return resultados[:max_results]

        except Exception as e:
            log.warning(f"[Online] Erro na busca: {e}")
            return []

    def search_summary(self, query: str) -> str:
        """
        Retorna uma string resumida dos resultados de busca.
        Pronta para injetar no contexto do LLM.
        """
        resultados = self.search(query)
        if not resultados:
            return ""
        partes = [f"[Web] {r['title']}: {r['snippet']}" for r in resultados]
        return " | ".join(partes)

    def get_news(self, topico: str = "brasil") -> list[dict]:
        """Busca notícias sobre um tópico."""
        return self.search(f"notícias {topico} hoje")

    # ── Utilitários ───────────────────────────────────────────────────────────

    def _checar_internet(self) -> bool:
        """Verifica conectividade com timeout."""
        try:
            urllib.request.urlopen("https://8.8.8.8", timeout=self.CHECK_TIMEOUT)
            self._ultimo_check = time.time()
            return True
        except Exception:
            try:
                # Fallback
                urllib.request.urlopen("https://1.1.1.1", timeout=self.CHECK_TIMEOUT)
                self._ultimo_check = time.time()
                return True
            except Exception:
                return False

    @property
    def status(self) -> str:
        return "online" if self.is_online() else "offline"


# ── Instância global ───────────────────────────────────────────────────────────
OnlineMode = _OnlineMode()
