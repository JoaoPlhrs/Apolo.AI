"""core/version.py — Controle de versão do APOLO"""

from dataclasses import dataclass
from datetime import date


@dataclass(frozen=True)
class VersionInfo:
    major:     int
    minor:     int
    patch:     int
    stage:     str   # "pre-alpha" | "alpha" | "beta" | "rc" | "stable"
    build:     int
    released:  str   # ISO date


# ── Versão atual ───────────────────────────────────────────────────────────────
CURRENT = VersionInfo(
    major    = 1,
    minor    = 0,
    patch    = 0,
    stage    = "pre-release",
    build    = 1,
    released = str(date.today()),
)


def get_version(full: bool = False) -> str:
    """
    Retorna a versão como string.

    get_version()         → "pre-alpha 2"
    get_version(full=True)→ "APOLO v0.2.0-pre-alpha.2 (2025-xx-xx)"
    """
    v = CURRENT
    short = f"Pre-Release {v.build}"
    if not full:
        return short
    return f"APOLO v{v.major}.{v.minor}.{v.patch}-{v.stage}.{v.build} ({v.released})"


def get_version_dict() -> dict:
    """Retorna versão como dicionário — útil para logs e APIs."""
    v = CURRENT
    return {
        "version": get_version(full=True),
        "short":   get_version(),
        "major":   v.major,
        "minor":   v.minor,
        "patch":   v.patch,
        "stage":   v.stage,
        "build":   v.build,
        "released": v.released,
    }


if __name__ == "__main__":
    print(get_version(full=True))
