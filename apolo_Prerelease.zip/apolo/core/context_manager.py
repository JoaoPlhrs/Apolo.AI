"""core/context_manager.py — Gerencia histórico de conversa em memória"""

import json
import os
from datetime import datetime
import config
from utils.logger import log


class ContextManager:
    def __init__(self):
        self.historico: list[dict] = []
        os.makedirs(config.HISTORY_DIR, exist_ok=True)
        self._carregar_ultima_sessao()

    def adicionar_usuario(self, texto: str):
        self.historico.append({"role": "user", "content": texto})
        self._truncar()

    def adicionar_assistente(self, texto: str):
        self.historico.append({"role": "assistant", "content": texto})
        self._truncar()
        self._salvar()

    def get_historico(self) -> list[dict]:
        """Retorna histórico para enviar ao LLM."""
        return self.historico.copy()

    def limpar(self):
        self.historico = []
        log.info("Histórico de conversa limpo.")

    def _truncar(self):
        """Mantém apenas os últimos N turnos para não exceder contexto."""
        max_msgs = config.MAX_HISTORY_TURNS * 2  # user + assistant = 2 por turno
        if len(self.historico) > max_msgs:
            self.historico = self.historico[-max_msgs:]

    def _salvar(self):
        """
        Salva sessão atual em JSON com escrita atômica.
        Usa arquivo temporário + rename para evitar corrupção se o processo
        for interrompido no meio da escrita.
        """
        import tempfile
        try:
            # Lê sessões existentes com validação
            sessoes = self._ler_sessoes()

            sessoes.append({
                "timestamp": datetime.now().isoformat(),
                "mensagens": self.historico[-4:]
            })
            sessoes = sessoes[-50:]  # mantém as últimas 50 sessões

            # Escrita atômica: escreve em temp e renomeia atomicamente
            dir_destino = os.path.dirname(config.HISTORY_FILE)
            os.makedirs(dir_destino, exist_ok=True)

            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=dir_destino,
                suffix=".tmp",
                delete=False
            ) as f:
                json.dump(sessoes, f, ensure_ascii=False, indent=2)
                tmp_path = f.name

            # Rename é atômico no mesmo filesystem
            os.replace(tmp_path, config.HISTORY_FILE)

        except Exception as e:
            log.warning(f"Não foi possível salvar histórico: {e}")
            # Remove temp se existir
            try:
                if "tmp_path" in dir() and os.path.exists(tmp_path):
                    os.unlink(tmp_path)
            except Exception:
                pass

    def _ler_sessoes(self) -> list:
        """
        Lê o arquivo de histórico com tratamento robusto de erros.
        Retorna lista vazia se o arquivo não existir ou estiver corrompido.
        """
        if not os.path.exists(config.HISTORY_FILE):
            return []
        try:
            with open(config.HISTORY_FILE, "r", encoding="utf-8") as f:
                conteudo = f.read().strip()
            if not conteudo:
                return []
            dados = json.loads(conteudo)
            # Garante que é uma lista
            if not isinstance(dados, list):
                log.warning("Histórico com formato inválido. Resetando.")
                return []
            return dados
        except json.JSONDecodeError as e:
            log.warning(f"Histórico JSON corrompido ({e}). Fazendo backup e resetando.")
            # Faz backup do arquivo corrompido antes de perder os dados
            backup = config.HISTORY_FILE + ".bak"
            try:
                os.replace(config.HISTORY_FILE, backup)
                log.info(f"Backup do histórico corrompido salvo em: {backup}")
            except Exception:
                pass
            return []

    def _carregar_ultima_sessao(self):
        """Carrega a última sessão para dar continuidade à conversa."""
        try:
            sessoes = self._ler_sessoes()
            if sessoes:
                ultima = sessoes[-1]
                self.historico = ultima.get("mensagens", [])
                log.info("Última sessão carregada.")
        except Exception:
            self.historico = []
