"""
core/status.py — Sistema de estados globais do APOLO

Estados:
    idle        → aguardando comando
    aguardando  → wake word detectado, pronto para ouvir
    ouvindo     → capturando áudio do microfone
    processando → LLM/agente calculando resposta
    respondendo → TTS falando / exibindo texto

Uso:
    from core.status import Status
    Status.set("ouvindo")
    Status.get()            → "ouvindo"
    Status.is_("ouvindo")   → True
"""

import threading
import time
from typing import Callable
from utils.logger import log

# ── Estados válidos ────────────────────────────────────────────────────────────
ESTADOS_VALIDOS = {"idle", "aguardando", "ouvindo", "processando", "respondendo"}

# Emojis e labels para cada estado (usados pelo feedback visual)
ESTADO_UI = {
    "idle":        ("⚫", "Em repouso"),
    "aguardando":  ("🟡", "Aguardando..."),
    "ouvindo":     ("🎤", "Ouvindo..."),
    "processando": ("🧠", "Processando..."),
    "respondendo": ("🔊", "Respondendo..."),
}


class _StatusManager:
    """Singleton que gerencia o estado atual do APOLO."""

    def __init__(self):
        self._estado: str = "idle"
        self._lock         = threading.Lock()
        self._listeners: list[Callable] = []
        self._historico: list[tuple[str, float]] = []   # (estado, timestamp)

    # ── API pública ────────────────────────────────────────────────────────────

    def set(self, estado: str):
        """
        Define o estado atual.
        Notifica todos os listeners registrados.
        """
        if estado not in ESTADOS_VALIDOS:
            log.warning(f"[Status] Estado desconhecido: '{estado}'. Ignorado.")
            return

        with self._lock:
            if self._estado == estado:
                return
            anterior       = self._estado
            self._estado   = estado
            self._historico.append((estado, time.time()))
            # Mantém só os últimos 50 registros
            if len(self._historico) > 50:
                self._historico = self._historico[-50:]

        log.debug(f"[Status] {anterior} → {estado}")
        self._notificar(estado, anterior)

    def get(self) -> str:
        """Retorna o estado atual."""
        with self._lock:
            return self._estado

    def is_(self, estado: str) -> bool:
        """Verifica se o estado atual é o informado."""
        return self.get() == estado

    def get_ui(self) -> tuple[str, str]:
        """Retorna (emoji, label) para exibição na interface."""
        return ESTADO_UI.get(self.get(), ("⚫", self.get()))

    # ── Listeners ─────────────────────────────────────────────────────────────

    def on_change(self, fn: Callable):
        """
        Registra uma função chamada sempre que o estado mudar.
        fn(novo_estado: str, estado_anterior: str)
        """
        self._listeners.append(fn)

    def _notificar(self, novo: str, anterior: str):
        for fn in self._listeners:
            try:
                fn(novo, anterior)
            except Exception as e:
                log.warning(f"[Status] Erro em listener: {e}")

    # ── Histórico ─────────────────────────────────────────────────────────────

    def historico(self, n: int = 10) -> list[dict]:
        """Retorna os últimos N estados com timestamps."""
        with self._lock:
            recentes = self._historico[-n:]
        return [{"estado": e, "ts": t} for e, t in recentes]

    def tempo_no_estado(self) -> float:
        """Retorna quantos segundos o APOLO está no estado atual."""
        with self._lock:
            if not self._historico:
                return 0.0
            return time.time() - self._historico[-1][1]

    def reset(self):
        """Volta para idle."""
        self.set("idle")


# ── Instância global ───────────────────────────────────────────────────────────
Status = _StatusManager()
