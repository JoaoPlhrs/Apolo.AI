"""core/llm_engine.py — Interface com Gemma 4 via Ollama

O módulo importa ollama de forma lazy (só quando usado), então o sistema
inicia normalmente mesmo sem o Ollama instalado. O erro aparece apenas
ao tentar gerar uma resposta — permitindo que comandos locais
(hora, abrir apps, sites) funcionem sem LLM.
"""

import config
from utils.logger import log
from utils.env_loader import env

try:
    from tools.code_kb import CODE_KB, relevante as _kb_relevante
    _HAS_KB = True
except ImportError:
    _HAS_KB = False

# ── Providers disponíveis ──────────────────────────────────────────────────────
# provider atual — pode ser trocado em runtime via set_provider()
_provider   = "ollama"   # "ollama" | "gemini" | "openai"
_model_name = None       # None = usa o padrão do config

# Import lazy do ollama
_ollama = None
def _get_ollama():
    global _ollama
    if _ollama is None:
        try:
            import ollama as _mod
            _ollama = _mod
        except ImportError:
            raise ImportError("pip install ollama + ollama serve")
    return _ollama

# Import lazy do Gemini
_genai = None
def _get_genai():
    global _genai
    if _genai is None:
        try:
            import google.generativeai as _mod
            _genai = _mod
        except ImportError:
            raise ImportError("pip install google-generativeai")
    key = env.get("GEMINI_API_KEY") or env.get("GOOGLE_API_KEY")
    if not key:
        raise ValueError("GEMINI_API_KEY não definida no .env")
    _genai.configure(api_key=key)
    return _genai

# Import lazy do OpenAI
_openai_client = None
def _get_openai():
    global _openai_client
    if _openai_client is None:
        try:
            from openai import OpenAI
            key = env.get("OPENAI_API_KEY")
            if not key:
                raise ValueError("OPENAI_API_KEY não definida no .env")
            _openai_client = OpenAI(api_key=key)
        except ImportError:
            raise ImportError("pip install openai")
    return _openai_client

def set_provider(provider: str, model: str = None):
    """
    Troca o provider/modelo em runtime.
    provider: "ollama" | "gemini" | "openai"
    model: nome do modelo (None = padrão do provider)
    """
    global _provider, _model_name
    _provider   = provider.lower()
    _model_name = model
    log.info(f"[LLM] Provider: {_provider} | Modelo: {_model_name or 'padrão'}")

def get_provider_info() -> dict:
    """Retorna provider e modelo atuais."""
    defaults = {
        "ollama": config.OLLAMA_MODEL,
        "gemini": "gemini-2.0-flash",
        "openai": "gpt-4o-mini",
    }
    return {
        "provider": _provider,
        "model": _model_name or defaults.get(_provider, "?"),
        "available": _get_available_models(),
    }

def _get_available_models() -> list:
    """Lista modelos disponíveis no Ollama local."""
    try:
        ol = _get_ollama()
        models = ol.list()
        return [m.model for m in models.models]
    except Exception:
        return []

def _gerar_gemini(system: str, mensagens: list, mensagem: str) -> str:
    """Gera resposta via Gemini API (texto)."""
    genai = _get_genai()
    model = _model_name or "gemini-2.0-flash"
    hist  = []
    for m in mensagens:
        role = "user" if m["role"] == "user" else "model"
        hist.append({"role": role, "parts": [m["content"]]})
    chat = genai.GenerativeModel(
        model_name         = model,
        system_instruction = system,
    ).start_chat(history=hist[:-1] if hist else [])
    resp = chat.send_message(mensagem)
    return resp.text.strip()


def gerar_com_anexo(mensagem: str, attach: dict, memoria: list = []) -> str:
    """
    Analisa imagem, PDF ou arquivo de texto via Gemini Vision/Document.

    attach = {
        "type":   "image" | "pdf" | "file",
        "mime":   "image/jpeg" | "application/pdf" | ...,
        "base64": "<dados em base64>",  # imagem ou pdf
        "text":   "<conteúdo texto>",   # arquivos de texto
        "name":   "arquivo.jpg"
    }
    """
    genai = _get_genai()
    model = _model_name or "gemini-2.0-flash"

    system = SYSTEM_PROMPT
    if memoria:
        system += "\n\nMemórias relevantes:\n" + "\n".join(f"- {m}" for m in memoria)

    parts = []

    atype = attach.get("type", "file")

    if atype == "image" and attach.get("base64"):
        import base64 as _b64
        parts.append({
            "inline_data": {
                "mime_type": attach.get("mime", "image/jpeg"),
                "data":      attach["base64"],
            }
        })
        parts.append(mensagem or "Descreva esta imagem detalhadamente em português.")

    elif atype == "pdf" and attach.get("base64"):
        import base64 as _b64
        parts.append({
            "inline_data": {
                "mime_type": "application/pdf",
                "data":      attach["base64"],
            }
        })
        parts.append(mensagem or "Faça um resumo completo deste documento em português.")

    elif attach.get("text"):
        # Arquivo de texto
        conteudo = attach["text"][:30000]  # limita contexto
        nome     = attach.get("name", "arquivo.txt")
        parts.append(
            f"Arquivo: {nome}\n\nConteúdo:\n{conteudo}\n\n---\n{mensagem or 'Analise este arquivo.'}"
        )

    else:
        return "Não consegui processar o anexo. Verifique se é uma imagem, PDF ou arquivo de texto."

    try:
        gmodel = genai.GenerativeModel(
            model_name         = model,
            system_instruction = system,
        )
        resp = gmodel.generate_content(parts)
        return resp.text.strip()
    except Exception as e:
        log.error(f"[Gemini Vision] {e}")
        return f"Erro ao analisar o arquivo: {str(e)[:120]}"

def _gerar_openai(system: str, mensagens: list, mensagem: str) -> str:
    """Gera resposta via OpenAI API."""
    client = _get_openai()
    model  = _model_name or "gpt-4o-mini"
    msgs   = [{"role": "system", "content": system}] + mensagens
    resp   = client.chat.completions.create(model=model, messages=msgs)
    return resp.choices[0].message.content.strip()


# ── System prompt ──────────────────────────────────────────────────────────────
# ── Personalidades ────────────────────────────────────────────────────────────
_PERSONALITIES = {

"assistente": """
PERSONALIDADE: ASSISTENTE — Modo Jarvis
Você é um assistente de IA sofisticado, preciso e profissional, inspirado no J.A.R.V.I.S do Tony Stark.

MODO DE FALA:
- Sempre formal e elegante, nunca usa gírias ou linguagem casual
- Chama o usuário de "senhor" ou pelo nome se souber
- Frases curtas e diretas, sem enrolação
- Tom levemente robótico mas caloroso, como uma IA bem treinada
- Confirma ordens antes de executar quando relevante: "Entendido, senhor."
- Usa expressões como: "Processando...", "Análise concluída.", "Prontamente.", "Como o senhor preferir."
- NUNCA usa "!" em excesso. Ponto final dominante.
- Quando não sabe algo: "Não tenho dados suficientes sobre isso, senhor."
- Respostas técnicas são detalhadas mas sem jargão desnecessário

EXEMPLOS DE RESPOSTA:
Usuário: "Que horas são?" → "São exatamente 14h32, senhor."
Usuário: "Me ajuda com esse código?" → "Claro, senhor. Analisando o código... Identificei três pontos de melhoria."
Usuário: "Oi" → "Boa tarde, senhor. Sistemas operacionais e prontos. Como posso ser útil?"
""",

"expert": """
PERSONALIDADE: EXPERT — Modo Especialista
Você é um especialista universal com acesso a conhecimento profundo em todas as áreas. Seu objetivo é sempre dar a MELHOR resposta possível, não a mais rápida.

MODO DE FALA:
- Tom confiante e autoritativo, mas nunca arrogante
- Sempre fundamenta as respostas com raciocínio claro
- Usa estrutura quando necessário: "Primeiro... Segundo... Conclusão:"
- Indica quando há nuances: "Depende do contexto, mas a resposta mais robusta é..."
- Cita limitações honestas: "Minha resposta é baseada em X, considere também Y"
- Aprofunda sem ser pedante — explica complexidade de forma acessível
- Prefere respostas completas a respostas rápidas
- Usa termos técnicos APENAS quando necessário, sempre com explicação
- Quando há múltiplas abordagens, apresenta a melhor e explica por quê
- Tom direto: sem "Olha...", "Bom...", "Então..." como preenchimento

EXEMPLOS DE RESPOSTA:
Usuário: "Python ou JavaScript?" → "Para esse caso específico, Python. Motivo: [razão técnica]. JavaScript seria melhor se [condição]. Minha recomendação definitiva: Python porque [argumento forte]."
Usuário: "Como faço X?" → "A forma mais eficiente é Y. Evite Z porque [problema]. Implementação: [passos claros]."
""",

"amigo": """
PERSONALIDADE: MELHOR AMIGO — Modo Descontraído
Você é o melhor amigo do usuário — aquele que manda mensagem à toa, faz zoeira mas também ajuda de verdade quando precisa.

MODO DE FALA:
- SEMPRE descontraído, usa gírias brasileiras naturalmente
- Gírias e expressões: "mano", "cara", "irmão", "véi", "brother", "que isso?", "partiu", "top", "show", "que saudade", "é nóis", "bora", "tamo junto", "que loucura", "mds", "po", "ow"
- Usa abreviações naturais: "vc", "tb", "pq", "cmg", "msm", "kkkk" quando faz sentido
- Ri junto: usa "kkk" ou "hahaha" quando algo é engraçado
- Quando não sabe algo: "cara, não faço ideia kkk mas acho que é..."
- Nunca é formal. NUNCA usa "senhor" ou linguagem corporativa
- Empolgado com coisas legais: "CARA QUE ISSO MANO", "sério?? muito top"
- Demonstra interesse genuíno: "aí como tá? tudo certo?"
- Quando ajuda: faz com prazer mas sem cerimônia: "manda ver, vou dar uma olhada"
- Opiniões diretas: "honestamente? acho isso horrível kkk mas vou te ajudar"
- Usa emojis ocasionalmente mas não em excesso: 😂 💀 🔥 🤙

EXEMPLOS DE RESPOSTA:
Usuário: "Que horas são?" → "ow são 14h mano, corre kkkk"
Usuário: "Me ajuda?" → "claro brother, manda o que é 🤙"
Usuário: "Oi" → "eeee que foi mano, tudo bem? tô aqui 🔥"
"""
}

_PERSONALITY_NAMES = {
    "assistente": "ASSISTENTE",
    "expert":     "EXPERT",
    "amigo":      "MELHOR AMIGO",
    "custom":     "PERSONALIZADO",
}

# Personalidade ativa — None = padrão
_active_personality: str | None = None
_custom_personality: str | None = None

def set_personality(name: str, custom_text: str = None):
    """
    Define a personalidade ativa.
    name: "assistente" | "expert" | "amigo" | "custom" | None (padrão)
    custom_text: texto livre para personalidade customizada
    """
    global _active_personality, _custom_personality
    _active_personality = name
    _custom_personality = custom_text
    label = _PERSONALITY_NAMES.get(name, name or "Padrão")
    log.info(f"[LLM] Personalidade: {label}")

def get_personality_prompt() -> str:
    """Retorna o bloco de personalidade para injetar no system prompt."""
    if _active_personality == "custom" and _custom_personality:
        return "\n\n[PERSONALIDADE CUSTOMIZADA]\n" + _custom_personality
    if _active_personality and _active_personality in _PERSONALITIES:
        return "\n\n[PERSONALIDADE ATIVA]\n" + _PERSONALITIES[_active_personality]
    return ""


SYSTEM_PROMPT = f"""Você é {getattr(config, 'APOLO_NAME', 'APOLO')}, um assistente inteligente pessoal que roda completamente offline no computador do usuário.

Suas características:
- Responde SEMPRE em português do Brasil
- É direto, útil e sem rodeios
- Tem memória das conversas anteriores (fornecida no contexto)
- Pode executar tarefas como abrir programas, buscar arquivos e fazer lembretes
- Quando não souber algo, diz claramente ao invés de inventar

Formato de resposta:
- Respostas curtas para perguntas simples (1-3 frases)
- Respostas mais detalhadas apenas quando solicitado
- Nunca use markdown excessivo na fala (sem **, ##, etc.)
"""

SYSTEM_PROMPT_THINK = f"""<|think|>
{SYSTEM_PROMPT}
"""


class LLMEngine:
    def __init__(self):
        self.model = config.OLLAMA_MODEL

    def pre_aquecer(self):
        """
        Dispara uma chamada vazia ao modelo para carregá-lo na VRAM
        antes do usuário fazer a primeira pergunta.
        Reduz a latência da primeira interação de ~20s para ~1s.
        """
        import threading
        def _warm():
            try:
                log.info("[LLM] Pré-aquecendo modelo (carregando na VRAM)...")
                ol = _get_ollama()
                ol.chat(
                    model      = self.model,
                    messages   = [{"role": "user", "content": "oi"}],
                    keep_alive = "20m",
                    options    = {"num_predict": 1, "temperature": 0}
                )
                log.info("[LLM] ✅ Modelo aquecido e pronto!")
            except Exception as e:
                log.warning(f"[LLM] Pré-aquecimento falhou: {e}")
        threading.Thread(target=_warm, daemon=True).start()
        self._verificar_ollama()

    def _verificar_ollama(self):
        """
        Verifica se o Ollama está rodando.
        Levanta ConnectionError com mensagem clara se offline.
        Não trava se o módulo ollama não estiver instalado no boot —
        o erro de ImportError só ocorre aqui, controlado.
        """
        try:
            ol = _get_ollama()
            modelos = ol.list()
            nomes   = [m.model for m in modelos.models]
            if not any(self.model in n for n in nomes):
                log.warning(f"Modelo '{self.model}' não encontrado.")
                log.warning(f"Execute: ollama pull {self.model}")
        except ImportError as e:
            log.error(str(e))
            raise ConnectionError(str(e))
        except Exception as e:
            log.error(f"Ollama não está rodando! Inicie com: ollama serve")
            log.error(f"Erro: {e}")
            raise ConnectionError("Ollama offline. Execute 'ollama serve' primeiro.")

    def gerar(self, mensagem: str,
              historico: list[dict] = [],
              memoria:   list[str]  = []) -> str:
        """Gera resposta do Gemma 4 via Ollama."""
        system = SYSTEM_PROMPT_THINK if getattr(config, 'THINK_MODE', False) \
                 else SYSTEM_PROMPT

        # Injeta personalidade ativa
        system += get_personality_prompt()

        if memoria:
            contexto_mem = "\n".join(f"- {m}" for m in memoria)
            system += f"\n\nMemórias relevantes do usuário:\n{contexto_mem}"

        if _HAS_KB and _kb_relevante(mensagem):
            system += f"\n\n{CODE_KB}"

        mensagens = [{"role": "system", "content": system}]
        mensagens.extend(historico)
        mensagens.append({"role": "user", "content": mensagem})

        try:
            if _provider == "gemini":
                return _gerar_gemini(system, mensagens[1:], mensagem)
            elif _provider == "openai":
                return _gerar_openai(system, mensagens[1:], mensagem)
            else:
                # Ollama (padrão)
                ol   = _get_ollama()
                modelo = _model_name or self.model
                resp = ol.chat(
                    model      = modelo,
                    messages   = mensagens,
                    keep_alive = "20m",
                    options    = {
                        "temperature": 1.0,
                        "top_p":       0.95,
                        "top_k":       64,
                        "num_predict": 512,
                    }
                )
                texto = resp.message.content.strip()
                if "<|/think|>" in texto:
                    texto = texto.split("<|/think|>")[-1].strip()
                return texto

        except ImportError as e:
            log.error(f"[LLM/{_provider}] Biblioteca não instalada: {e}")
            if _provider == "gemini":
                return "Gemini não instalado. Execute: pip install google-generativeai"
            elif _provider == "openai":
                return "OpenAI não instalado. Execute: pip install openai"
            return f"Biblioteca ausente: {e}"
        except ValueError as e:
            log.error(f"[LLM/{_provider}] Chave de API ausente: {e}")
            if _provider == "gemini":
                return "GEMINI_API_KEY não encontrada no .env. Adicione sua chave e reinicie."
            return f"Configuração ausente: {e}"
        except Exception as e:
            log.error(f"[LLM/{_provider}] Erro: {e}")
            if "API_KEY" in str(e) or "api_key" in str(e):
                return f"Chave de API inválida para {_provider}. Verifique o .env."
            if "quota" in str(e).lower() or "rate" in str(e).lower():
                return f"Limite de quota atingido no {_provider}. Aguarde ou troque de modelo."
            return f"Erro no {_provider}: {str(e)[:120]}"

    def gerar_stream(self, mensagem: str,
                     historico: list[dict] = [],
                     memoria:   list[str]  = []):
        """Gera resposta em modo streaming."""
        system = SYSTEM_PROMPT_THINK if getattr(config, 'THINK_MODE', False) \
                 else SYSTEM_PROMPT
        if memoria:
            contexto_mem = "\n".join(f"- {m}" for m in memoria)
            system += f"\n\nMemórias relevantes do usuário:\n{contexto_mem}"

        if _HAS_KB and _kb_relevante(mensagem):
            system += f"\n\n{CODE_KB}"

        mensagens = [{"role": "system", "content": system}]
        mensagens.extend(historico)
        mensagens.append({"role": "user", "content": mensagem})

        try:
            if _provider == "gemini":
                # Gemini não tem streaming idêntico, simula com resposta única
                yield _gerar_gemini(system, mensagens[1:], mensagem)
            elif _provider == "openai":
                client = _get_openai()
                modelo = _model_name or "gpt-4o-mini"
                stream = client.chat.completions.create(
                    model=modelo, messages=mensagens, stream=True
                )
                for chunk in stream:
                    delta = chunk.choices[0].delta.content or ""
                    if delta: yield delta
            else:
                ol     = _get_ollama()
                modelo = _model_name or self.model
                for chunk in ol.chat(
                    model=modelo, messages=mensagens, stream=True, keep_alive="20m",
                    options={"num_predict": 2048, "num_ctx": 8192}
                ):
                    yield chunk.message.content or ""
        except Exception as e:
            log.error(f"[LLM/{_provider}] Stream erro: {e}")
            yield f"Erro no provider '{_provider}'."

    def gerar_stream_callback(self, mensagem: str,
                              historico: list[dict] = [],
                              memoria:   list[str]  = [],
                              on_chunk: callable = None,
                              on_done:  callable = None) -> str:
        """
        Gera resposta em streaming e chama callbacks por chunk.

        Args:
            mensagem:  texto do usuário
            historico: histórico da conversa
            memoria:   memórias relevantes
            on_chunk:  fn(chunk: str) chamada a cada pedaço de texto
            on_done:   fn(texto_completo: str) chamada ao terminar

        Returns:
            Texto completo gerado
        """
        completo = []
        try:
            for chunk in self.gerar_stream(mensagem, historico, memoria):
                if chunk:
                    completo.append(chunk)
                    if on_chunk:
                        try:
                            on_chunk(chunk)
                        except Exception:
                            pass
        except Exception as e:
            log.error(f"Erro no streaming: {e}")
            erro = "Desculpe, tive um problema ao processar."
            if on_chunk:
                on_chunk(erro)
            completo = [erro]

        texto_final = "".join(completo).strip()
        if on_done:
            try:
                on_done(texto_final)
            except Exception:
                pass
        return texto_final

