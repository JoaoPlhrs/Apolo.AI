"""
commands/app_commands.py — Comandos de abertura de aplicativos e sites

Uso:
    from commands.app_commands import AppCommands
    AppCommands.open_youtube()
    AppCommands.open_spotify()
    AppCommands.open_vscode()
"""

import webbrowser
import subprocess
import sys
import os
import glob
from utils.logger import log

WINDOWS = sys.platform == "win32"
MACOS   = sys.platform == "darwin"
LINUX   = sys.platform == "linux"


def _abrir_url(url: str, label: str = "") -> str:
    """Abre URL no navegador padrão."""
    try:
        webbrowser.open(url)
        nome = label or url
        log.info(f"[App] Aberto: {nome}")
        return f"Abrindo {nome}."
    except Exception as e:
        return f"Erro ao abrir {label or url}: {e}"


def _abrir_app_local(candidatos: list[str], nome: str) -> bool:
    """Tenta abrir um app local a partir de uma lista de caminhos/comandos."""
    for cmd in candidatos:
        expandido = os.path.expandvars(os.path.expanduser(cmd))
        # Resolve glob (ex: app-*/App.exe)
        matches = glob.glob(expandido)
        caminho = matches[0] if matches else expandido
        try:
            subprocess.Popen(
                caminho.split() if " " in caminho else [caminho],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            log.info(f"[App] App local aberto: {caminho}")
            return True
        except (FileNotFoundError, PermissionError):
            continue
        except Exception as e:
            log.debug(f"[App] Falha em '{caminho}': {e}")
    return False


class _AppCommands:
    """Singleton — comandos de abertura de apps e sites."""

    # ── Sites ─────────────────────────────────────────────────────────────────

    def open_youtube(self, busca: str = "") -> str:
        """Abre o YouTube, opcionalmente com busca."""
        if busca:
            import urllib.parse
            url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(busca)}"
            return _abrir_url(url, f"YouTube: {busca}")
        return _abrir_url("https://www.youtube.com", "YouTube")

    def open_instagram(self) -> str:
        """Abre o Instagram."""
        return _abrir_url("https://www.instagram.com", "Instagram")

    def open_chatgpt(self) -> str:
        """Abre o ChatGPT."""
        return _abrir_url("https://chat.openai.com", "ChatGPT")

    def open_github(self) -> str:
        """Abre o GitHub."""
        return _abrir_url("https://github.com", "GitHub")

    def open_gmail(self) -> str:
        """Abre o Gmail."""
        return _abrir_url("https://mail.google.com", "Gmail")

    def open_google(self, busca: str = "") -> str:
        """Abre o Google, opcionalmente com busca."""
        if busca:
            import urllib.parse
            return _abrir_url(f"https://www.google.com/search?q={urllib.parse.quote(busca)}", f"Google: {busca}")
        return _abrir_url("https://www.google.com", "Google")

    def open_twitter(self) -> str:
        return _abrir_url("https://twitter.com", "Twitter/X")

    def open_linkedin(self) -> str:
        return _abrir_url("https://www.linkedin.com", "LinkedIn")

    def open_reddit(self) -> str:
        return _abrir_url("https://www.reddit.com", "Reddit")

    def open_whatsapp(self) -> str:
        return _abrir_url("https://web.whatsapp.com", "WhatsApp Web")

    def open_notion(self) -> str:
        return _abrir_url("https://www.notion.so", "Notion")

    def open_trello(self) -> str:
        return _abrir_url("https://trello.com", "Trello")

    # ── Apps locais ───────────────────────────────────────────────────────────

    def open_spotify(self) -> str:
        """Abre o Spotify (app local ou web como fallback)."""
        candidatos_win   = [
            r"%APPDATA%\Spotify\Spotify.exe",
            r"%LOCALAPPDATA%\Microsoft\WindowsApps\Spotify.exe",
            "spotify",
        ]
        candidatos_linux = ["spotify", "flatpak run com.spotify.Client"]
        candidatos_mac   = ["/Applications/Spotify.app/Contents/MacOS/Spotify"]

        candidatos = (candidatos_win if WINDOWS
                      else candidatos_mac if MACOS
                      else candidatos_linux)

        if _abrir_app_local(candidatos, "Spotify"):
            return "Abrindo Spotify."
        # Fallback web
        return _abrir_url("https://open.spotify.com", "Spotify Web")

    def open_vscode(self, path: str = "") -> str:
        """Abre o Visual Studio Code, opcionalmente em um caminho."""
        cmd_base = ["code"]
        if path:
            cmd_base.append(os.path.expanduser(path))
        try:
            subprocess.Popen(cmd_base, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"Abrindo VS Code{' em ' + path if path else ''}."
        except FileNotFoundError:
            pass

        # Caminhos alternativos no Windows
        win_paths = [
            r"%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe",
            r"%ProgramFiles%\Microsoft VS Code\Code.exe",
        ]
        if WINDOWS and _abrir_app_local(win_paths, "VS Code"):
            return "Abrindo VS Code."

        return "VS Code não encontrado. Instale em: https://code.visualstudio.com"

    def open_discord(self) -> str:
        """Abre o Discord."""
        candidatos_win   = [r"%LOCALAPPDATA%\Discord\app-*\Discord.exe", "discord"]
        candidatos_linux = ["discord", "flatpak run com.discordapp.Discord"]
        candidatos_mac   = ["/Applications/Discord.app/Contents/MacOS/Discord"]

        candidatos = (candidatos_win if WINDOWS
                      else candidatos_mac if MACOS
                      else candidatos_linux)

        if _abrir_app_local(candidatos, "Discord"):
            return "Abrindo Discord."
        return _abrir_url("https://discord.com/app", "Discord Web")

    def open_telegram(self) -> str:
        """Abre o Telegram."""
        candidatos_win   = [r"%APPDATA%\Telegram Desktop\Telegram.exe", "telegram"]
        candidatos_linux = ["telegram-desktop", "flatpak run org.telegram.desktop"]
        candidatos_mac   = ["/Applications/Telegram.app/Contents/MacOS/Telegram"]

        candidatos = (candidatos_win if WINDOWS
                      else candidatos_mac if MACOS
                      else candidatos_linux)

        if _abrir_app_local(candidatos, "Telegram"):
            return "Abrindo Telegram."
        return _abrir_url("https://web.telegram.org", "Telegram Web")

    def open_chrome(self, url: str = "") -> str:
        """Abre o Google Chrome."""
        from commands.system_commands import open_chrome
        ok = open_chrome(url)
        return "Abrindo Chrome." if ok else "Chrome não encontrado no sistema."

    def open_obs(self) -> str:
        """Abre o OBS Studio."""
        candidatos_win   = [r"%ProgramFiles%\obs-studio\bin\64bit\obs64.exe", "obs64", "obs"]
        candidatos_linux = ["obs", "flatpak run com.obsproject.Studio"]
        candidatos_mac   = ["/Applications/OBS.app/Contents/MacOS/OBS"]

        candidatos = (candidatos_win if WINDOWS else
                      candidatos_mac if MACOS else candidatos_linux)
        if _abrir_app_local(candidatos, "OBS"):
            return "Abrindo OBS Studio."
        return "OBS Studio não encontrado."

    def open_calculator(self) -> str:
        """Abre a calculadora do sistema."""
        if WINDOWS:
            ok = _abrir_app_local(["calc.exe"], "Calculadora")
        elif MACOS:
            ok = _abrir_app_local(["open -a Calculator"], "Calculadora")
        else:
            ok = _abrir_app_local(["gnome-calculator", "kcalc", "xcalc"], "Calculadora")
        return "Abrindo calculadora." if ok else "Calculadora não encontrada."

    def open_file_manager(self) -> str:
        """Abre o gerenciador de arquivos."""
        if WINDOWS:
            ok = _abrir_app_local(["explorer.exe"], "Explorador")
        elif MACOS:
            ok = _abrir_app_local(["open -a Finder"], "Finder")
        else:
            ok = _abrir_app_local(["nautilus", "dolphin", "thunar", "nemo"], "Gerenciador")
        return "Abrindo gerenciador de arquivos." if ok else "Gerenciador não encontrado."

    # ── Meta-função: abre qualquer coisa por nome ─────────────────────────────

    def open(self, nome: str) -> str:
        """
        Tenta abrir qualquer app ou site pelo nome.
        Usado pelo Planner quando a intenção é 'abrir_app'.
        """
        nome_l = nome.lower().strip()
        mapa = {
            "youtube":          self.open_youtube,
            "instagram":        self.open_instagram,
            "chatgpt":          lambda: self.open_chatgpt(),
            "chat gpt":         lambda: self.open_chatgpt(),
            "github":           self.open_github,
            "gmail":            self.open_gmail,
            "google":           self.open_google,
            "spotify":          self.open_spotify,
            "vscode":           self.open_vscode,
            "vs code":          self.open_vscode,
            "visual studio":    self.open_vscode,
            "discord":          self.open_discord,
            "telegram":         self.open_telegram,
            "chrome":           self.open_chrome,
            "google chrome":    self.open_chrome,
            "obs":              self.open_obs,
            "obs studio":       self.open_obs,
            "calculadora":      self.open_calculator,
            "calculator":       self.open_calculator,
            "arquivos":         self.open_file_manager,
            "explorador":       self.open_file_manager,
            "whatsapp":         self.open_whatsapp,
            "twitter":          self.open_twitter,
            "linkedin":         self.open_linkedin,
            "reddit":           self.open_reddit,
            "notion":           self.open_notion,
            "trello":           self.open_trello,
        }

        # Correspondência exata
        if nome_l in mapa:
            return mapa[nome_l]()

        # Correspondência parcial
        for chave, fn in mapa.items():
            if chave in nome_l or nome_l in chave:
                return fn()

        # Fallback: usa SystemCommands
        from commands.system_commands import SystemCommands
        sc = SystemCommands()
        ok = sc.abrir_app(nome)
        return f"{'Abrindo' if ok else 'Não encontrei'} {nome}."


# ── Instância global ───────────────────────────────────────────────────────────
AppCommands = _AppCommands()
