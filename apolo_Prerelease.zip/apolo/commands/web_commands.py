"""
commands/web_commands.py — Comandos para abrir sites e navegar (V2.5)

Usa apenas webbrowser (stdlib) — sem dependências extras.
Compatível com Windows, Linux e macOS.

Uso:
    from commands.web_commands import WebCommands
    wc = WebCommands()
    wc.open_youtube()
    wc.open_instagram()
    wc.buscar_google("python tutorial")
"""

import webbrowser
import urllib.parse
from utils.logger import log


class WebCommands:
    """Comandos para abrir sites e fazer buscas no navegador padrão."""

    # ── Sites diretos ─────────────────────────────────────────────

    def open_youtube(self, busca: str = "") -> str:
        """
        Abre o YouTube. Se informar busca, pesquisa diretamente.

        Exemplos:
            open_youtube()                     → youtube.com
            open_youtube("lofi music study")   → resultado de busca
        """
        if busca:
            url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(busca)}"
            msg = f"Abrindo YouTube e pesquisando '{busca}'."
        else:
            url = "https://www.youtube.com"
            msg = "Abrindo YouTube."
        self._abrir(url)
        return msg

    def open_instagram(self) -> str:
        """Abre o Instagram."""
        self._abrir("https://www.instagram.com")
        return "Abrindo Instagram."

    def open_chatgpt(self) -> str:
        """Abre o ChatGPT."""
        self._abrir("https://chat.openai.com")
        return "Abrindo ChatGPT."

    def open_spotify(self) -> str:
        """Abre o Spotify Web."""
        self._abrir("https://open.spotify.com")
        return "Abrindo Spotify."

    def tocar_no_spotify(self, musica: str) -> str:
        """
        Toca uma música diretamente no Spotify.

        Estratégia:
          1. Tenta abrir o app Spotify via URI scheme (spotify:search:...)
             → abre o Spotify instalado e já executa a busca dentro do app
          2. Fallback: abre o Spotify Web com a busca pronta para tocar
        """
        import urllib.parse
        import subprocess, sys

        musica_enc = urllib.parse.quote(musica)

        # URI scheme do Spotify — abre o app instalado diretamente
        uri_spotify = f"spotify:search:{musica_enc}"

        # Tenta abrir via URI scheme (funciona no Windows, Mac e Linux
        # se o Spotify estiver instalado)
        abriu_app = False
        try:
            if sys.platform == "win32":
                import os
                os.startfile(uri_spotify)
                abriu_app = True
            elif sys.platform == "darwin":
                subprocess.Popen(["open", uri_spotify],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
                abriu_app = True
            else:  # Linux
                r = subprocess.run(
                    ["xdg-open", uri_spotify],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=3
                )
                abriu_app = (r.returncode == 0)
        except Exception:
            abriu_app = False

        if abriu_app:
            log.info(f"[Music] Spotify app: {uri_spotify}")
            return f"Abrindo '{musica}' no Spotify."

        # Fallback: Spotify Web com busca
        url_web = f"https://open.spotify.com/search/{musica_enc}"
        self._abrir(url_web)
        log.info(f"[Music] Spotify Web: {url_web}")
        return f"Buscando '{musica}' no Spotify Web."

    def open_github(self) -> str:
        """Abre o GitHub."""
        self._abrir("https://github.com")
        return "Abrindo GitHub."

    def open_gmail(self) -> str:
        """Abre o Gmail."""
        self._abrir("https://mail.google.com")
        return "Abrindo Gmail."

    def open_whatsapp(self) -> str:
        """Abre o WhatsApp Web."""
        self._abrir("https://web.whatsapp.com")
        return "Abrindo WhatsApp Web."

    def open_twitter(self) -> str:
        """Abre o Twitter/X."""
        self._abrir("https://twitter.com")
        return "Abrindo Twitter."

    def open_reddit(self) -> str:
        """Abre o Reddit."""
        self._abrir("https://www.reddit.com")
        return "Abrindo Reddit."

    def open_linkedin(self) -> str:
        """Abre o LinkedIn."""
        self._abrir("https://www.linkedin.com")
        return "Abrindo LinkedIn."

    # ── Buscas ───────────────────────────────────────────────────

    def buscar_google(self, consulta: str) -> str:
        """Pesquisa no Google."""
        url = f"https://www.google.com/search?q={urllib.parse.quote(consulta)}"
        self._abrir(url)
        return f"Pesquisando no Google: '{consulta}'."

    def buscar_youtube(self, consulta: str) -> str:
        """Pesquisa no YouTube."""
        return self.open_youtube(busca=consulta)

    # ── Utilitários ───────────────────────────────────────────────

    def abrir_navegador(self, url: str = "https://www.google.com") -> str:
        """Abre uma URL qualquer no navegador padrão."""
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        self._abrir(url)
        return f"Abrindo {url}."

    def abrir_url(self, url: str) -> bool:
        """Alias compatível com código legado da V2."""
        return self._abrir(url)

    def _abrir(self, url: str) -> bool:
        """Abre URL e registra no log."""
        try:
            webbrowser.open(url)
            log.info(f"[Web] Aberto: {url}")
            return True
        except Exception as e:
            log.error(f"[Web] Erro ao abrir '{url}': {e}")
            return False

    # ── Método genérico: abre site pelo nome ──────────────────────

    def abrir_site(self, nome: str) -> str:
        """
        Abre um site pelo nome amigável.
        Usado pelo Planner quando detecta intenção de abrir site.

        Args:
            nome: "youtube", "instagram", "chatgpt", "spotify", etc.

        Returns:
            Mensagem de confirmação
        """
        nome_l = nome.lower().strip()
        mapa = {
            "youtube":          self.open_youtube,
            "instagram":        self.open_instagram,
            "chatgpt":          self.open_chatgpt,
            "chat gpt":         self.open_chatgpt,
            "spotify":          self.open_spotify,
            "github":           self.open_github,
            "gmail":            self.open_gmail,
            "whatsapp":         self.open_whatsapp,
            "twitter":          self.open_twitter,
            "reddit":           self.open_reddit,
            "linkedin":         self.open_linkedin,
            "google":           lambda: self.abrir_navegador("https://www.google.com"),
        }

        # Correspondência exata
        if nome_l in mapa:
            return mapa[nome_l]()

        # Correspondência parcial
        for chave, fn in mapa.items():
            if chave in nome_l or nome_l in chave:
                return fn()

        # Nenhum match — tenta abrir como URL diretamente
        return self.abrir_navegador(nome_l)
