"""
commands/custom_commands.py — Comandos personalizados por frase exata ou parcial

O usuário pode definir frases que disparam respostas específicas.
Suporta: texto simples, TTS, ação Python, e abertura de apps/URLs.

Arquivo de dados: data/custom_commands.json

Uso:
    from commands.custom_commands import CustomCommands
    CustomCommands.add("acorda criança papai chegou",
                       "Bem-vindo senhor! A cerimônia foi um sucesso.")
    resposta = CustomCommands.check("acorda criança papai chegou")
"""

import os
import re
import json
import time
from typing import Optional, Callable
import config
from utils.logger import log

CUSTOM_FILE = os.path.join(config.DATA_DIR, "custom_commands.json")
STOPWORDS   = {"o", "a", "e", "de", "do", "da", "que", "se", "em", "um", "uma",
               "é", "não", "me", "te", "eu", "tu", "para", "com", "por", "mas"}


def _normalizar(texto: str) -> str:
    t = texto.lower().strip()
    t = re.sub(r"[^\w\s]", "", t)
    t = re.sub(r"\s+",     " ", t)
    return t


def _jaccard(a: str, b: str) -> float:
    """Similaridade de Jaccard entre dois textos normalizados."""
    pa = set(a.split()) - STOPWORDS
    pb = set(b.split()) - STOPWORDS
    if not pa or not pb:
        return 0.0
    return len(pa & pb) / len(pa | pb)


# ── Comandos padrão embutidos ─────────────────────────────────────────────────
COMANDOS_PADRAO: dict[str, dict] = {
    "acorda criança papai chegou": {
        "response": "Bem-vindo senhor! Parabéns, a cerimônia de abertura foi um sucesso!",
        "action":   None,
    },
    "modo silencioso": {
        "response": "Modo silencioso ativado. Só responderei quando chamado.",
        "action":   None,
    },
    "qual sua versão": {
        "response": None,  # None = usa função de ação
        "action":   "version",
    },
    "status do sistema": {
        "response": None,
        "action":   "status",
    },
}


class _CustomCommands:
    """Singleton — gerencia comandos personalizados por frase."""

    THRESHOLD = 0.60    # similaridade mínima para match

    def __init__(self):
        self._comandos: dict[str, dict] = dict(COMANDOS_PADRAO)
        self._custom_fns: dict[str, Callable] = {}
        self._load()

    def _load(self):
        """Carrega comandos salvos em disco."""
        if os.path.exists(CUSTOM_FILE):
            try:
                with open(CUSTOM_FILE, "r", encoding="utf-8") as f:
                    salvo = json.load(f)
                # Mescla com padrão (padrão tem prioridade)
                for k, v in salvo.items():
                    if k not in COMANDOS_PADRAO:
                        self._comandos[k] = v
                log.info(f"[CustomCmd] {len(salvo)} comandos carregados")
            except Exception as e:
                log.warning(f"[CustomCmd] Erro ao carregar: {e}")

    def _save(self):
        """Salva apenas os comandos customizados (não os padrão)."""
        os.makedirs(config.DATA_DIR, exist_ok=True)
        personalizados = {k: v for k, v in self._comandos.items()
                          if k not in COMANDOS_PADRAO}
        try:
            with open(CUSTOM_FILE, "w", encoding="utf-8") as f:
                json.dump(personalizados, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log.warning(f"[CustomCmd] Erro ao salvar: {e}")

    # ── API principal ──────────────────────────────────────────────────────────

    def check(self, texto: str) -> Optional[str]:
        """
        Verifica se o texto corresponde a algum comando personalizado.

        Estratégia:
          1. Match exato (normalizado)
          2. Substring (frase curta contida no input)
          3. Similaridade Jaccard > THRESHOLD

        Returns:
            String com a resposta, ou None se nenhum comando ativado
        """
        texto_norm = _normalizar(texto)
        melhor_score = 0.0
        melhor_cmd   = None

        for frase, dados in self._comandos.items():
            frase_norm = _normalizar(frase)

            # Match exato
            if texto_norm == frase_norm:
                return self._executar(dados)

            # Substring (frase-chave contida no input)
            if frase_norm in texto_norm:
                return self._executar(dados)

            # Similaridade Jaccard
            score = _jaccard(texto_norm, frase_norm)
            if score > melhor_score:
                melhor_score = score
                melhor_cmd   = dados

        if melhor_score >= self.THRESHOLD and melhor_cmd:
            log.info(f"[CustomCmd] Match ({melhor_score:.2f}): '{texto[:40]}'")
            return self._executar(melhor_cmd)

        return None

    def _executar(self, dados: dict) -> str:
        """Executa a ação de um comando e retorna a resposta."""
        # Resposta de texto
        if dados.get("response"):
            return dados["response"]

        # Ação especial
        acao = dados.get("action")
        if acao:
            # Ação de função customizada
            if acao in self._custom_fns:
                try:
                    return str(self._custom_fns[acao]())
                except Exception as e:
                    return f"Erro na ação '{acao}': {e}"

            # Ações embutidas
            if acao == "version":
                from core.version import get_version
                return get_version(full=True)

            if acao == "status":
                from core.status import Status
                emoji, label = Status.get_ui()
                return f"Status: {emoji} {label}"

            # URL
            if acao.startswith("url:"):
                import webbrowser
                url = acao[4:]
                webbrowser.open(url)
                return f"Abrindo {url}."

            # App
            if acao.startswith("app:"):
                from commands.app_commands import AppCommands
                return AppCommands.open(acao[4:])

        return ""

    def add(self, frase: str, response: str = None,
            action: str = None) -> bool:
        """
        Adiciona ou atualiza um comando personalizado.

        Args:
            frase:    frase gatilho
            response: texto de resposta (ou None se usar action)
            action:   ação especial:
                        "url:https://..."  → abre URL
                        "app:spotify"      → abre app
                        nome de função registrada via register_fn()

        Exemplo:
            add("boa tarde chefe", "Boa tarde! Em que posso ajudar?")
            add("abre youtube", action="url:https://youtube.com")
        """
        if not frase.strip():
            return False
        self._comandos[_normalizar(frase)] = {
            "response": response,
            "action":   action,
        }
        self._save()
        log.info(f"[CustomCmd] Adicionado: '{frase}'")
        return True

    def remove(self, frase: str) -> bool:
        """Remove um comando personalizado."""
        chave = _normalizar(frase)
        if chave in COMANDOS_PADRAO:
            log.warning(f"[CustomCmd] Não é possível remover comando padrão: '{frase}'")
            return False
        if chave in self._comandos:
            del self._comandos[chave]
            self._save()
            return True
        return False

    def register_fn(self, name: str, fn: Callable):
        """Registra uma função Python para usar como action."""
        self._custom_fns[name] = fn

    def list_all(self) -> list[dict]:
        """Lista todos os comandos com frase e preview da resposta."""
        resultado = []
        for frase, dados in self._comandos.items():
            resultado.append({
                "frase":    frase,
                "response": (dados.get("response") or "")[:60],
                "action":   dados.get("action") or "",
                "builtin":  frase in {_normalizar(k) for k in COMANDOS_PADRAO},
            })
        return resultado

    def load_from_dict(self, comandos: dict):
        """
        Carrega comandos de um dicionário {frase: resposta}.
        Útil para carregar de arquivo JSON externo.
        """
        for frase, resp in comandos.items():
            if isinstance(resp, str):
                self.add(frase, response=resp)
            elif isinstance(resp, dict):
                self.add(frase, **resp)

    def load_from_json(self, caminho: str) -> int:
        """Importa comandos de um arquivo JSON. Retorna quantidade importada."""
        try:
            with open(caminho, "r", encoding="utf-8") as f:
                dados = json.load(f)
            self.load_from_dict(dados)
            return len(dados)
        except Exception as e:
            log.error(f"[CustomCmd] Erro ao importar JSON: {e}")
            return 0


# ── Instância global ───────────────────────────────────────────────────────────
CustomCommands = _CustomCommands()
