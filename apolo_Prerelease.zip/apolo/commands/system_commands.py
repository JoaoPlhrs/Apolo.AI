"""
commands/system_commands.py — Execução de comandos no sistema operacional

Compatível com Windows (prioridade), Linux e macOS.
Inclui open_chrome() e abrir_app() genérico.
"""

import os
import sys
import subprocess
import glob
from pathlib import Path
from utils.logger import log

# ─── Detecção de SO ────────────────────────────────────────────────────────────
WINDOWS = sys.platform == "win32"
MACOS   = sys.platform == "darwin"
LINUX   = sys.platform == "linux"

# ─── Mapa de aplicativos por SO ───────────────────────────────────────────────
APPS: dict[str, dict] = {
    "chrome": {
        "win":   [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe",
            "chrome",
        ],
        "linux": ["google-chrome", "google-chrome-stable", "chromium-browser", "chromium"],
        "mac":   ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "open -a 'Google Chrome'"],
    },
    "firefox": {
        "win":   [r"C:\Program Files\Mozilla Firefox\firefox.exe", "firefox"],
        "linux": ["firefox", "firefox-esr"],
        "mac":   ["/Applications/Firefox.app/Contents/MacOS/firefox"],
    },
    "edge": {
        "win":   [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            "msedge",
        ],
        "linux": ["microsoft-edge"],
        "mac":   ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"],
    },
    "vscode": {
        "win":   [r"%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe", "code"],
        "linux": ["code"],
        "mac":   ["/Applications/Visual Studio Code.app/Contents/MacOS/Electron", "code"],
    },
    "notepad": {
        "win":   ["notepad.exe"],
        "linux": ["gedit", "mousepad", "xed", "kate"],
        "mac":   ["open -a TextEdit"],
    },
    "calculadora": {
        "win":   ["calc.exe"],
        "linux": ["gnome-calculator", "kcalc", "xcalc"],
        "mac":   ["open -a Calculator"],
    },
    "explorador": {
        "win":   ["explorer.exe"],
        "linux": ["nautilus", "dolphin", "thunar", "nemo"],
        "mac":   ["open -a Finder"],
    },
    "terminal": {
        "win":   ["wt.exe", "cmd.exe"],
        "linux": ["gnome-terminal", "konsole", "xterm"],
        "mac":   ["open -a Terminal"],
    },
    "spotify": {
        "win":   [r"%APPDATA%\Spotify\Spotify.exe", "spotify"],
        "linux": ["spotify"],
        "mac":   ["open -a Spotify"],
    },
    "discord": {
        "win":   [r"%LOCALAPPDATA%\Discord\app-*\Discord.exe", "discord"],
        "linux": ["discord"],
        "mac":   ["open -a Discord"],
    },
    "telegram": {
        "win":   [r"%APPDATA%\Telegram Desktop\Telegram.exe", "telegram"],
        "linux": ["telegram-desktop"],
        "mac":   ["open -a Telegram"],
    },
    "vlc": {
        "win":   [r"C:\Program Files\VideoLAN\VLC\vlc.exe", "vlc"],
        "linux": ["vlc"],
        "mac":   ["open -a VLC"],
    },
    "word": {
        "win":   ["winword.exe"],
        "linux": ["libreoffice --writer"],
        "mac":   ["open -a Microsoft Word"],
    },
    "excel": {
        "win":   ["excel.exe"],
        "linux": ["libreoffice --calc"],
        "mac":   ["open -a Microsoft Excel"],
    },
    "paint": {
        "win":   ["mspaint.exe"],
        "linux": ["gimp", "pinta"],
        "mac":   ["open -a Preview"],
    },
    "steam": {
        "win":   [r"C:\Program Files (x86)\Steam\Steam.exe", "steam"],
        "linux": ["steam"],
        "mac":   ["open -a Steam"],
    },
}

# Aliases (nomes alternativos para o mesmo app)
ALIASES: dict[str, str] = {
    "navegador":       "chrome",
    "browser":         "chrome",
    "google chrome":   "chrome",
    "google":          "chrome",
    "mozilla":         "firefox",
    "microsoft edge":  "edge",
    "vs code":         "vscode",
    "visual studio":   "vscode",
    "bloco de notas":  "notepad",
    "bloc de notas":   "notepad",
    "gerenciador":     "explorador",
    "arquivos":        "explorador",
    "pasta":           "explorador",
    "musica":          "spotify",
    "calc":            "calculadora",
    "word":            "word",
    "excel":           "excel",
}

# Diretórios de busca de arquivos
DIRS_BUSCA = [
    Path.home(),
    Path.home() / "Desktop",
    Path.home() / "Documents",
    Path.home() / "Downloads",
    Path.home() / "Pictures",
    Path.home() / "Videos",
    Path.home() / "Music",
]
if WINDOWS:
    DIRS_BUSCA += [
        Path.home() / "OneDrive",
        Path(os.environ.get("PUBLIC", r"C:\Users\Public")),
    ]


def _so() -> str:
    if WINDOWS: return "win"
    if MACOS:   return "mac"
    return "linux"


def _expandir(caminho: str) -> str:
    """Expande variáveis de ambiente e glob no caminho."""
    expandido = os.path.expandvars(os.path.expanduser(caminho))
    # Resolve glob (ex: app-*/Discord.exe)
    matches = glob.glob(expandido)
    return matches[0] if matches else expandido


def _executar(cmd: list | str) -> bool:
    """Executa um comando e retorna True se bem-sucedido."""
    try:
        if isinstance(cmd, str):
            # Strings com espaços (como "open -a Spotify")
            subprocess.Popen(cmd, shell=True,
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(cmd,
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        return True
    except FileNotFoundError:
        return False
    except Exception as e:
        log.debug(f"[CMD] Falha ao executar {cmd}: {e}")
        return False


# ══════════════════════════════════════════════════════════════════════════════
# Função principal: open_chrome()
# ══════════════════════════════════════════════════════════════════════════════

def open_chrome(url: str = "") -> bool:
    """
    Abre o Google Chrome.

    Args:
        url: URL opcional para abrir diretamente

    Returns:
        True se aberto com sucesso
    """
    candidatos = APPS["chrome"][_so()]
    for caminho in candidatos:
        expandido = _expandir(caminho)
        cmd = [expandido, url] if url else [expandido]
        if _executar(cmd):
            log.info(f"[CMD] Chrome aberto: {expandido}")
            return True
    log.warning("[CMD] Chrome nao encontrado no sistema")
    return False


# ══════════════════════════════════════════════════════════════════════════════
# Classe SystemCommands
# ══════════════════════════════════════════════════════════════════════════════

class SystemCommands:
    """Executa comandos no sistema operacional."""

    def abrir_app(self, nome: str, args: list = None) -> bool:
        """
        Abre um aplicativo pelo nome (suporta aliases).

        Args:
            nome: nome do app ("chrome", "vscode", "spotify", etc.)
            args: argumentos extras (ex: URL para o browser)

        Returns:
            True se aberto com sucesso
        """
        nome_norm = nome.lower().strip()
        # Resolve alias
        chave = ALIASES.get(nome_norm, nome_norm)

        # Tenta no mapa de apps
        if chave in APPS:
            candidatos = APPS[chave][_so()]
            for caminho in candidatos:
                expandido = _expandir(caminho)
                cmd       = [expandido] + (args or [])
                if _executar(cmd):
                    log.info(f"[CMD] App aberto: {expandido}")
                    return True

        # Tenta busca parcial no mapa
        for app_key, variantes in APPS.items():
            if nome_norm in app_key or app_key in nome_norm:
                for caminho in variantes[_so()]:
                    expandido = _expandir(caminho)
                    cmd       = [expandido] + (args or [])
                    if _executar(cmd):
                        log.info(f"[CMD] App aberto (parcial): {expandido}")
                        return True

        # Último recurso: tenta o nome diretamente
        for tentativa in [nome_norm, nome, nome.replace(" ", "")]:
            if _executar([tentativa] + (args or [])):
                log.info(f"[CMD] App aberto (direto): {tentativa}")
                return True

        log.warning(f"[CMD] App nao encontrado: '{nome}'")
        return False

    def open_chrome(self, url: str = "") -> bool:
        """Atalho para abrir o Chrome."""
        return open_chrome(url)

    def buscar_arquivo(self, nome: str, extensoes: list = None,
                       max_resultados: int = 5) -> str:
        """
        Busca arquivos por nome nos diretórios do usuário.

        Args:
            nome:           nome parcial ou completo do arquivo
            extensoes:      lista de extensões para filtrar (ex: [".pdf", ".docx"])
            max_resultados: máximo de resultados retornados

        Returns:
            String formatada com os resultados
        """
        encontrados = []
        nome_lower  = nome.lower()

        for diretorio in DIRS_BUSCA:
            if not diretorio.exists():
                continue
            try:
                for arquivo in diretorio.rglob(f"*{nome}*"):
                    if not arquivo.is_file():
                        continue
                    if extensoes and arquivo.suffix.lower() not in extensoes:
                        continue
                    encontrados.append(str(arquivo))
                    if len(encontrados) >= max_resultados:
                        break
            except PermissionError:
                continue
            if len(encontrados) >= max_resultados:
                break

        if not encontrados:
            return f"Nenhum arquivo encontrado com '{nome}'."
        if len(encontrados) == 1:
            return f"Encontrei: {encontrados[0]}"

        lista = "\n".join(f"  • {f}" for f in encontrados)
        return f"Encontrei {len(encontrados)} arquivo(s):\n{lista}"

    def abrir_arquivo(self, caminho: str) -> bool:
        """Abre um arquivo com o programa padrão do sistema."""
        try:
            if WINDOWS:
                os.startfile(caminho)
            elif MACOS:
                subprocess.Popen(["open", caminho])
            else:
                subprocess.Popen(["xdg-open", caminho])
            return True
        except Exception as e:
            log.error(f"[CMD] Erro ao abrir arquivo: {e}")
            return False

    def screenshot(self) -> str | None:
        """Tira um screenshot e salva em Downloads."""
        destino = str(Path.home() / "Downloads" / "screenshot.png")
        try:
            if WINDOWS:
                import ctypes
                # Usa PowerShell para screenshot
                ps  = f'Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::PrimaryScreen | Out-Null; $b=[System.Drawing.Bitmap]::new([System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width,[System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height); $g=[System.Drawing.Graphics]::FromImage($b); $g.CopyFromScreen(0,0,0,0,$b.Size); $b.Save("{destino}")'
                subprocess.run(["powershell", "-Command", ps], capture_output=True)
            elif MACOS:
                subprocess.run(["screencapture", "-x", destino])
            else:
                subprocess.run(["scrot", destino])
            log.info(f"[CMD] Screenshot salvo: {destino}")
            return destino
        except Exception as e:
            log.warning(f"[CMD] Screenshot falhou: {e}")
            return None

    def volume(self, nivel: int):
        """Define o volume do sistema (0-100)."""
        nivel = max(0, min(100, nivel))
        try:
            if WINDOWS:
                # Usa nircmd se disponível, senão PowerShell
                resultado = _executar(["nircmd", "setsysvolume", str(int(nivel * 655.35))])
                if not resultado:
                    ps = f"[audio.AudioEndpointVolume]::FromSoundcard | Out-Null"
                    subprocess.run(["powershell", f"$obj=New-Object -COM WScript.Shell;$obj.SendKeys([char]173)", ])
            elif LINUX:
                subprocess.run(["amixer", "-q", "sset", "Master", f"{nivel}%"])
            log.info(f"[CMD] Volume definido: {nivel}%")
        except Exception as e:
            log.warning(f"[CMD] Erro ao ajustar volume: {e}")
