# APOLO — Knowledge Base Completo
> Documento para exportar conhecimento do projeto a outras IAs ou desenvolvedores.
> Versão do documento: 1.0 | Projeto: APOLO v1.0.0-beta.1

---

## 1. IDENTIDADE DO PROJETO

**Nome completo:** APOLO — Algoritmo de Processamento Operado por Lógica Operacional
**Versão atual:** Beta 1 (v1.0.0-beta.1)
**Linguagem:** Python 3.10+
**Paradigma:** Offline-first, modular, local
**Objetivo:** Assistente pessoal local tipo Jarvis — voz, memória, comandos, IA
**Motor de IA:** Gemma 4 via Ollama (local, sem internet para o LLM)
**Criador:** Projeto solo em desenvolvimento ativo

---

## 2. ESTRUTURA DE PASTAS

```
apolo/
├── main.py                  # Entry point modo terminal
├── main_gui.py              # Entry point modo gráfico
├── setup.py                 # Instalador interativo (7 passos)
├── config.py                # Configurações globais (fonte da verdade)
├── requirements.txt         # Dependências pip obrigatórias
├── .env                     # Chaves de API (NUNCA no GitHub)
├── .env.example             # Template do .env para distribuição
├── .gitignore               # Bloqueia .env, data/, models/, __pycache__
│
├── config/                  # Pacote config (resolve conflito com config.py)
│   ├── __init__.py          # Re-exporta tudo de config.py via importlib
│   └── voice_config.json    # Config de voz em JSON
│
├── core/                    # Núcleo do sistema
│   ├── dispatcher.py        # Pipeline central — 9 camadas de processamento
│   ├── llm_engine.py        # Interface Gemma 4 via Ollama (import lazy)
│   ├── context_manager.py   # Histórico de conversa + escrita atômica JSON
│   ├── status.py            # Estados globais singleton (idle/ouvindo/etc)
│   ├── online_mode.py       # Modo online ativável (DuckDuckGo sem API key)
│   └── version.py           # Versão interna get_version() → "Beta 1"
│
├── memory/                  # Sistema de memória (4 camadas)
│   ├── vector_store.py      # Banco vetorial (FAISS > ChromaDB > InMemory)
│   ├── long_term.py         # SQLite — fatos e preferências persistentes
│   ├── context_memory.py    # TF-IDF + decay temporal + boost por acesso
│   ├── learning.py          # Aprendizado por feedback (Jaccard similarity)
│   ├── user_profile.py      # Perfil JSON do usuário (nome, cidade, etc)
│   ├── episodic.py          # Histórico de sessões em JSON
│   └── embedder.py          # sentence-transformers singleton (lazy)
│
├── agents/                  # Tomada de decisão
│   ├── intent_parser.py     # Classifica intenção por regex (14 tipos)
│   ├── planner.py           # Executa ação para cada intenção
│   ├── scheduler.py         # Lembretes (APScheduler ou fallback threading)
│   ├── routines.py          # Rotinas automáticas (bom dia, modo estudo)
│   └── dev_mode.py          # Assistente de código (gerar/explicar/revisar)
│
├── commands/                # Execução no sistema operacional
│   ├── system_commands.py   # Abrir apps + buscar arquivos (Win/Lin/Mac)
│   ├── web_commands.py      # Abrir sites + tocar_no_spotify()
│   ├── app_commands.py      # AppCommands singleton (YouTube, Discord, etc)
│   └── custom_commands.py   # Frases personalizadas → respostas fixas
│
├── tools/                   # Ferramentas externas
│   ├── weather.py           # Clima via Open-Meteo (sem API key)
│   ├── calculator.py        # Calculadora segura + conversões de unidade
│   ├── search.py            # Pesquisa real (Wikipedia PT + DuckDuckGo)
│   └── youtube_music.py     # Toca música via YouTube Data API v3
│
├── voice/                   # Sistema de voz
│   ├── stt.py               # STT com faster-whisper (offline)
│   ├── tts.py               # TTS: Piper > Coqui > pyttsx3 (auto-detect)
│   ├── wake_word.py         # Wake word: SR+Google > Whisper > texto
│   ├── listener.py          # Escuta contínua após wake word
│   ├── feedback.py          # UX: beep + barra áudio + spinner + status
│   ├── audio_visualizer.py  # Barra ASCII tempo real no terminal
│   └── audio_capture.py     # Captura com VAD (detecção de silêncio)
│
├── ui/                      # Interface gráfica
│   └── interface.py         # Tkinter Canvas 100% — esfera de partículas 3D
│
└── utils/                   # Utilitários
    ├── logger.py             # Logger colorido centralizado
    ├── helpers.py            # Funções auxiliares gerais
    ├── time_utils.py         # Horas com timezone Brasil (zoneinfo)
    └── env_loader.py         # Carregador de .env (sem dependências externas)
```

---

## 3. FLUXO DE PROCESSAMENTO (DISPATCHER)

O `core/dispatcher.py` é o coração. Cada entrada passa por 9 camadas em ordem:

```
Entrada de texto
    │
    ├─ 1. CustomCommands.check()      → frases exatas/similares (prioridade máxima)
    ├─ 2. Learning.retrieve()         → respostas aprendidas por feedback
    ├─ 3. RoutineManager.run()        → "bom dia", "modo estudo", etc
    ├─ 4. GATILHOS_APP                → YouTube, Spotify, Discord (dict de lambdas)
    ├─ 5. DevMode                     → "gera código", "explica código"
    ├─ 6. OnlineMode                  → "ativa modo online", busca web
    ├─ 7. _checar_comando_memoria()   → "me chamo", "lembre que", "moro em"
    ├─ 8. IntentParser → Planner      → comandos de sistema (regex)
    └─ 9. LLMEngine.gerar()           → Gemma 4 com contexto de memória
```

**Proteção anti-duplicata:** cooldown de 1.5s no dispatcher. Mesmo texto em menos de 1.5s é ignorado silenciosamente.

---

## 4. INTENÇÕES RECONHECIDAS (IntentParser)

| Tipo | Exemplos de frase |
|---|---|
| `abrir_site` | "abre o youtube", "vai no instagram", "abrir chatgpt" |
| `abrir_app` | "abre o chrome", "inicia o vscode", "executa o spotify" |
| `buscar_web` | "pesquisa no google python", "googla receita de bolo" |
| `hora_data` | "que horas são", "que hora é", "qual a hr", "quantas horas", "que dia é hoje" |
| `lembrete` | "me lembra de estudar às 18h", "me avisa para tomar remédio" |
| `buscar_arquivo` | "procura arquivo relatorio", "onde está o arquivo config" |
| `clima` | "como está o clima em SP", "vai chover", "temperatura agora" |
| `identidade` | "o que você faz", "quem é o apolo", "qual sua função" |
| `layout` | "layout", "painel", "mostra o status" |
| `tocar_musica` | "toca bohemian rhapsody", "quero ouvir jazz", "play lofi" |
| `pesquisar_internet` | "pesquise na internet capital do brasil", "busque na web python" |
| `limpar` | "limpar histórico", "nova conversa", "esquece tudo" |
| `sair` | "sair apolo", "tchau", "encerra o apolo" |

---

## 5. SISTEMA DE MEMÓRIA (4 CAMADAS)

### Camada 1 — Vetorial (vector_store.py)
- Backend: FAISS (preferido) > ChromaDB > InMemory
- Embeddings: `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`
- Score mínimo: 0.30 (cosine similarity)
- Uso: armazena conversas e recupera contexto semanticamente relevante

### Camada 2 — Longo Prazo (long_term.py)
- Backend: SQLite (`data/long_term.db`)
- Tabelas: `memories` (chave/valor) e `facts` (triplas sujeito/predicado/objeto)
- Fatos aprendidos automaticamente: nome, cidade, preferências
- Método: `save_fact("usuario", "nome", "João")`

### Camada 3 — Contextual (context_memory.py)
- TF-IDF simples (sem embeddings)
- Decay temporal exponencial (memórias antigas perdem peso)
- Tags automáticas por palavras-chave (preferencia, fato_pessoal, tecnico, etc)
- Limit: 500 memórias (remove as menos relevantes)

### Camada 4 — Aprendizado (learning.py)
- Similaridade de Jaccard entre textos normalizados
- Threshold: 0.65 para match
- `save_feedback(input, correct_output)` → aprende respostas
- `retrieve_learned_response(input)` → retorna resposta aprendida

**Comandos de memória por voz:**
- "me chamo X" → salva nome do usuário
- "moro em X" → salva cidade
- "lembre que X" → salva fato genérico
- "quando eu disser X você responde Y" → ensina resposta customizada

---

## 6. SISTEMA DE VOZ

### STT (Speech-to-Text)
- Motor: `faster-whisper` (offline puro)
- Modelo padrão: `base` (tiny/base/small/medium disponíveis)
- Idioma: `pt` (Portuguese)
- VAD ativo (ignora silêncio)
- Fallback: SpeechRecognition + Google (online, sem chave)

### TTS (Text-to-Speech)
- Auto-detecção: Piper > Coqui > pyttsx3
- **Piper:** voz neural PT-BR, ~50MB, melhor qualidade
- **Coqui:** XTTS-v2, multilíngue, maior download
- **pyttsx3:** voz do sistema, zero latência, sempre disponível
- Thread-safe: speak() pode ser chamado de qualquer thread

### Wake Word
- Auto-detecção de backend: SpeechRecognition+Google > Whisper Tiny > texto stdin
- Palavra padrão: "apolo"
- Cooldown: 2.5s entre ativações
- Variações aceitas: "apolo", "apollo", "ápolo", "apôlo"
- Porcupine (Picovoice) opcional para máxima precisão

### Listener (após wake word)
- `listen_after_wakeword(timeout=5, phrase_limit=5)`
- Escuta 5s após wake word detectada
- Transcreve com Whisper, fallback para SR+Google

---

## 7. INTERFACE GRÁFICA (ui/interface.py)

- **Biblioteca:** tkinter Canvas 100% (zero Labels/Frames/Buttons padrão)
- **Dimensões:** 460×700px, não redimensionável
- **Estética:** deep-space, fundo #000000, tipografia Consolas monospace

### Esfera de partículas
- Grade 26×34 = 884 pontos projetados em esfera 3D
- Gradiente: azul `#5588ff` (topo) → roxo `#cc33ff` (base)
- 3 funções seno sobrepostas para ondulação orgânica
- Rotação lenta no eixo Y (phi_offset = t * 0.17)
- Deformação proporcional ao nível de áudio (até 30px extra)
- Projeção: perspectiva com FOV=880

### Estados visuais da esfera
| Estado | Glow Color | Quando |
|---|---|---|
| idle | `#0a0820` | Em repouso |
| ouvindo | `#0a1870` | Microfone ativo |
| processando | `#1a0050` | LLM calculando |
| respondendo | `#0a1880` | TTS falando |

### Componentes do Canvas
- Título "APOLO" com efeito glow 3 camadas
- Status pill animado com ponto piscante
- Linha decorativa com losango central
- Painel glassmorphism simulado (sombra difusa + borda brilhante)
- Botão mic circular com anéis pulsantes quando ativo
- Input de texto customizado com cursor piscante real
- Botão SEND desenhado como cápsula arredondada

---

## 8. COMANDOS ESPECIAIS DO SISTEMA

O dispatcher trata strings especiais retornadas pelo planner:

| String | Ação no main.py / interface.py |
|---|---|
| `__SAIR__` | Encerra o APOLO |
| `__LIMPAR__` | Limpa o histórico de conversa |
| `__LAYOUT__` | Exibe painel de status no terminal/GUI |

---

## 9. FERRAMENTAS EXTERNAS

### Clima (weather.py)
- API: Open-Meteo (gratuita, sem API key, sem cadastro)
- Cidades BR mapeadas: SP, RJ, BH, Brasília, Curitiba, POA, Salvador, Fortaleza...
- Resposta: temperatura atual, máx/mín, umidade, vento, chuva esperada

### Pesquisa na Internet (search.py)
- Fonte 1: Wikipedia PT-BR REST API (`/api/rest_v1/page/summary/`)
- Fonte 2: DuckDuckGo Instant Answer API
- Fallback: abre Google no navegador
- Retorna: texto em linguagem natural, 2 frases máximo

### YouTube Music (youtube_music.py)
- API: YouTube Data API v3 (chave no .env)
- Busca: `videoCategoryId=10` (música) + `type=video` + `maxResults=1`
- Resultado: abre `youtube.com/watch?v=ID` — toca automaticamente
- Fallback sem API key: abre `music.youtube.com/search?q=...` (não auto-toca)
- Quota: 10.000 requests/dia (gratuito)

### Calculadora (calculator.py)
- eval() restrito (whitelist de funções matemáticas)
- Conversões: temperatura, distância, peso, moeda (aproximada)

---

## 10. CONFIGURAÇÕES (config.py)

```python
OLLAMA_MODEL   = "gemma4:e4b"     # modelo LLM
OLLAMA_BASE_URL = "http://localhost:11434"

STT_ENGINE     = "whisper"         # motor STT
WHISPER_MODEL  = "base"            # tamanho do modelo Whisper
STT_LANGUAGE   = "pt"

TTS_ENGINE     = "pyttsx3"         # motor TTS (piper/coqui/pyttsx3)
TTS_RATE       = 175               # velocidade fala
TTS_VOLUME     = 1.0

WAKE_WORD_ENABLED = False          # True requer pvporcupine + key
WAKE_WORD         = "apolo"
PORCUPINE_KEY     = ""

AUDIO_RATE        = 16000
AUDIO_CHANNELS    = 1
AUDIO_CHUNK       = 1024
LISTEN_SECONDS    = 6

EMBEDDING_MODEL = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
MEMORY_TOP_K    = 4
MAX_HISTORY_TURNS = 10

APOLO_NAME   = "APOLO"
THINK_MODE   = False               # True = Gemma raciocina antes de responder
VECTOR_BACKEND = "auto"            # faiss / chroma / auto
```

---

## 11. VARIÁVEIS DE AMBIENTE (.env)

```env
YOUTUBE_API_KEY=sua_chave_aqui
```

- Arquivo `.env` fica na raiz do projeto
- **Nunca commitado** (`.gitignore` bloqueia `.env`)
- `.env.example` é commitado como template
- Leitura via `utils/env_loader.py` (stdlib pura, sem python-dotenv)
- `env.get("YOUTUBE_API_KEY")` → valor ou None
- `env.require("YOUTUBE_API_KEY")` → valor ou ValueError

---

## 12. DEPENDÊNCIAS

### Obrigatórias (requirements.txt)
| Pacote | Uso |
|---|---|
| `ollama>=0.4.0` | SDK Python para o Ollama |
| `faster-whisper>=1.0.0` | STT offline |
| `SpeechRecognition>=3.10.0` | STT online (fallback) + wake word |
| `pyttsx3>=2.90` | TTS do sistema |
| `pyaudio>=0.2.14` | Captura de microfone |
| `sentence-transformers>=3.0.0` | Embeddings para memória vetorial |
| `faiss-cpu>=1.7.4` | Banco vetorial rápido |
| `apscheduler>=3.10.0` | Lembretes agendados |
| `rich>=13.0.0` | Terminal colorido |
| `colorama>=0.4.6` | Cores no Windows |
| `requests>=2.31.0` | HTTP |
| `python-dateutil>=2.8.0` | Parsing de datas |
| `numpy>=1.24.0` | Operações numéricas |

### Opcionais (instalados pelo setup.py)
| Pacote | Uso |
|---|---|
| `piper-tts` | Voz neural PT-BR offline (~50MB modelo) |
| `openwakeword` | Wake word open-source sem conta |
| `chromadb` | Banco vetorial alternativo ao FAISS |

### PyAudio no Windows — estratégia especial
1. `pip install pyaudio` direto (funciona Python 3.12+)
2. `pipwin install pyaudio` (wheels pré-compilados)
3. `audioop-lts` como fallback parcial

---

## 13. COMO EXECUTAR

```bash
# Instalação completa (interativa)
python setup.py

# Ollama (terminal separado, sempre ativo)
ollama serve

# Baixar modelo (uma vez)
ollama pull gemma4:e4b

# Interface gráfica (modo principal)
python main_gui.py

# Interface gráfica sem Ollama (só o visual)
python main_gui.py --demo

# Modo terminal
python main.py

# Modo terminal com voz
python main.py --voz

# Modo terminal com logs detalhados
python main.py --debug
```

---

## 14. BUGS CONHECIDOS E SOLUÇÕES APLICADAS

| Bug | Causa | Solução aplicada |
|---|---|---|
| `AttributeError: config has no attribute APOLO_NAME` | Pasta `config/` tem prioridade sobre `config.py` | `config/__init__.py` re-exporta tudo de `config.py` via importlib |
| `NameError: Optional is not defined` | Import no final do arquivo (após o uso) | Movido `from typing import Optional` para o topo |
| `TclError: unknown option -letterSpacing` | Parâmetro CSS inválido no tkinter | Removido; tkinter não suporta letterSpacing |
| Comando executa 2 vezes | Wake word + loop principal processam juntos | Cooldown de 1.5s no dispatcher (`_ultimo_texto` + `_ultimo_ts`) |
| JSON corrompido no histórico | Escrita não-atômica | Escrita via `NamedTemporaryFile` + `os.replace()` |
| `_Feedback object has no attribute on_routine` | Método não existia | Adicionado `on_routine()` à classe `_Feedback` |
| Spotify abre no browser em vez do app | "spotify" estava em `sites_conhecidos` no planner | Removido da lista; vai para `SystemCommands.abrir_app()` |
| `apscheduler` não instalado trava o boot | Import no topo sem fallback | Import condicional + `_SchedulerSimples` com threading |
| `ollama` não instalado trava o boot | Import no topo | Import lazy via `_get_ollama()` |
| Setup instala nada (tudo FALHOU) | `shell=True` + `capture_output` no Windows com espaço no path | Substituído por lista de args sem `shell=True` |

---

## 15. SISTEMA DE STATUS

Singleton em `core/status.py`:

```python
from core.status import Status
Status.set("ouvindo")   # idle | aguardando | ouvindo | processando | respondendo
Status.get()            # → "ouvindo"
Status.is_("ouvindo")   # → True
Status.get_ui()         # → ("🎤", "Ouvindo...")
Status.on_change(fn)    # registra listener
```

---

## 16. ROTINAS PREDEFINIDAS

| Nome | Ações |
|---|---|
| "bom dia" | Hora atual + clima + frase motivacional (LLM) |
| "boa noite" | Hora atual + saudação (LLM) |
| "modo estudo" | Abre VSCode + Spotify Focus no browser |
| "modo trabalho" | Abre VSCode + Gmail |
| "notícias" | LLM resumindo notícias do dia |

Registrar nova rotina:
```python
from agents.routines import RoutineManager
RoutineManager.register_routine("café", [
    {"type": "falar", "params": {"text": "Hora do café!"}},
    {"type": "abrir_url", "params": {"url": "https://youtube.com", "label": "YouTube"}},
])
```

---

## 17. COMANDOS PERSONALIZADOS

```python
from commands.custom_commands import CustomCommands

# Adicionar frase → resposta
CustomCommands.add("acorda criança papai chegou",
                   "Bem-vindo senhor! A cerimônia foi um sucesso!")

# Verificar (chamado automaticamente pelo dispatcher camada 1)
resposta = CustomCommands.check("acorda criança papai chegou")

# Listar todos
CustomCommands.list_all()
```

Embutidos por padrão:
- "acorda criança papai chegou" → "Bem-vindo senhor!..."
- "modo silencioso" → ativa modo silencioso
- "qual sua versão" → retorna versão atual
- "status do sistema" → retorna status atual

---

## 18. VERSÃO E ROADMAP

**Atual:** APOLO v1.0.0-beta.1 ("Beta 1")

Histórico de estágios:
- **pre-alpha 1** → base funcional (LLM + terminal)
- **pre-alpha 2** → voz + memória + agentes
- **v2.5** → wake word local + feedback visual + comandos de sites
- **Beta 1** → interface gráfica + esfera de partículas + pesquisa + YouTube API

Próximas features planejadas:
- Integração Google Calendar
- Leitura de e-mails
- Plugin system (pasta `plugins/` já existe, ainda vazia)
- Port para Android (servidor REST no PC + app cliente Flutter)
- Spotify Web API para controle sem abrir browser

---

## 19. CONTEXTO PARA IA ASSISTENTE

Se você é uma IA recebendo este documento para auxiliar no desenvolvimento do APOLO, considere:

1. **Nunca recriar o projeto do zero** — ele já tem +8.000 linhas funcionais
2. **Sempre ler o arquivo antes de editar** — use o conteúdo real, não suposições
3. **Edições cirúrgicas** — modificar apenas o necessário, preservar o resto
4. **Testar sintaxe** — `ast.parse()` em todo arquivo modificado antes de entregar
5. **Sem shell=True no Windows** — usar lista de argumentos no subprocess
6. **Sem letterSpacing no tkinter** — não existe esse parâmetro
7. **config/ vs config.py** — o pacote `config/` re-exporta `config.py` via importlib
8. **Chaves de API** — sempre no `.env`, nunca em código-fonte `.py`
9. **Encoding** — arquivos têm emojis e acentos; usar `encoding="utf-8"` sempre
10. **Import lazy** — ollama e apscheduler usam import lazy para não travar o boot

**Arquivos mais críticos (mexer com cuidado):**
- `core/dispatcher.py` — qualquer mudança afeta o fluxo inteiro
- `config.py` + `config/__init__.py` — par inseparável
- `agents/intent_parser.py` — ordem dos padrões importa (primeiro match vence)
- `ui/interface.py` — 100% canvas, zero widgets tk, encoding sensível

---

*Documento gerado em: 2026 | Projeto APOLO Beta 1*
