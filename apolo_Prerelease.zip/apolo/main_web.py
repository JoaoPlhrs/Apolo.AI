"""
main_web.py — Ponto de entrada da interface web do APOLO

Uso:
    python main_web.py          → abre o navegador com a interface
    python main_web.py --demo   → modo demo (sem Ollama, só visual)
    python main_web.py --port 8765

O que faz:
    1. Sobe um servidor HTTP (porta+1) que serve o apolo_4.html
    2. Sobe um WebSocket na porta configurada
    3. Conecta ao Dispatcher do APOLO (todos os comandos disponíveis)
    4. Sites (YouTube, Instagram, etc.) → abre no browser do usuário via open_url
    5. Apps locais (Spotify, Discord, VS Code...) → abre via subprocess no servidor
    6. Abre o navegador automaticamente
"""

import sys
import os
import asyncio
import json
import threading
import time
import webbrowser
import argparse
import logging
import re
from http.server import HTTPServer, SimpleHTTPRequestHandler

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

try:
    import websockets
except ImportError:
    print("\n  ERRO: websockets não instalado.\n  Execute: pip install websockets psutil\n")
    sys.exit(1)

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    import pynvml
    pynvml.nvmlInit()
    _nvml_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    HAS_NVML = True
except Exception:
    HAS_NVML = False

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [APOLO] %(message)s",
                    datefmt="%H:%M:%S")
log = logging.getLogger("apolo")

DEMO_MODE      = "--demo" in sys.argv
dispatcher     = None
_custom_prompt = ""   # prompt personalizado enviado pelo frontend
_clientes: set = set()
_net_prev    = None
_net_ts_prev = None

# URLs que devem ser abertas no browser do usuário (não no servidor)
_URL_SITES = {
    "youtube.com", "youtu.be", "instagram.com", "chat.openai.com", "github.com",
    "mail.google.com", "google.com", "open.spotify.com", "web.whatsapp.com",
    "discord.com", "web.telegram.org", "twitter.com", "linkedin.com",
    "reddit.com", "notion.so", "trello.com",
}


# ─── Monitor ──────────────────────────────────────────────────────────────────

def _monitor_data() -> dict:
    global _net_prev, _net_ts_prev
    data = {"type": "monitor"}
    if not HAS_PSUTIL:
        return data

    vm = psutil.virtual_memory()
    data["ram"]          = round(vm.percent, 1)
    data["ram_used_gb"]  = round(vm.used  / 1024**3, 1)
    data["ram_total_gb"] = round(vm.total / 1024**3, 1)
    data["cpu"]          = round(psutil.cpu_percent(interval=None), 1)

    if HAS_NVML:
        try:
            data["gpu_temp"]      = pynvml.nvmlDeviceGetTemperature(_nvml_handle, pynvml.NVML_TEMPERATURE_GPU)
            data["gpu_usage"]     = pynvml.nvmlDeviceGetUtilizationRates(_nvml_handle).gpu
            mem_info              = pynvml.nvmlDeviceGetMemoryInfo(_nvml_handle)
            data["vram_used_gb"]  = round(mem_info.used  / 1024**3, 1)
            data["vram_total_gb"] = round(mem_info.total / 1024**3, 1)
        except Exception:
            pass

    # Top 3 processos por CPU
    try:
        procs = sorted(
            [p.info for p in psutil.process_iter(['name','cpu_percent']) if p.info['cpu_percent'] and p.info['cpu_percent'] > 0.1],
            key=lambda x: x['cpu_percent'], reverse=True
        )[:3]
        data["processes"] = [{"name": p["name"][:16], "cpu": round(p["cpu_percent"],1)} for p in procs]
    except Exception:
        pass

    net = psutil.net_io_counters()
    now = time.time()
    if _net_prev and _net_ts_prev:
        dt = now - _net_ts_prev
        if dt > 0:
            data["net_up_mb"]   = round((net.bytes_sent - _net_prev.bytes_sent) / dt / 1024 / 1024, 2)
            data["net_down_mb"] = round((net.bytes_recv - _net_prev.bytes_recv) / dt / 1024 / 1024, 2)
    _net_prev    = net
    _net_ts_prev = now
    return data


async def _monitor_loop():
    if HAS_PSUTIL:
        psutil.cpu_percent(interval=None)
    await asyncio.sleep(1.0)
    while True:
        if _clientes:
            payload = json.dumps(_monitor_data())
            mortos = set()
            for ws in _clientes.copy():
                try:
                    await ws.send(payload)
                except Exception:
                    mortos.add(ws)
            _clientes -= mortos
        await asyncio.sleep(1.5)


# ─── Dispatcher ───────────────────────────────────────────────────────────────

def _carregar_dispatcher():
    global dispatcher
    try:
        log.info("Carregando APOLO Dispatcher...")
        from core.dispatcher import Dispatcher
        dispatcher = Dispatcher()
        log.info("✅ Dispatcher pronto!")
        # Pré-aquece o modelo para eliminar latência da primeira resposta
        if hasattr(dispatcher, 'llm') and hasattr(dispatcher.llm, 'pre_aquecer'):
            dispatcher.llm.pre_aquecer()
    except ConnectionError:
        log.error("❌ Ollama offline — execute: ollama serve")
    except Exception as e:
        log.error(f"❌ Erro: {e}")


# ─── Intercepta URLs para abrir no browser do usuário ────────────────────────

def _extrair_url_aberta(texto: str) -> str | None:
    """
    Quando o webbrowser.open() já foi chamado pelo dispatcher (para sites),
    precisamos também mandar a URL pro frontend abrir no browser do usuário.
    Extrai a URL da resposta de texto se for uma abertura de site.
    """
    urls = re.findall(r'https?://[^\s\'"]+', texto)
    if not urls:
        return None
    url = urls[0].rstrip(".,)")
    # Só manda pro frontend se for um site (não app local)
    for dominio in _URL_SITES:
        if dominio in url:
            return url
    return None


# ─── WebSocket handler ────────────────────────────────────────────────────────

async def _handler(websocket):
    _clientes.add(websocket)
    log.info("🔗 Interface conectada")
    try:
        async for raw in websocket:
            try:
                msg = json.loads(raw)
            except Exception:
                continue

            # Troca de provider/modelo em runtime
            if msg.get("type") == "set_model":
                provider = msg.get("provider", "ollama").lower()
                model    = msg.get("model", None)
                try:
                    from core import llm_engine as _lm
                    _lm.set_provider(provider, model)
                    info = _lm.get_provider_info()
                    await websocket.send(json.dumps({
                        "type":     "model_changed",
                        "provider": info["provider"],
                        "model":    info["model"],
                        "label":    f"{info['provider'].upper()} · {info['model']}",
                    }))
                    log.info(f"Modelo trocado: {provider} / {model}")
                except Exception as e:
                    await websocket.send(json.dumps({"type": "error", "text": str(e)}))
                continue

            # Lista modelos Ollama disponíveis
            if msg.get("type") == "list_models":
                try:
                    from core import llm_engine as _lm
                    info = _lm.get_provider_info()
                    await websocket.send(json.dumps({
                        "type":      "models_list",
                        "available": info["available"],
                        "current":   {"provider": info["provider"], "model": info["model"]},
                    }))
                except Exception as e:
                    await websocket.send(json.dumps({"type": "error", "text": str(e)}))
                continue

            # Troca de personalidade
            if msg.get("type") == "set_personality":
                name   = msg.get("personality")   # "assistente"|"expert"|"amigo"|"custom"|None
                custom = msg.get("custom_text", None)
                try:
                    from core.llm_engine import set_personality
                    set_personality(name, custom)
                    label = {"assistente":"ASSISTENTE","expert":"EXPERT","amigo":"MELHOR AMIGO","custom":"PERSONALIZADO"}.get(name or "", "PADRÃO")
                    await websocket.send(json.dumps({
                        "type":  "personality_changed",
                        "name":  name or "default",
                        "label": label,
                    }))
                    log.info(f"Personalidade: {label}")
                except Exception as e:
                    await websocket.send(json.dumps({"type":"error","text":str(e)}))
                continue

            # Prompt customizado enviado pelas configurações
            if msg.get("type") == "set_prompt":
                global _custom_prompt
                _custom_prompt = msg.get("prompt", "").strip()
                nome    = msg.get("username", "")
                apolo_n = msg.get("apoloname", "")
                # Injeta no dispatcher/llm_engine se disponível
                if dispatcher and hasattr(dispatcher, 'llm'):
                    from core import llm_engine as _lm
                    partes = []
                    if _custom_prompt:
                        partes.append(_custom_prompt)
                    if nome:
                        partes.append(f"O nome do usuário é {nome}.")
                    if apolo_n:
                        partes.append(f"Seu nome é {apolo_n}.")
                    if partes:
                        _lm.SYSTEM_PROMPT = _lm.SYSTEM_PROMPT.split("\n\n[PERSONALIZAÇÃO")[0]
                        _lm.SYSTEM_PROMPT += f"\n\n[PERSONALIZAÇÃO DO USUÁRIO]\n" + "\n".join(partes)
                log.info(f"Prompt customizado atualizado: {_custom_prompt[:60]}...")
                continue

            if msg.get("type") != "message":
                continue

            texto  = msg.get("text", "").strip()
            attach = msg.get("attach")  # {type, mime, base64, text, name}

            if not texto and not attach:
                continue

            log.info(f"💬 {texto[:60]}" + (f" [+{attach['type']}]" if attach else ""))

            if DEMO_MODE or not dispatcher:
                resposta = _demo(texto or "Olá!")
            elif attach:
                # Anexo — usa Gemini Vision/Document
                resposta = await _processar_anexo(texto, attach)
            else:
                resposta = await _processar(texto)

            # Envia a resposta de texto
            await websocket.send(json.dumps({"type": "response", "text": resposta}))

            # Se abriu um site, manda também open_url pro browser do usuário
            url = _extrair_url_aberta(resposta)
            if url:
                await websocket.send(json.dumps({"type": "open_url", "url": url}))
                log.info(f"🌐 Abrindo no browser do usuário: {url}")

    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        _clientes.discard(websocket)


def _demo(texto: str) -> str:
    t = texto.lower()
    if any(x in t for x in ("olá", "oi")):
        return "Olá! Modo demo ativo. Inicie o Ollama para respostas reais."
    if "hora" in t:
        return f"São {time.strftime('%H:%M:%S')} (modo demo)."
    return "Modo demo. Execute 'ollama serve' e reinicie para o APOLO completo."


async def _processar(texto: str) -> str:
    loop = asyncio.get_event_loop()
    resultado = {}
    evento = threading.Event()

    def _run():
        try:
            resultado["r"] = dispatcher.processar(texto)
        except Exception as e:
            resultado["r"] = f"Erro: {str(e)[:100]}"
        finally:
            evento.set()

    threading.Thread(target=_run, daemon=True).start()
    await loop.run_in_executor(None, evento.wait)
    return resultado.get("r", "")


async def _processar_anexo(texto: str, attach: dict) -> str:
    """Processa anexo (imagem/pdf/arquivo) via Gemini Vision."""
    loop = asyncio.get_event_loop()
    resultado = {}
    evento = threading.Event()

    def _run():
        try:
            from core.llm_engine import gerar_com_anexo, set_provider
            # Garante que Gemini está ativo
            set_provider("gemini", "gemini-2.0-flash")
            mem = []
            if dispatcher and hasattr(dispatcher, 'memory'):
                try:
                    mem = dispatcher.memory.buscar(texto or "imagem", k=3)
                except Exception:
                    pass
            resultado["r"] = gerar_com_anexo(texto, attach, mem)
        except Exception as e:
            log.error(f"[Anexo] {e}")
            resultado["r"] = f"Erro ao analisar o anexo: {str(e)[:120]}"
        finally:
            evento.set()

    threading.Thread(target=_run, daemon=True).start()
    await loop.run_in_executor(None, evento.wait)
    return resultado.get("r", "")


# ─── HTTP server ──────────────────────────────────────────────────────────────

class _Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=os.path.join(ROOT, "ui"), **kwargs)

    def log_message(self, *args):
        pass


def _iniciar_http(http_port: int):
    HTTPServer(("localhost", http_port), _Handler).serve_forever()


# ─── Main ─────────────────────────────────────────────────────────────────────

async def main(port: int):
    log.info(f"🚀 APOLO Web | demo={DEMO_MODE} | psutil={HAS_PSUTIL} | GPU={HAS_NVML}")

    if not DEMO_MODE:
        threading.Thread(target=_carregar_dispatcher, daemon=True).start()

    http_port = port + 1
    threading.Thread(target=_iniciar_http, args=(http_port,), daemon=True).start()

    asyncio.create_task(_monitor_loop())

    url = f"http://localhost:{http_port}/apolo_4.html"
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    log.info(f"🌐 Interface: {url}")

    async with websockets.serve(_handler, "localhost", port):
        log.info(f"✅ WebSocket pronto em ws://localhost:{port}")
        await asyncio.Future()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    if args.demo:
        DEMO_MODE = True

    try:
        asyncio.run(main(args.port))
    except KeyboardInterrupt:
        log.info("🛑 Encerrado.")
