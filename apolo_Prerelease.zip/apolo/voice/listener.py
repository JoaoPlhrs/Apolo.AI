"""
voice/listener.py — Escuta contínua após detecção de wake word

Depois que o APOLO detecta "Apolo", este módulo assume e captura
o restante da fala do usuário na mesma frase, sem precisar que o
usuário fale novamente.

Dependência:
    pip install SpeechRecognition pyaudio

Uso standalone:
    from voice.listener import listen_after_wakeword
    texto = listen_after_wakeword()
    if texto:
        print(f"Você disse: {texto}")
"""

import sys
import time

from utils.logger import log


# ── Configuração ──────────────────────────────────────────────────────────────

TIMEOUT_ESCUTA   = 5   # segundos esperando início de fala
LIMITE_FRASE     = 5   # segundos máximos de fala contínua
IDIOMA           = "pt-BR"


# ── Função principal ──────────────────────────────────────────────────────────

def listen_after_wakeword(
    timeout: int = TIMEOUT_ESCUTA,
    phrase_limit: int = LIMITE_FRASE,
    idioma: str = IDIOMA,
) -> str | None:
    """
    Escuta o microfone por até `timeout` segundos e transcreve a fala.

    Chamada imediatamente após a wake word ser detectada.
    Usa SpeechRecognition com Google STT (gratuito, sem chave).
    Se não houver internet, tenta Whisper como fallback.

    Args:
        timeout:      Segundos esperando início de fala antes de desistir.
        phrase_limit: Segundos máximos de fala a capturar.
        idioma:       Código de idioma para o reconhecedor (padrão: "pt-BR").

    Returns:
        Texto transcrito (str) ou None se não houver fala detectável.

    Saída no terminal:
        Sucesso → imprime  'Você disse: <texto>'
        Falha   → imprime  'Não entendi, pode repetir?'
    """
    try:
        import speech_recognition as sr
    except ImportError:
        log.error("[Listener] SpeechRecognition não instalado. Execute: pip install SpeechRecognition pyaudio")
        return None

    recognizer = sr.Recognizer()
    recognizer.pause_threshold = 0.8   # pausa de 0.8s encerra a frase

    try:
        microfone = sr.Microphone(sample_rate=16000)
    except Exception as e:
        log.error(f"[Listener] Microfone indisponível: {e}")
        return None

    # ── Captura ───────────────────────────────────────────────────────────────
    log.info(f"[Listener] Escutando por até {timeout}s...")

    try:
        with microfone as source:
            # Ajuste rápido de ruído ambiente (não bloqueia por muito tempo)
            recognizer.adjust_for_ambient_noise(source, duration=0.3)

            try:
                audio = recognizer.listen(
                    source,
                    timeout          = timeout,      # espera início de fala
                    phrase_time_limit= phrase_limit, # limite máximo de fala
                )
            except sr.WaitTimeoutError:
                # Ninguém falou dentro do timeout — falha silenciosa
                log.debug("[Listener] Timeout: nenhuma fala detectada.")
                _imprimir_falha()
                return None

    except Exception as e:
        log.warning(f"[Listener] Erro ao acessar microfone: {e}")
        return None

    # ── Transcrição ───────────────────────────────────────────────────────────
    texto = _transcrever(recognizer, audio, idioma)

    if texto:
        _imprimir_sucesso(texto)
        return texto
    else:
        # Fallback para Whisper se SR/Google falhou
        texto = _fallback_whisper(audio)
        if texto:
            _imprimir_sucesso(texto)
            return texto
        _imprimir_falha()
        return None


# ── Transcrição com Google (SpeechRecognition) ────────────────────────────────

def _transcrever(recognizer, audio, idioma: str) -> str | None:
    """Tenta transcrever com Google STT. Retorna texto ou None."""
    try:
        import speech_recognition as sr
        texto = recognizer.recognize_google(audio, language=idioma).strip()
        log.debug(f"[Listener/Google] '{texto}'")
        return texto if texto else None
    except Exception:
        # UnknownValueError → áudio sem fala clara
        # RequestError      → sem internet
        return None


# ── Fallback: Whisper ─────────────────────────────────────────────────────────

def _fallback_whisper(audio) -> str | None:
    """
    Tenta transcrever com Whisper Tiny quando o Google falha.
    Útil quando não há internet ou o áudio não foi reconhecido.
    """
    try:
        import tempfile, os, wave
        from faster_whisper import WhisperModel

        # Salva o áudio capturado em arquivo WAV temporário
        wav_bytes = audio.get_wav_data()
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(wav_bytes)
            path = f.name

        try:
            modelo = WhisperModel("tiny", device="cpu", compute_type="int8")
            segs, _ = modelo.transcribe(path, language="pt", beam_size=1, vad_filter=True)
            texto   = " ".join(s.text for s in segs).strip()
            log.debug(f"[Listener/Whisper] '{texto}'")
            return texto if texto else None
        finally:
            try:
                os.unlink(path)
            except Exception:
                pass

    except ImportError:
        # faster-whisper não instalado — sem fallback disponível
        return None
    except Exception as e:
        log.debug(f"[Listener/Whisper] Fallback falhou: {e}")
        return None


# ── Saída no terminal ─────────────────────────────────────────────────────────

def _imprimir_sucesso(texto: str):
    """Exibe 'Você disse: <texto>' com destaque no terminal."""
    _c = _cor()
    print(f"  {_c['dim']}Você disse:{_c['reset']} {_c['bold']}\"{texto}\"{_c['reset']}")


def _imprimir_falha():
    """Exibe mensagem de falha no terminal."""
    _c = _cor()
    print(f"  {_c['dim']}Não entendi, pode repetir?{_c['reset']}")


def _cor() -> dict:
    """Retorna dict de sequências ANSI se o terminal suportar, ou strings vazias."""
    suporta = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
    if suporta:
        return {"bold": "\033[1m", "dim": "\033[2m", "reset": "\033[0m"}
    return {"bold": "", "dim": "", "reset": ""}
