"""voice/audio_capture.py — Captura de áudio com detecção de silêncio (VAD simples)"""

import audioop
import wave
import tempfile
import os
import config
from utils.logger import log


class AudioCapture:
    """
    Captura áudio do microfone com detecção automática de fala.
    Para gravação quando detecta silêncio prolongado.
    Mais natural que gravar por tempo fixo.
    """

    LIMIAR_SILENCIO = 500       # amplitude RMS mínima para considerar fala
    FRAMES_SILENCIO = 30        # chunks silenciosos antes de parar (~1.5s)
    FRAMES_MINIMOS  = 10        # chunks mínimos para aceitar (evita lixo)
    FRAMES_MAX      = 300       # máximo de chunks (~15s)

    def __init__(self):
        self.pa = None

    def _init_pa(self):
        if self.pa is None:
            import pyaudio
            self.pa = pyaudio.PyAudio()

    def capturar_com_vad(self) -> str | None:
        """
        Captura áudio com VAD (Voice Activity Detection) simples.
        Retorna caminho do arquivo WAV ou None se nenhuma fala detectada.
        """
        self._init_pa()
        import pyaudio

        stream = self.pa.open(
            format            = pyaudio.paInt16,
            channels          = config.AUDIO_CHANNELS,
            rate              = config.AUDIO_RATE,
            input             = True,
            frames_per_buffer = config.AUDIO_CHUNK,
        )

        frames         = []
        silencio_count = 0
        falando        = False
        frames_fala    = 0

        log.info("Aguardando fala...")

        try:
            while len(frames) < self.FRAMES_MAX:
                chunk = stream.read(config.AUDIO_CHUNK, exception_on_overflow=False)
                rms   = audioop.rms(chunk, 2)  # calcula energia do áudio

                if rms > self.LIMIAR_SILENCIO:
                    # Fala detectada
                    if not falando:
                        log.info("Fala iniciada.")
                        falando = True
                    frames.append(chunk)
                    frames_fala    += 1
                    silencio_count  = 0
                else:
                    # Silêncio
                    if falando:
                        frames.append(chunk)  # inclui um pouco de silêncio após fala
                        silencio_count += 1
                        if silencio_count >= self.FRAMES_SILENCIO:
                            log.info("Silêncio detectado, encerrando captura.")
                            break

            if not falando or frames_fala < self.FRAMES_MINIMOS:
                return None

            # Salva em arquivo temporário
            f = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
            with wave.open(f.name, "wb") as wf:
                wf.setnchannels(config.AUDIO_CHANNELS)
                wf.setsampwidth(self.pa.get_sample_size(pyaudio.paInt16))
                wf.setframerate(config.AUDIO_RATE)
                wf.writeframes(b"".join(frames))
            return f.name

        finally:
            stream.stop_stream()
            stream.close()

    def fechar(self):
        if self.pa:
            self.pa.terminate()
