"""voice/stt.py — Speech-to-Text com faster-whisper (offline)"""

import io
import wave
import tempfile
import os
import config
from utils.logger import log


class STTEngine:
    def __init__(self):
        self.modelo  = None
        self.pa      = None
        self._carregar()

    def _carregar(self):
        """Carrega o modelo Whisper (baixado automaticamente na primeira vez)."""
        try:
            from faster_whisper import WhisperModel
            log.info(f"Carregando Whisper '{config.WHISPER_MODEL}'...")
            self.modelo = WhisperModel(
                config.WHISPER_MODEL,
                device       = "cpu",
                compute_type = "int8",       # eficiente em CPU
            )
            log.info("Whisper pronto.")
        except ImportError:
            log.error("faster-whisper não instalado. Execute: pip install faster-whisper")
        except Exception as e:
            log.error(f"Erro ao carregar Whisper: {e}")

    def _init_audio(self):
        """Inicializa PyAudio (lazy, para não travar na importação)."""
        if self.pa is None:
            try:
                import pyaudio
                self.pa = pyaudio.PyAudio()
            except ImportError:
                log.error("pyaudio não instalado. Execute: pip install pyaudio")
                raise

    def escutar(self, segundos: int = None) -> str:
        """
        Captura áudio do microfone e transcreve.
        Retorna o texto transcrito, ou "" em caso de erro.
        """
        if not self.modelo:
            return ""

        segundos = segundos or config.LISTEN_SECONDS
        self._init_audio()

        import pyaudio
        log.info(f"Escutando por {segundos}s...")

        try:
            stream = self.pa.open(
                format            = pyaudio.paInt16,
                channels          = config.AUDIO_CHANNELS,
                rate              = config.AUDIO_RATE,
                input             = True,
                frames_per_buffer = config.AUDIO_CHUNK,
            )

            frames = []
            total  = int(config.AUDIO_RATE / config.AUDIO_CHUNK * segundos)
            for _ in range(total):
                frames.append(stream.read(config.AUDIO_CHUNK, exception_on_overflow=False))

            stream.stop_stream()
            stream.close()

            # Salva em arquivo WAV temporário
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                nome_arquivo = f.name
                with wave.open(f.name, "wb") as wf:
                    wf.setnchannels(config.AUDIO_CHANNELS)
                    wf.setsampwidth(self.pa.get_sample_size(pyaudio.paInt16))
                    wf.setframerate(config.AUDIO_RATE)
                    wf.writeframes(b"".join(frames))

            # Transcreve
            segmentos, info = self.modelo.transcribe(
                nome_arquivo,
                language              = config.STT_LANGUAGE,
                beam_size             = 5,
                vad_filter            = True,   # ignora silêncio
                vad_parameters        = {"min_silence_duration_ms": 300},
            )
            texto = " ".join(s.text for s in segmentos).strip()
            os.unlink(nome_arquivo)

            if texto:
                log.info(f"Transcrito: '{texto}'")
            else:
                log.info("Nenhuma fala detectada.")

            return texto

        except Exception as e:
            log.error(f"Erro na captura de áudio: {e}")
            return ""

    def fechar(self):
        if self.pa:
            self.pa.terminate()
