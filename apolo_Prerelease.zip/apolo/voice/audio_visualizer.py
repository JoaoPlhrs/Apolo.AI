"""
voice/audio_visualizer.py — Barra de áudio ASCII em tempo real (V2.5)

Mostra a intensidade do microfone no terminal durante a escuta.
Sem dependências além de pyaudio e audioop (ambos da stdlib ou já instalados).

Exemplo de saída:
    [████████░░░░░░░░░░░░]  42%   🎤

Uso:
    from voice.audio_visualizer import AudioVisualizer

    viz = AudioVisualizer()
    viz.start()          # inicia exibição em background
    viz.set_level(0.7)   # define nível manualmente (0.0 a 1.0)
    viz.feed_chunk(pcm)  # alimenta com bytes de áudio bruto
    viz.stop()           # para e limpa a linha
"""

import sys
import time
import threading


class AudioVisualizer:
    """
    Barra de áudio ASCII para o terminal.

    Modos de uso:
      1. Manual:  viz.set_level(0.5) — define nível externamente
      2. Auto:    viz.feed_chunk(pcm_bytes) — calcula nível do áudio
      3. Ao vivo: viz.start("pyaudio") — lê microfone diretamente
    """

    # ── Configuração da barra ─────────────────────────────────────
    LARGURA    = 20        # quantidade de caracteres na barra
    CHAR_CHEIO = "█"      # caractere de volume ativo
    CHAR_VAZIO = "░"      # caractere de volume inativo
    ABRE       = "["
    FECHA      = "]"
    FPS        = 20        # atualizações por segundo
    DECAY      = 0.08      # queda de nível por frame (suaviza animação)

    def __init__(self, largura: int = None, cores: bool = True):
        self._largura   = largura or self.LARGURA
        self._nivel     = 0.0       # 0.0 a 1.0
        self._rodando   = False
        self._thread    = None
        self._lock      = threading.Lock()
        self._usar_cores= cores and self._terminal_suporta_cores()
        self._pa_stream = None      # pyaudio stream (modo ao vivo)

    # ── API pública ───────────────────────────────────────────────

    def start(self, modo: str = "manual"):
        """
        Inicia a exibição em background.

        Args:
            modo: "manual"  → use set_level() ou feed_chunk()
                  "pyaudio" → lê microfone automaticamente
        """
        if self._rodando:
            return
        self._rodando = True
        self._thread  = threading.Thread(
            target=self._loop_exibicao,
            daemon=True,
            name="audio_viz",
        )
        self._thread.start()

        if modo == "pyaudio":
            self._iniciar_pyaudio()

    def stop(self):
        """Para a barra e limpa a linha."""
        self._rodando = False

        if self._pa_stream:
            try:
                self._pa_stream.stop_stream()
                self._pa_stream.close()
            except Exception:
                pass
            self._pa_stream = None

        # Limpa a linha do terminal
        espaco = " " * (self._largura + 15)
        sys.stdout.write(f"\r{espaco}\r")
        sys.stdout.flush()

    def set_level(self, nivel: float):
        """Define o nível manualmente (0.0 a 1.0)."""
        with self._lock:
            self._nivel = max(0.0, min(1.0, float(nivel)))

    def feed_chunk(self, pcm_bytes: bytes):
        """
        Alimenta com um chunk de áudio PCM 16-bit e calcula o volume.
        Chamado pelo STT ou pelo loop de captura durante a gravação.
        """
        try:
            import audioop
            rms   = audioop.rms(pcm_bytes, 2)   # energia RMS do chunk
            nivel = min(rms / 6000.0, 1.0)      # normaliza para 0-1
            self.set_level(nivel)
        except Exception:
            pass

    # ── Loop de exibição ──────────────────────────────────────────

    def _loop_exibicao(self):
        intervalo = 1.0 / self.FPS
        while self._rodando:
            with self._lock:
                nivel   = self._nivel
                # Decai suavemente para simular movimento natural
                self._nivel = max(0.0, self._nivel - self.DECAY)

            self._desenhar(nivel)
            time.sleep(intervalo)

    def _desenhar(self, nivel: float):
        """Renderiza a barra ASCII na mesma linha do terminal."""
        n_cheio = int(nivel * self._largura)
        n_vazio = self._largura - n_cheio
        barra   = self.CHAR_CHEIO * n_cheio + self.CHAR_VAZIO * n_vazio
        pct     = int(nivel * 100)

        # Cor baseada na intensidade
        if self._usar_cores:
            if nivel > 0.75:
                cor_inicio = "\033[91m"   # vermelho — volume alto
            elif nivel > 0.40:
                cor_inicio = "\033[93m"   # amarelo — volume médio
            else:
                cor_inicio = "\033[92m"   # verde — volume baixo
            cor_fim = "\033[0m"
        else:
            cor_inicio = cor_fim = ""

        icone = "🎤" if nivel > 0.05 else "  "
        linha = (
            f"\r{self.ABRE}{cor_inicio}{barra}{cor_fim}{self.FECHA} "
            f"{pct:3d}%  {icone}"
        )
        sys.stdout.write(linha)
        sys.stdout.flush()

    # ── Modo ao vivo (lê microfone) ───────────────────────────────

    def _iniciar_pyaudio(self):
        """Inicia captura do microfone para alimentar a barra automaticamente."""
        try:
            import pyaudio

            pa = pyaudio.PyAudio()

            def _callback(in_data, frame_count, time_info, status):
                self.feed_chunk(in_data)
                return (None, pyaudio.paContinue)

            self._pa_stream = pa.open(
                format            = pyaudio.paInt16,
                channels          = 1,
                rate              = 16000,
                input             = True,
                frames_per_buffer = 512,
                stream_callback   = _callback,
            )
            self._pa_stream.start_stream()

        except ImportError:
            pass  # sem pyaudio, modo manual apenas
        except Exception:
            pass

    # ── Utilitário estático ───────────────────────────────────────

    @staticmethod
    def render_string(nivel: float, largura: int = 20) -> str:
        """
        Retorna a barra como string simples (sem ANSI, sem \r).
        Útil para logs ou testes.

        Exemplo: "[████████░░░░░░░░░░░░]  40%"
        """
        n = int(nivel * largura)
        barra = "█" * n + "░" * (largura - n)
        return f"[{barra}] {int(nivel*100):3d}%"

    @staticmethod
    def _terminal_suporta_cores() -> bool:
        return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
