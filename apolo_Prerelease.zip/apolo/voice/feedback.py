"""
voice/feedback.py — Feedback visual e sonoro de escuta (V2.5)

Mostra o estado atual do APOLO no terminal de forma clara e simples.
Integra com AudioVisualizer para mostrar a barra durante escuta.

Estados:
  on_activate()    → beep + "🎤 Estou ouvindo..."
  on_listening()   → inicia barra de áudio
  feed_audio()     → alimenta a barra com áudio em tempo real
  on_listening_stop() → para a barra
  on_heard(texto)  → "Você disse: ..."
  on_processing()  → spinner "🧠 Processando..."
  on_done()        → "✅ Pronto"
  on_error()       → "❌ Erro"

Uso:
    from voice.feedback import Feedback
    Feedback.on_activate()
    Feedback.on_listening()
    Feedback.on_heard("abre o youtube")
"""

import sys
import time
import threading
from utils.logger import log


# ── Cores ANSI ────────────────────────────────────────────────────────────────
def _cor_suportada() -> bool:
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

CYAN   = "\033[96m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
DIM    = "\033[2m"
BOLD   = "\033[1m"
RESET  = "\033[0m"


def _c(texto: str, cor: str) -> str:
    """Aplica cor se o terminal suportar."""
    if _cor_suportada():
        return f"{cor}{texto}{RESET}"
    return texto


# ── Beep sonoro ───────────────────────────────────────────────────────────────

def _beep(freq: int = 880, dur_ms: int = 100):
    """
    Emite beep sonoro sem dependências externas.
    Windows: winsound. Linux/Mac: terminal bell como fallback.
    """
    try:
        if sys.platform == "win32":
            import winsound
            winsound.Beep(freq, dur_ms)
        else:
            # Tenta sox (opcional) para beep mais agradável no Linux/Mac
            try:
                import subprocess
                subprocess.run(
                    ["sox", "-n", "-d", "synth",
                     f"{dur_ms/1000:.2f}", "sine", str(freq)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=1,
                )
            except Exception:
                # Fallback: bell ASCII
                sys.stdout.write("\a")
                sys.stdout.flush()
    except Exception:
        pass


# ── Spinner simples ───────────────────────────────────────────────────────────

class _Spinner:
    FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self):
        self._ativo  = False
        self._thread = None
        self._msg    = ""

    def start(self, msg: str = "Processando..."):
        self._msg   = msg
        self._ativo = True
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="spinner"
        )
        self._thread.start()

    def stop(self):
        self._ativo = False
        if self._thread:
            self._thread.join(timeout=0.3)
        # Limpa a linha
        sys.stdout.write(f"\r{' ' * (len(self._msg) + 6)}\r")
        sys.stdout.flush()

    def _loop(self):
        i = 0
        while self._ativo:
            frame = self.FRAMES[i % len(self.FRAMES)]
            sys.stdout.write(f"\r{_c(frame, CYAN)} {self._msg}")
            sys.stdout.flush()
            time.sleep(0.08)
            i += 1


# ══════════════════════════════════════════════════════════════════════════════
# Classe principal
# ══════════════════════════════════════════════════════════════════════════════

class _Feedback:
    """Singleton — gerencia todo o feedback UX do APOLO."""

    def __init__(self):
        self._spinner    = _Spinner()
        self._viz        = None      # AudioVisualizer (lazy)
        self._spin_ativo = False
        self.beep_ligado = True      # pode desligar via Feedback.beep_ligado = False
        self.ativo       = True      # pode desligar via Feedback.ativo = False

    # ── Eventos principais ────────────────────────────────────────

    def on_activate(self):
        """
        Wake word detectada. Sinaliza que está pronto para ouvir.
        Som (beep duplo) + mensagem visual.
        """
        if not self.ativo:
            return

        if self.beep_ligado:
            _beep(880, 80)
            time.sleep(0.06)
            _beep(1100, 80)

        print(_c("\n🎤  Estou ouvindo...", CYAN + BOLD))

    def on_listening(self):
        """
        Inicia captura de áudio. Exibe barra de áudio.
        """
        if not self.ativo:
            return

        # Inicia visualizador em background
        try:
            from voice.audio_visualizer import AudioVisualizer
            self._viz = AudioVisualizer()
            self._viz.start(modo="manual")
        except Exception:
            self._viz = None
            print(_c("🎤  Capturando áudio...", CYAN))

    def feed_audio(self, pcm_bytes: bytes):
        """Alimenta o visualizador com chunk de áudio durante a captura."""
        if self._viz:
            self._viz.feed_chunk(pcm_bytes)

    def on_listening_stop(self):
        """Para a barra de áudio."""
        if self._viz:
            self._viz.stop()
            self._viz = None

    def on_heard(self, texto: str):
        """
        Exibe o texto reconhecido após a transcrição.
        """
        if not self.ativo:
            return

        if not texto or not texto.strip():
            print(_c("  ○  Nada detectado.", DIM))
            return

        label = _c("Você disse:", DIM)
        frase = _c(f'"{texto}"', BOLD)
        print(f"  {label} {frase}")

    def on_processing(self, msg: str = "Processando..."):
        """
        Inicia spinner enquanto o LLM / agente processa.
        """
        if not self.ativo:
            return

        self._spinner.start(f"🧠  {msg}")
        self._spin_ativo = True

    def on_done(self, resposta: str = ""):
        """Para o spinner e exibe confirmação com emoção positiva."""
        if self._spin_ativo:
            self._spinner.stop()
            self._spin_ativo = False

        if self.ativo:
            print(_c("✅  Pronto 😄", GREEN))

    def on_error(self, msg: str = "Ocorreu um erro."):
        """Para o spinner e exibe erro com emoção."""
        if self._spin_ativo:
            self._spinner.stop()
            self._spin_ativo = False

        if self.ativo:
            print(_c(f"😕  Hmm... {msg}", RED))

    def on_wait(self, msg: str = "Só um momento..."):
        """Exibe mensagem de espera com emoção neutra."""
        if self.ativo:
            print(_c(f"⏳  {msg}", DIM))

    def on_success(self, msg: str = ""):
        """Exibe mensagem de sucesso com emoção positiva."""
        if self.ativo:
            texto = f"✅  {msg} 😄" if msg else "✅  Feito! 😄"
            print(_c(texto, GREEN))

    def on_command(self, cmd: str):
        """Exibe o comando identificado."""
        if self.ativo:
            print(f"  {_c('⚡ Comando:', YELLOW)} {cmd}")

    def on_routine(self, nome: str):
        """Exibe a rotina sendo executada."""
        if self.ativo:
            print(f"  {_c('🔄 Rotina:', YELLOW)} {nome}")

    def on_wake_idle(self):
        """Retornou para o modo de espera."""
        if self.ativo:
            print(_c("  ○  Aguardando...", DIM))


# ── Instância global singleton ────────────────────────────────────────────────
Feedback = _Feedback()
