"""
voice/tts.py — Text-to-Speech melhorado para o APOLO

Hierarquia de motores (do mais natural ao mais simples):
  1. Piper TTS   → voz neural offline, ~50MB, latência <1s, melhor qualidade
  2. Coqui TTS   → voz neural offline, ~200MB, qualidade alta
  3. pyttsx3     → voz do sistema, zero latência, qualidade básica

O motor é selecionado automaticamente ou via config.TTS_ENGINE.

Uso:
    from voice.tts import TTSEngine
    tts = TTSEngine()
    tts.speak("Olá, sou o APOLO")     # async (não bloqueia)
    tts.speak("texto", block=True)    # síncrono
"""

import os
import threading
import subprocess
import tempfile
import re
import config
from utils.logger import log


class TTSEngine:
    """
    Motor de síntese de voz com auto-detecção de backend.
    Thread-safe — speak() pode ser chamado de qualquer thread.
    """

    def __init__(self):
        self._engine_name = config.TTS_ENGINE
        self._engine      = None
        self._lock        = threading.Lock()
        self._speaking    = False
        self._stop_flag   = threading.Event()
        self._load()

    # ── Carregamento ──────────────────────────────────────────────────────────

    def _load(self):
        ordem = {
            "piper":   self._load_piper,
            "coqui":   self._load_coqui,
            "pyttsx3": self._load_pyttsx3,
        }
        # Tenta o engine configurado primeiro
        tentativas = [self._engine_name] + [k for k in ordem if k != self._engine_name]
        for nome in tentativas:
            fn = ordem.get(nome)
            if fn and fn():
                self._engine_name = nome
                log.info(f"[TTS] Motor ativo: {nome}")
                return
        log.error("[TTS] Nenhum motor de voz disponivel.")

    def _load_piper(self) -> bool:
        """
        Piper TTS — voz neural offline.

        Vozes disponíveis:
          - Jarvis (en_GB): voz do J.A.R.V.I.S. do Iron Man — ativa com TTS_JARVIS_VOICE=True
          - PT-BR (faber):  voz em português — ativa com TTS_JARVIS_VOICE=False

        Instalação:
            pip install piper-tts huggingface_hub
        """
        try:
            from piper.voice import PiperVoice
            model_dir = os.path.join(config.BASE_DIR, "models", "piper")
            os.makedirs(model_dir, exist_ok=True)

            use_jarvis = getattr(config, "TTS_JARVIS_VOICE", False)

            # Voz padrão: edresson (pt-BR, masculino grave — mais próximo de IA assistente)
            # Fallback: faber (pt-BR, neutro)
            model_path  = os.path.join(model_dir, "pt_BR-edresson-medium.onnx")
            config_path = os.path.join(model_dir, "pt_BR-edresson-medium.onnx.json")
            if not os.path.exists(model_path):
                log.info("[TTS/Piper] Baixando voz edresson pt-BR (masculino)...")
                self._baixar_edresson(model_dir)
            # Se falhar, tenta faber
            if not os.path.exists(model_path):
                model_path  = os.path.join(model_dir, "pt_BR-faber-medium.onnx")
                config_path = os.path.join(model_dir, "pt_BR-faber-medium.onnx.json")
                if not os.path.exists(model_path):
                    self._baixar_ptbr(model_dir)

            if os.path.exists(model_path):
                self._engine = PiperVoice.load(model_path, config_path=config_path)
                voz = "Jarvis" if use_jarvis else "PT-BR faber"
                log.info(f"[TTS/Piper] Voz carregada: {voz}")
                return True
        except ImportError:
            log.warning("[TTS/Piper] Não instalado: pip install piper-tts huggingface_hub")
        except Exception as e:
            log.warning(f"[TTS/Piper] {e}")
        return False

    def _baixar_edresson(self, model_dir: str):
        """Baixa voz edresson pt-BR — masculino, tom grave, ideal para assistente."""
        import urllib.request
        base  = "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/edresson/medium"
        files = ["pt_BR-edresson-medium.onnx", "pt_BR-edresson-medium.onnx.json"]
        for fname in files:
            dest = os.path.join(model_dir, fname)
            if not os.path.exists(dest):
                url = f"{base}/{fname}"
                log.info(f"[TTS/Piper] Baixando {fname}...")
                try:
                    urllib.request.urlretrieve(url, dest)
                    log.info(f"[TTS/Piper] ✅ {fname}")
                except Exception as e:
                    log.error(f"[TTS/Piper] ❌ {fname}: {e}")

    def _baixar_jarvis(self, model_dir: str):
        """
        Baixa o modelo Jarvis do Hugging Face (jgkawell/jarvis).
        Repo: https://huggingface.co/jgkawell/jarvis
        Modelo: en/en_GB/jarvis/medium/jarvis-medium.onnx  (~60MB)
        """
        import urllib.request
        base  = "https://huggingface.co/jgkawell/jarvis/resolve/main/en/en_GB/jarvis/medium"
        files = ["jarvis-medium.onnx", "jarvis-medium.onnx.json"]
        for fname in files:
            dest = os.path.join(model_dir, fname)
            if not os.path.exists(dest):
                url = f"{base}/{fname}"
                log.info(f"[TTS/Piper] Baixando {fname} de {url}")
                try:
                    urllib.request.urlretrieve(url, dest)
                    log.info(f"[TTS/Piper] ✅ {fname} baixado")
                except Exception as e:
                    log.error(f"[TTS/Piper] ❌ Falha ao baixar {fname}: {e}")

    def _baixar_ptbr(self, model_dir: str):
        """Baixa o modelo Piper PT-BR automaticamente."""
        import urllib.request
        base  = "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/medium"
        files = ["pt_BR-faber-medium.onnx", "pt_BR-faber-medium.onnx.json"]
        for fname in files:
            dest = os.path.join(model_dir, fname)
            if not os.path.exists(dest):
                try:
                    urllib.request.urlretrieve(f"{base}/{fname}", dest)
                    log.info(f"[TTS/Piper] Baixado: {fname}")
                except Exception as e:
                    log.warning(f"[TTS/Piper] Falha ao baixar {fname}: {e}")

    def _load_coqui(self) -> bool:
        """Coqui TTS — voz neural offline, qualidade alta."""
        try:
            from TTS.api import TTS
            # Modelo multilíngue — funciona em PT
            self._engine = TTS("tts_models/multilingual/multi-dataset/xtts_v2",
                               progress_bar=False, gpu=False)
            return True
        except ImportError:
            pass
        except Exception as e:
            log.warning(f"[TTS/Coqui] {e}")
        return False

    def _load_pyttsx3(self) -> bool:
        """pyttsx3 — voz do sistema, sempre disponível."""
        try:
            import pyttsx3
            eng = pyttsx3.init()
            eng.setProperty("rate",   config.TTS_RATE)
            eng.setProperty("volume", config.TTS_VOLUME)
            # Tenta selecionar voz em português
            for v in eng.getProperty("voices"):
                if any(x in v.id.lower() + v.name.lower()
                       for x in ["pt", "brazil", "portuguese", "brasil"]):
                    eng.setProperty("voice", v.id)
                    log.info(f"[TTS/pyttsx3] Voz PT selecionada: {v.name}")
                    break
            self._engine = eng
            return True
        except ImportError:
            log.error("[TTS/pyttsx3] Nao instalado: pip install pyttsx3")
        except Exception as e:
            log.warning(f"[TTS/pyttsx3] {e}")
        return False

    # ── API pública ───────────────────────────────────────────────────────────

    def speak(self, text: str, block: bool = False):
        """
        Sintetiza e reproduz texto.

        Args:
            text:  texto a ser falado
            block: True = aguarda terminar; False = async (padrão)
        """
        if not self._engine or not text.strip():
            return
        clean = self._clean(text)
        if not clean:
            return

        if block:
            self._sintetizar(clean)
        else:
            t = threading.Thread(target=self._sintetizar, args=(clean,), daemon=True)
            t.start()

    # Alias para compatibilidade com código antigo
    def falar(self, text: str, bloquear: bool = False):
        self.speak(text, block=bloquear)

    def stop(self):
        """Para a fala em andamento."""
        self._stop_flag.set()
        if self._engine_name == "pyttsx3":
            try:
                self._engine.stop()
            except Exception:
                pass
        self._stop_flag.clear()

    @property
    def is_speaking(self) -> bool:
        return self._speaking

    # ── Internos ──────────────────────────────────────────────────────────────

    def _sintetizar(self, text: str):
        with self._lock:
            self._speaking = True
            try:
                if self._engine_name == "piper":
                    self._falar_piper(text)
                elif self._engine_name == "coqui":
                    self._falar_coqui(text)
                else:
                    self._falar_pyttsx3(text)
            except Exception as e:
                log.warning(f"[TTS] Erro ao falar: {e}")
            finally:
                self._speaking = False

    def _falar_piper(self, text: str):
        """Usa Piper para gerar áudio e reproduz com aplay/afplay."""
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            nome = f.name
        try:
            import wave, struct
            with wave.open(nome, "wb") as wav_f:
                wav_f.setnchannels(1)
                wav_f.setsampwidth(2)
                wav_f.setframerate(22050)
                for audio_bytes in self._engine.synthesize_stream_raw(text):
                    wav_f.writeframes(audio_bytes)
            self._reproduzir_audio(nome)
        finally:
            try:
                os.unlink(nome)
            except Exception:
                pass

    def _falar_coqui(self, text: str):
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            nome = f.name
        try:
            self._engine.tts_to_file(text=text, file_path=nome,
                                     language="pt", speaker="Ana Florence")
            self._reproduzir_audio(nome)
        finally:
            try:
                os.unlink(nome)
            except Exception:
                pass

    def _falar_pyttsx3(self, text: str):
        self._engine.say(text)
        self._engine.runAndWait()

    def _reproduzir_audio(self, caminho: str):
        """Reproduz um arquivo WAV no sistema."""
        import sys
        if sys.platform == "linux":
            subprocess.run(["aplay", "-q", caminho],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform == "darwin":
            subprocess.run(["afplay", caminho])
        elif sys.platform == "win32":
            import winsound
            winsound.PlaySound(caminho, winsound.SND_FILENAME)

    @staticmethod
    def _clean(text: str) -> str:
        """Remove markdown e caracteres problemáticos para TTS."""
        text = re.sub(r"\*{1,3}(.+?)\*{1,3}", r"\1", text)
        text = re.sub(r"#{1,6}\s*(.+)",        r"\1", text)
        text = re.sub(r"`{1,3}.+?`{1,3}",      "",    text)
        text = re.sub(r"\[(.+?)\]\(.+?\)",     r"\1", text)
        text = re.sub(r"^[\s\-•*]+",           "",    text, flags=re.MULTILINE)
        text = text.replace("→", "para").replace("←", "de").replace("↑", "acima")
        text = re.sub(r"\n{2,}", ". ", text)
        text = re.sub(r"\s{2,}", " ", text)
        return text.strip()
