"""
voice/wake_word.py — Wake word local sem API externa (V2.5)

Estratégias (auto-detectadas, sem custo):
  1. SpeechRecognition + Google (online, gratuito, sem chave, melhor precisão PT)
  2. SpeechRecognition + Sphinx (offline, precisa pocketsphinx)
  3. Whisper Tiny (offline, sem internet, mais lento)
  4. Texto via stdin (fallback de debug)

Instalação mínima:
    pip install SpeechRecognition pyaudio

Uso:
    from voice.wake_word import WakeWordDetector
    det = WakeWordDetector(callback=minha_funcao)
    det.start()
"""

import threading
import time
import config
from utils.logger import log


class WakeWordDetector:
    """Detecta a palavra de ativação sem nenhuma API paga."""

    COOLDOWN_SEG = 2.5   # evita disparo duplo

    def __init__(self, callback, wake_word: str = None):
        self._callback       = callback
        self._palavra        = (wake_word or config.WAKE_WORD).lower().strip()
        self._rodando        = False
        self._thread         = None
        self._backend_nome   = ""
        self._ultimo_disparo = 0.0
        self._sr_rec         = None   # SpeechRecognition recognizer
        self._sr_mic         = None   # SpeechRecognition microphone
        self._whisper        = None   # Whisper Tiny model

    # ── API pública ───────────────────────────────────────────────

    def start(self):
        if self._rodando:
            return
        self._backend_nome = self._detectar_backend()
        self._rodando      = True
        self._thread       = threading.Thread(
            target=self._loop, daemon=True, name="apolo_wake_word"
        )
        self._thread.start()
        log.info(f"[WakeWord] Ativo | backend: {self._backend_nome} | palavra: '{self._palavra}'")

    def iniciar(self): self.start()

    def stop(self):
        self._rodando = False
        log.info("[WakeWord] Parado.")

    def parar(self): self.stop()

    def set_word(self, nova: str):
        self._palavra = nova.lower().strip()

    @property
    def is_running(self): return self._rodando

    @property
    def backend(self): return self._backend_nome

    # ── Detecção de backend ───────────────────────────────────────

    def _detectar_backend(self) -> str:
        if self._init_sr():
            return "sr_google"
        if self._init_whisper():
            return "whisper"
        return "texto"

    def _init_sr(self) -> bool:
        try:
            import speech_recognition as sr
            self._sr_rec = sr.Recognizer()
            self._sr_rec.energy_threshold         = 300
            self._sr_rec.dynamic_energy_threshold = True
            self._sr_rec.pause_threshold          = 0.6
            self._sr_mic = sr.Microphone(sample_rate=16000)
            # Calibra uma vez para reduzir falsos positivos
            with self._sr_mic as source:
                self._sr_rec.adjust_for_ambient_noise(source, duration=0.5)
            return True
        except ImportError:
            log.debug("[WakeWord] SpeechRecognition não instalado: pip install SpeechRecognition")
        except Exception as e:
            log.debug(f"[WakeWord] SR init: {e}")
        return False

    def _init_whisper(self) -> bool:
        try:
            from faster_whisper import WhisperModel
            log.info("[WakeWord] Carregando Whisper Tiny...")
            self._whisper = WhisperModel("tiny", device="cpu", compute_type="int8")
            return True
        except ImportError:
            log.debug("[WakeWord] faster-whisper não instalado")
        except Exception as e:
            log.debug(f"[WakeWord] Whisper init: {e}")
        return False

    # ── Loops ─────────────────────────────────────────────────────

    def _loop(self):
        log.info(f"[WakeWord] Aguardando '{self._palavra}'...")
        loops = {
            "sr_google": self._loop_sr,
            "whisper":   self._loop_whisper,
            "texto":     self._loop_texto,
        }
        fn = loops.get(self._backend_nome, self._loop_texto)
        try:
            fn()
        except Exception as e:
            log.error(f"[WakeWord] Erro fatal: {e}")

    def _loop_sr(self):
        """SpeechRecognition com Google STT (gratuito, sem chave)."""
        import speech_recognition as sr
        while self._rodando:
            try:
                with self._sr_mic as source:
                    audio = self._sr_rec.listen(
                        source,
                        timeout=5,
                        phrase_time_limit=3,
                    )
                # Tenta Google (gratuito)
                try:
                    texto = self._sr_rec.recognize_google(
                        audio, language="pt-BR"
                    ).lower()
                    log.debug(f"[WakeWord] Captado: '{texto}'")
                    if self._contem_palavra(texto):
                        self._disparar()
                except sr.UnknownValueError:
                    pass  # silêncio/ruído, normal
                except sr.RequestError:
                    # Sem internet — tenta Whisper como fallback imediato
                    if self._whisper:
                        self._checar_whisper_bytes(audio.get_wav_data())
            except sr.WaitTimeoutError:
                pass
            except Exception as e:
                log.warning(f"[WakeWord/SR] {e}")
                time.sleep(1)

    def _loop_whisper(self):
        """Whisper Tiny — offline puro, chunks de 2 segundos."""
        import pyaudio, wave, tempfile, os
        RATE   = 16000
        CHUNK  = 1024
        DUR    = 2
        N      = int(RATE / CHUNK * DUR)

        pa     = pyaudio.PyAudio()
        stream = pa.open(
            format=pyaudio.paInt16, channels=1,
            rate=RATE, input=True, frames_per_buffer=CHUNK,
        )

        while self._rodando:
            try:
                frames = [stream.read(CHUNK, exception_on_overflow=False) for _ in range(N)]
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                    path = f.name
                with wave.open(path, "wb") as wf:
                    wf.setnchannels(1); wf.setsampwidth(2)
                    wf.setframerate(RATE); wf.writeframes(b"".join(frames))
                try:
                    segs, _ = self._whisper.transcribe(
                        path, language="pt", beam_size=1, vad_filter=True
                    )
                    texto = " ".join(s.text for s in segs).lower().strip()
                    if texto:
                        log.debug(f"[WakeWord/Whisper] '{texto}'")
                    if self._contem_palavra(texto):
                        self._disparar()
                finally:
                    try: os.unlink(path)
                    except: pass
            except Exception as e:
                log.warning(f"[WakeWord/Whisper] {e}")
                time.sleep(0.5)

        stream.stop_stream(); stream.close(); pa.terminate()

    def _loop_texto(self):
        """Fallback: digita a palavra no terminal para ativar."""
        log.info(f"[WakeWord/Texto] Digite '{self._palavra}' + Enter para ativar.")
        while self._rodando:
            try:
                linha = input().strip().lower()
                if self._contem_palavra(linha):
                    self._disparar()
            except (EOFError, KeyboardInterrupt):
                break
            except Exception:
                time.sleep(0.1)

    # ── Helpers ───────────────────────────────────────────────────

    def _contem_palavra(self, texto: str) -> bool:
        """Verifica se o texto contém a wake word (com variações)."""
        if not texto:
            return False
        # Variações fonéticas comuns do português para "apolo"
        variacoes = {
            "apolo": ["apolo", "apollo", "ápolo", "apôlo", "a polo"],
        }
        alvo = variacoes.get(self._palavra, [self._palavra])
        return any(v in texto for v in alvo)

    def _checar_whisper_bytes(self, wav_bytes: bytes):
        """Usa Whisper para transcrever bytes WAV quando SR/Google falha offline."""
        if not self._whisper:
            return
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(wav_bytes); path = f.name
        try:
            segs, _ = self._whisper.transcribe(path, language="pt", beam_size=1)
            texto   = " ".join(s.text for s in segs).lower()
            if self._contem_palavra(texto):
                self._disparar()
        finally:
            try: os.unlink(path)
            except: pass

    def _disparar(self):
        """Chama o callback com cooldown."""
        agora = time.time()
        if agora - self._ultimo_disparo < self.COOLDOWN_SEG:
            return
        self._ultimo_disparo = agora
        log.info(f"[WakeWord] ✓ '{self._palavra}' detectado!")
        threading.Thread(
            target=self._callback, daemon=True, name="wake_callback"
        ).start()
