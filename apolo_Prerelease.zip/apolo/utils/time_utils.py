"""
utils/time_utils.py — Sistema de horas com timezone correto do Brasil

Usa zoneinfo (Python 3.9+), sem dependências externas.
Sempre retorna o horário de Brasília, independente do fuso do servidor.

Uso:
    from utils.time_utils import get_current_time, speak_time, get_date_info
"""

from datetime import datetime
from zoneinfo import ZoneInfo

# Timezone oficial de Brasília (UTC-3)
TZ_BRASIL = ZoneInfo("America/Sao_Paulo")

# Nomes dos dias da semana em português
DIAS_SEMANA = [
    "segunda-feira",
    "terça-feira",
    "quarta-feira",
    "quinta-feira",
    "sexta-feira",
    "sábado",
    "domingo",
]

# Nomes dos meses em português
MESES = [
    "", "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
]


def _agora() -> datetime:
    """Retorna o datetime atual no fuso de Brasília."""
    return datetime.now(TZ_BRASIL)


def get_current_time() -> dict:
    """
    Retorna dict com todos os componentes de data e hora atuais.

    Returns:
        {
          "hora":      int   (0-23)
          "minuto":    int   (0-59)
          "segundo":   int   (0-59)
          "dia":       int   (1-31)
          "mes":       int   (1-12)
          "ano":       int
          "dia_semana":str   ("segunda-feira", etc.)
          "mes_nome":  str   ("janeiro", etc.)
          "periodo":   str   ("manhã", "tarde", "noite", "madrugada")
          "iso":       str   (ISO 8601)
        }
    """
    agora = _agora()
    hora  = agora.hour

    # Período do dia
    if 5 <= hora < 12:
        periodo = "manhã"
    elif 12 <= hora < 18:
        periodo = "tarde"
    elif 18 <= hora < 24:
        periodo = "noite"
    else:
        periodo = "madrugada"

    return {
        "hora":       hora,
        "minuto":     agora.minute,
        "segundo":    agora.second,
        "dia":        agora.day,
        "mes":        agora.month,
        "ano":        agora.year,
        "dia_semana": DIAS_SEMANA[agora.weekday()],
        "mes_nome":   MESES[agora.month],
        "periodo":    periodo,
        "iso":        agora.isoformat(),
    }


def speak_time() -> str:
    """
    Retorna a hora atual em formato falado, natural em português.

    Exemplos:
        "São 15 horas e 30 minutos"
        "É 1 hora da manhã"
        "São exatamente 12 horas"
        "São 9 horas e 5 minutos da manhã"
    """
    t = get_current_time()
    h = t["hora"]
    m = t["minuto"]
    p = t["periodo"]

    # Singular / plural da hora
    if h == 0:
        hora_str = "meia-noite"
        plural   = False
    elif h == 1:
        hora_str = "1 hora"
        plural   = False
    elif h == 12:
        hora_str = "meio-dia"
        plural   = False
    else:
        hora_str = f"{h} horas"
        plural   = True

    # Minutos
    if m == 0:
        if h in (0, 12):
            return f"São {hora_str}."
        prefixo = "São" if plural else "É"
        return f"{prefixo} exatamente {hora_str}."

    elif m == 1:
        minuto_str = "1 minuto"
    else:
        minuto_str = f"{m} minutos"

    # Monta a frase completa
    if h in (0, 12):
        return f"São {hora_str} e {minuto_str}."

    prefixo = "São" if plural else "É"
    return f"{prefixo} {hora_str} e {minuto_str} da {p}."


def speak_date() -> str:
    """
    Retorna a data atual em formato falado.

    Exemplo: "Hoje é segunda-feira, 7 de abril de 2025."
    """
    t = get_current_time()
    return (
        f"Hoje é {t['dia_semana']}, "
        f"{t['dia']} de {t['mes_nome']} de {t['ano']}."
    )


def speak_datetime() -> str:
    """Retorna data e hora juntos."""
    return f"{speak_date()} {speak_time()}"


def get_greeting() -> str:
    """
    Retorna saudação adequada ao período do dia.

    Exemplos: "Bom dia!", "Boa tarde!", "Boa noite!"
    """
    periodo = get_current_time()["periodo"]
    saudacoes = {
        "manhã":      "Bom dia!",
        "tarde":      "Boa tarde!",
        "noite":      "Boa noite!",
        "madrugada":  "Boa madrugada!",
    }
    return saudacoes.get(periodo, "Olá!")
