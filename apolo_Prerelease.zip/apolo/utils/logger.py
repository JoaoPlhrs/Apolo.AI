"""utils/logger.py — Logger centralizado do APOLO"""

import logging
import sys
from colorama import Fore, Style, init

init(autoreset=True)

class ApoloFormatter(logging.Formatter):
    CORES = {
        logging.DEBUG:    Fore.CYAN,
        logging.INFO:     Fore.GREEN,
        logging.WARNING:  Fore.YELLOW,
        logging.ERROR:    Fore.RED,
        logging.CRITICAL: Fore.MAGENTA,
    }

    def format(self, record):
        cor = self.CORES.get(record.levelno, "")
        prefix = {
            logging.DEBUG:    "[DEBUG]",
            logging.INFO:     "[APOLO]",
            logging.WARNING:  "[AVISO]",
            logging.ERROR:    "[ERRO ]",
            logging.CRITICAL: "[FATAL]",
        }.get(record.levelno, "[?????]")
        msg = super().format(record)
        return f"{cor}{prefix}{Style.RESET_ALL} {msg}"


def get_logger(name: str = "apolo") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(ApoloFormatter("%(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


# Logger padrão global
log = get_logger("apolo")
