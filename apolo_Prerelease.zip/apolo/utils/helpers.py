"""utils/helpers.py — Funções auxiliares gerais"""

import re
import os
import sys
import platform
from datetime import datetime


def limpar_texto_tts(texto: str) -> str:
    """Remove formatação markdown que atrapalha a síntese de voz."""
    texto = re.sub(r'\*{1,3}(.+?)\*{1,3}', r'\1', texto)   # negrito/itálico
    texto = re.sub(r'#{1,6}\s*(.+)',        r'\1', texto)   # headings
    texto = re.sub(r'`{1,3}(.+?)`{1,3}',   r'\1', texto)   # código
    texto = re.sub(r'\[(.+?)\]\(.+?\)',     r'\1', texto)   # links
    texto = re.sub(r'^\s*[-•*]\s*',         '',    texto, flags=re.MULTILINE)  # bullets
    texto = re.sub(r'\n{2,}',              ' ',    texto)   # múltiplas quebras
    texto = re.sub(r'→|←|↑|↓',            '',     texto)   # setas
    return texto.strip()


def formatar_data_hora(dt: datetime = None) -> str:
    """Retorna data/hora formatada em português."""
    dt = dt or datetime.now()
    dias    = ["segunda-feira", "terça-feira", "quarta-feira",
               "quinta-feira",  "sexta-feira", "sábado", "domingo"]
    meses   = ["janeiro","fevereiro","março","abril","maio","junho",
               "julho","agosto","setembro","outubro","novembro","dezembro"]
    dia_sem = dias[dt.weekday()]
    mes     = meses[dt.month - 1]
    return f"{dia_sem}, {dt.day} de {mes} de {dt.year}, {dt.hour:02d}:{dt.minute:02d}"


def detectar_so() -> str:
    """Detecta o sistema operacional."""
    s = platform.system()
    return {"Linux": "linux", "Darwin": "macos", "Windows": "windows"}.get(s, "desconhecido")


def truncar(texto: str, max_chars: int = 200) -> str:
    """Trunca texto longo com reticências."""
    return texto if len(texto) <= max_chars else texto[:max_chars - 3] + "..."


def normalizar_texto(texto: str) -> str:
    """Normaliza texto para comparação: minúsculas, sem acentos excessivos."""
    import unicodedata
    nfkd = unicodedata.normalize("NFKD", texto.lower().strip())
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def extrair_numero(texto: str) -> float | None:
    """Extrai o primeiro número de um texto."""
    m = re.search(r'-?\d+(?:[.,]\d+)?', texto)
    if m:
        return float(m.group().replace(",", "."))
    return None


def verificar_conexao_ollama() -> bool:
    """Verifica se o Ollama está acessível."""
    try:
        import urllib.request
        urllib.request.urlopen("http://localhost:11434/api/tags", timeout=2)
        return True
    except Exception:
        return False


def criar_diretorios_necessarios():
    """Garante que todos os diretórios necessários existem."""
    import config
    dirs = [
        config.DATA_DIR,
        config.CHROMA_DIR,
        config.HISTORY_DIR,
        os.path.join(os.path.dirname(config.BASE_DIR), "models"),
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)
