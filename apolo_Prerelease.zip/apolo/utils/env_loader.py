"""
utils/env_loader.py — Carregador de variáveis de ambiente do arquivo .env

Lê o arquivo .env na raiz do projeto sem dependências externas (puro stdlib).
As variáveis ficam disponíveis via os.environ E via get().

Uso:
    from utils.env_loader import env
    chave = env.get("YOUTUBE_API_KEY")   # None se não existir
    chave = env.require("YOUTUBE_API_KEY") # levanta erro se não existir
"""

import os
from pathlib import Path
from utils.logger import log

# Raiz do projeto (dois níveis acima deste arquivo: utils/ → apolo/)
_ROOT = Path(__file__).parent.parent


class _EnvLoader:
    """Carrega e expõe variáveis do arquivo .env."""

    def __init__(self):
        self._vars: dict[str, str] = {}
        self._carregado = False

    def _carregar(self):
        """Lê o .env uma única vez (lazy loading)."""
        if self._carregado:
            return
        self._carregado = True

        env_path = _ROOT / ".env"
        if not env_path.exists():
            log.debug("[Env] .env não encontrado — usando apenas os.environ")
            return

        try:
            with open(env_path, encoding="utf-8") as f:
                for linha in f:
                    linha = linha.strip()
                    # Ignora comentários e linhas vazias
                    if not linha or linha.startswith("#"):
                        continue
                    if "=" not in linha:
                        continue
                    chave, _, valor = linha.partition("=")
                    chave  = chave.strip()
                    valor  = valor.strip()
                    # Remove aspas opcionais ao redor do valor
                    if len(valor) >= 2 and valor[0] in ('"', "'") and valor[-1] == valor[0]:
                        valor = valor[1:-1]
                    self._vars[chave] = valor
                    # Injeta em os.environ para compatibilidade com bibliotecas
                    os.environ.setdefault(chave, valor)

            log.debug(f"[Env] {len(self._vars)} variáveis carregadas do .env")

        except Exception as e:
            log.warning(f"[Env] Erro ao ler .env: {e}")

    def get(self, chave: str, padrao: str = None) -> str | None:
        """
        Retorna o valor de uma variável de ambiente.
        Ordem de busca: .env → os.environ → padrao
        """
        self._carregar()
        return self._vars.get(chave) or os.environ.get(chave) or padrao

    def require(self, chave: str) -> str:
        """
        Retorna o valor de uma variável obrigatória.
        Levanta ValueError com instrução clara se não existir.
        """
        valor = self.get(chave)
        if not valor:
            raise ValueError(
                f"Variável '{chave}' não encontrada.\n"
                f"Adicione ao arquivo .env na raiz do projeto:\n"
                f"  {chave}=seu_valor_aqui"
            )
        return valor

    def exists(self, chave: str) -> bool:
        """Verifica se uma variável está definida e não vazia."""
        return bool(self.get(chave))

    def listar(self) -> dict[str, str]:
        """Retorna todas as variáveis do .env (sem expor os valores)."""
        self._carregar()
        return {k: "***" for k in self._vars}


# Instância global
env = _EnvLoader()
