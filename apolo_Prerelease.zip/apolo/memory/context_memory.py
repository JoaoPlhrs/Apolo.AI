"""
memory/context_memory.py — Memória contextual inteligente

Diferente do vector_store (que armazena tudo) e do long_term (que armazena fatos),
o context_memory entende RELAÇÕES entre informações e prioriza por relevância.

Estratégias:
  - TF-IDF simples para score de relevância sem embeddings
  - Decay temporal (memórias antigas perdem peso)
  - Boost por acesso frequente
  - Agrupamento por contexto (tags automáticas)

Uso:
    from memory.context_memory import ContextMemory
    cm = ContextMemory()
    cm.save_context("Usuário prefere Python a JavaScript")
    resultados = cm.retrieve_context("qual linguagem ele prefere?")
    cm.rank_memories()  → lista ordenada por relevância
"""

import os
import json
import math
import time
import re
from datetime import datetime
from typing import Optional
import config
from utils.logger import log

CONTEXT_FILE = os.path.join(config.DATA_DIR, "context_memory.json")

# Stopwords básicas em português
STOPWORDS = {
    "o", "a", "os", "as", "um", "uma", "de", "do", "da", "dos", "das",
    "em", "no", "na", "nos", "nas", "por", "para", "com", "que", "se",
    "e", "é", "ou", "mas", "ao", "à", "eu", "tu", "ele", "ela", "nós",
    "me", "te", "meu", "minha", "seu", "sua", "este", "esse", "isso",
    "não", "sim", "já", "mais", "muito", "bem", "tudo", "foi", "ser",
}

# Tags automáticas por palavras-chave
TAG_RULES = {
    "preferencia":  ["prefer", "gost", "ador", "odei", "melhor", "pior"],
    "fato_pessoal": ["meu", "minha", "trabalho", "moro", "chamo", "tenho"],
    "tecnico":      ["código", "python", "programa", "arquivo", "erro", "função"],
    "rotina":       ["manhã", "tarde", "noite", "sempre", "todo dia", "rotina"],
    "tarefa":       ["fazer", "preciso", "devo", "quero", "lembr", "tarefa"],
}


def _tokenize(texto: str) -> list[str]:
    """Tokeniza texto em palavras relevantes."""
    palavras = re.findall(r"\b\w{3,}\b", texto.lower())
    return [p for p in palavras if p not in STOPWORDS]


def _detectar_tags(texto: str) -> list[str]:
    """Detecta tags automáticas pelo conteúdo."""
    t = texto.lower()
    return [tag for tag, gatilhos in TAG_RULES.items()
            if any(g in t for g in gatilhos)]


def _score_tfidf(query_tokens: list[str], doc_tokens: list[str],
                 corpus_size: int, doc_freq: dict) -> float:
    """TF-IDF simples para score de relevância."""
    if not query_tokens or not doc_tokens:
        return 0.0
    score = 0.0
    tf_doc = {}
    for t in doc_tokens:
        tf_doc[t] = tf_doc.get(t, 0) + 1

    for token in query_tokens:
        tf  = tf_doc.get(token, 0) / max(len(doc_tokens), 1)
        df  = doc_freq.get(token, 0)
        idf = math.log((corpus_size + 1) / (df + 1)) + 1
        score += tf * idf
    return score


class ContextMemory:
    """Memória contextual com scoring de relevância e decay temporal."""

    DECAY_LAMBDA = 0.01   # queda de score por hora de inatividade
    BOOST_ACCESS = 0.1    # boost por cada acesso

    def __init__(self):
        os.makedirs(config.DATA_DIR, exist_ok=True)
        self._memorias: list[dict] = []
        self._doc_freq: dict[str, int] = {}   # frequência de token no corpus
        self._load()

    # ── Persistência ──────────────────────────────────────────────────────────

    def _load(self):
        if os.path.exists(CONTEXT_FILE):
            try:
                with open(CONTEXT_FILE, "r", encoding="utf-8") as f:
                    dados = json.load(f)
                self._memorias = dados.get("memorias", [])
                self._doc_freq = dados.get("doc_freq", {})
                log.info(f"[ContextMemory] {len(self._memorias)} memórias carregadas")
            except Exception as e:
                log.warning(f"[ContextMemory] Erro ao carregar: {e}")

    def _save(self):
        try:
            with open(CONTEXT_FILE, "w", encoding="utf-8") as f:
                json.dump({
                    "memorias": self._memorias,
                    "doc_freq": self._doc_freq,
                }, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log.warning(f"[ContextMemory] Erro ao salvar: {e}")

    # ── API principal ──────────────────────────────────────────────────────────

    def save_context(self, text: str, importance: float = 1.0) -> str:
        """
        Salva um texto como memória contextual.

        Args:
            text:       conteúdo a memorizar
            importance: 0.1 a 10.0 — peso base desta memória

        Returns:
            ID da memória criada
        """
        if not text.strip():
            return ""

        tokens = _tokenize(text)
        tags   = _detectar_tags(text)
        mem_id = f"ctx_{abs(hash(text)) % 999999}"

        # Verifica se já existe (evita duplicata)
        for m in self._memorias:
            if m["id"] == mem_id:
                m["access_count"] += 1
                m["last_access"]   = time.time()
                self._save()
                return mem_id

        memoria = {
            "id":           mem_id,
            "text":         text,
            "tokens":       tokens,
            "tags":         tags,
            "importance":   importance,
            "created_at":   time.time(),
            "last_access":  time.time(),
            "access_count": 0,
        }
        self._memorias.append(memoria)

        # Atualiza frequência de documento
        for t in set(tokens):
            self._doc_freq[t] = self._doc_freq.get(t, 0) + 1

        # Limita a 500 memórias (remove as menos relevantes)
        if len(self._memorias) > 500:
            self._memorias = self.rank_memories()[:500]

        self._save()
        log.debug(f"[ContextMemory] Salvo: {text[:60]}")
        return mem_id

    def retrieve_context(self, query: str, top_k: int = 5,
                         tag_filter: str = None) -> list[dict]:
        """
        Recupera memórias relevantes para uma query.

        Scoring combina:
          - TF-IDF (relevância semântica básica)
          - Decay temporal (memórias recentes têm peso maior)
          - Boost por acesso frequente
          - Filtro por tag

        Returns:
            Lista de dicts: [{"text", "score", "tags", "age_hours"}]
        """
        if not self._memorias:
            return []

        query_tokens  = _tokenize(query)
        agora         = time.time()
        corpus_size   = len(self._memorias)
        resultados    = []

        for m in self._memorias:
            # Filtro por tag
            if tag_filter and tag_filter not in m.get("tags", []):
                continue

            # Score TF-IDF
            score_texto = _score_tfidf(
                query_tokens, m["tokens"], corpus_size, self._doc_freq
            )

            # Decay temporal (exponencial)
            horas_atraso  = (agora - m["last_access"]) / 3600
            decay         = math.exp(-self.DECAY_LAMBDA * horas_atraso)

            # Boost por importância e acesso
            boost = m["importance"] + (m["access_count"] * self.BOOST_ACCESS)

            score_final = score_texto * decay * boost

            if score_final > 0:
                resultados.append({
                    "id":        m["id"],
                    "text":      m["text"],
                    "score":     round(score_final, 4),
                    "tags":      m["tags"],
                    "age_hours": round(horas_atraso, 1),
                })

        # Ordena por score
        resultados.sort(key=lambda x: x["score"], reverse=True)

        # Registra acesso nas memórias retornadas
        ids_retornados = {r["id"] for r in resultados[:top_k]}
        for m in self._memorias:
            if m["id"] in ids_retornados:
                m["access_count"] += 1
                m["last_access"]   = agora

        if ids_retornados:
            self._save()

        return resultados[:top_k]

    def retrieve_as_text(self, query: str, top_k: int = 3) -> str:
        """
        Versão simplificada — retorna string pronta para injetar no LLM.
        """
        results = self.retrieve_context(query, top_k)
        if not results:
            return ""
        return " | ".join(r["text"] for r in results)

    def rank_memories(self) -> list[dict]:
        """
        Retorna TODAS as memórias ordenadas por relevância composta
        (importância × recência × frequência de acesso).
        Útil para diagnóstico e limpeza.
        """
        agora = time.time()
        scored = []
        for m in self._memorias:
            horas    = (agora - m["last_access"]) / 3600
            decay    = math.exp(-self.DECAY_LAMBDA * horas)
            score    = m["importance"] * decay * (1 + m["access_count"] * 0.05)
            scored.append({**m, "_score": score})
        scored.sort(key=lambda x: x["_score"], reverse=True)
        return scored

    # ── Utilitários ───────────────────────────────────────────────────────────

    def get_by_tag(self, tag: str) -> list[str]:
        """Retorna textos de memórias com uma tag específica."""
        return [m["text"] for m in self._memorias if tag in m.get("tags", [])]

    def delete(self, mem_id: str):
        """Remove uma memória pelo ID."""
        antes = len(self._memorias)
        self._memorias = [m for m in self._memorias if m["id"] != mem_id]
        if len(self._memorias) < antes:
            self._save()

    def clear(self):
        """Limpa toda a memória contextual."""
        self._memorias = []
        self._doc_freq = {}
        self._save()

    def stats(self) -> dict:
        return {
            "total":     len(self._memorias),
            "tags":      list({t for m in self._memorias for t in m.get("tags", [])}),
            "vocab_size": len(self._doc_freq),
        }
