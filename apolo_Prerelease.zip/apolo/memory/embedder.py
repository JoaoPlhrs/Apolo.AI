"""memory/embedder.py — Wrapper de sentence-transformers para embeddings multilíngues"""

from typing import List
import config
from utils.logger import log


class Embedder:
    """
    Encapsula o modelo de embeddings.
    Lazy-loading: só carrega quando usado pela primeira vez.
    """

    _instancia = None  # Singleton

    def __new__(cls):
        if cls._instancia is None:
            cls._instancia = super().__new__(cls)
            cls._instancia._modelo = None
        return cls._instancia

    def _carregar(self):
        if self._modelo is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            log.info(f"Carregando modelo de embeddings...")
            self._modelo = SentenceTransformer(config.EMBEDDING_MODEL)
            log.info("Embedder pronto.")
        except ImportError:
            log.error("sentence-transformers não instalado. Execute: pip install sentence-transformers")
            raise
        except Exception as e:
            log.error(f"Erro ao carregar embedder: {e}")
            raise

    def encode(self, textos: List[str] | str, normalizar: bool = True) -> list:
        """
        Gera embeddings para um texto ou lista de textos.
        Retorna lista de vetores float.
        """
        self._carregar()
        if isinstance(textos, str):
            textos = [textos]
        vetores = self._modelo.encode(textos, normalize_embeddings=normalizar)
        return vetores.tolist()

    def encode_um(self, texto: str) -> list:
        """Gera embedding para um único texto. Retorna lista de floats."""
        return self.encode([texto])[0]

    @property
    def dimensao(self) -> int:
        self._carregar()
        return self._modelo.get_sentence_embedding_dimension()
