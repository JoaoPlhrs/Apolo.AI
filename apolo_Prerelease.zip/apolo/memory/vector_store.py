"""
memory/vector_store.py — Banco vetorial com FAISS (primário) + ChromaDB (fallback)

Hierarquia de backend:
  1. FAISS    → mais rápido, 100% offline, sem servidor
  2. ChromaDB → persistente, mais features
  3. InMemory → fallback puro se nenhum disponível

Interface pública idêntica independente do backend.
"""

import os
import uuid
import pickle
from abc import ABC, abstractmethod
from typing import Optional
import config
from utils.logger import log


# ══════════════════════════════════════════════════════════════════════════════
# Backends abstratos
# ══════════════════════════════════════════════════════════════════════════════

class VectorBackend(ABC):
    @abstractmethod
    def add(self, text, embedding, metadata, doc_id): ...
    @abstractmethod
    def search(self, embedding, n): ...
    @abstractmethod
    def delete(self, doc_id): ...
    @abstractmethod
    def count(self): ...
    @abstractmethod
    def clear(self): ...


class FAISSBackend(VectorBackend):
    INDEX_FILE = os.path.join(config.DATA_DIR, "faiss.index")
    META_FILE  = os.path.join(config.DATA_DIR, "faiss_meta.pkl")

    def __init__(self, dim=384):
        import faiss
        self._dim   = dim
        self._index = faiss.IndexFlatIP(dim)
        self._meta  = []
        self._load()

    def _load(self):
        try:
            import faiss
            if os.path.exists(self.INDEX_FILE) and os.path.exists(self.META_FILE):
                self._index = faiss.read_index(self.INDEX_FILE)
                with open(self.META_FILE, "rb") as f:
                    self._meta = pickle.load(f)
                log.info(f"[FAISS] {self._index.ntotal} vetores carregados")
        except Exception as e:
            log.warning(f"[FAISS] Nao foi possivel carregar indice: {e}")

    def _save(self):
        try:
            import faiss
            os.makedirs(config.DATA_DIR, exist_ok=True)
            faiss.write_index(self._index, self.INDEX_FILE)
            with open(self.META_FILE, "wb") as f:
                pickle.dump(self._meta, f)
        except Exception as e:
            log.warning(f"[FAISS] Erro ao salvar: {e}")

    def add(self, text, embedding, metadata, doc_id):
        import numpy as np
        vec = np.array([embedding], dtype="float32")
        self._index.add(vec)
        self._meta.append({"id": doc_id, "text": text, **metadata})
        self._save()

    def search(self, embedding, n):
        if self._index.ntotal == 0:
            return []
        import numpy as np
        vec = np.array([embedding], dtype="float32")
        k   = min(n, self._index.ntotal)
        scores, indices = self._index.search(vec, k)
        resultados = []
        for score, idx in zip(scores[0], indices[0]):
            if 0 <= idx < len(self._meta) and not self._meta[idx].get("_deleted"):
                item = self._meta[idx].copy()
                item["score"] = float(score)
                resultados.append(item)
        return resultados

    def delete(self, doc_id):
        for m in self._meta:
            if m.get("id") == doc_id:
                m["_deleted"] = True
        self._save()

    def count(self):
        return len([m for m in self._meta if not m.get("_deleted")])

    def clear(self):
        import faiss
        self._index = faiss.IndexFlatIP(self._dim)
        self._meta  = []
        self._save()


class ChromaBackend(VectorBackend):
    def __init__(self):
        import chromadb
        os.makedirs(config.CHROMA_DIR, exist_ok=True)
        client = chromadb.PersistentClient(path=config.CHROMA_DIR)
        self._col = client.get_or_create_collection(
            name="apolo_vetores", metadata={"hnsw:space": "cosine"}
        )
        log.info(f"[Chroma] {self._col.count()} docs carregados")

    def add(self, text, embedding, metadata, doc_id):
        try:
            self._col.add(documents=[text], embeddings=[embedding],
                          metadatas=[metadata], ids=[doc_id])
        except Exception:
            pass  # ignora duplicata

    def search(self, embedding, n):
        if self._col.count() == 0:
            return []
        k   = min(n, self._col.count())
        res = self._col.query(query_embeddings=[embedding], n_results=k,
                              include=["documents", "distances", "metadatas"])
        out = []
        for doc, dist, meta in zip(res["documents"][0], res["distances"][0], res["metadatas"][0]):
            out.append({"text": doc, "score": 1 - dist, **meta})
        return out

    def delete(self, doc_id):
        try:
            self._col.delete(ids=[doc_id])
        except Exception:
            pass

    def count(self):
        return self._col.count()

    def clear(self):
        self._col.delete()


class InMemoryBackend(VectorBackend):
    def __init__(self):
        self._docs = []
        log.warning("[VectorStore] Backend in-memory — sem persistencia")

    def add(self, text, embedding, metadata, doc_id):
        self._docs.append({"id": doc_id, "text": text, "vec": embedding, **metadata})

    def search(self, embedding, n):
        import math
        def cos(a, b):
            dot = sum(x*y for x, y in zip(a, b))
            na  = math.sqrt(sum(x**2 for x in a))
            nb  = math.sqrt(sum(x**2 for x in b))
            return dot / (na * nb + 1e-9)
        scored = [(cos(embedding, d["vec"]), d) for d in self._docs]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [{"score": s, **d} for s, d in scored[:n]]

    def delete(self, doc_id):
        self._docs = [d for d in self._docs if d["id"] != doc_id]

    def count(self):
        return len(self._docs)

    def clear(self):
        self._docs = []


# ══════════════════════════════════════════════════════════════════════════════
# Interface pública
# ══════════════════════════════════════════════════════════════════════════════

class VectorMemory:
    SCORE_THRESHOLD = 0.30

    def __init__(self):
        self._embedder = None
        self._backend  = self._init_backend()
        self._load_embedder()

    def _init_backend(self):
        try:
            import faiss  # noqa
            b = FAISSBackend()
            log.info("[VectorStore] Backend: FAISS")
            return b
        except ImportError:
            pass
        try:
            import chromadb  # noqa
            b = ChromaBackend()
            log.info("[VectorStore] Backend: ChromaDB")
            return b
        except ImportError:
            pass
        return InMemoryBackend()

    def _load_embedder(self):
        try:
            from sentence_transformers import SentenceTransformer
            self._embedder = SentenceTransformer(config.EMBEDDING_MODEL)
        except Exception as e:
            log.warning(f"[VectorStore] Embedder indisponivel: {e}")

    def _embed(self, texto):
        if not self._embedder:
            return None
        try:
            return self._embedder.encode(texto, normalize_embeddings=True).tolist()
        except Exception:
            return None

    def salvar(self, texto, metadata=None):
        metadata = metadata or {}
        if not texto.strip():
            return False
        embedding = self._embed(texto)
        if embedding is None:
            return False
        doc_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, texto))
        try:
            self._backend.add(texto, embedding, metadata, doc_id)
            return True
        except Exception as e:
            log.warning(f"[VectorStore] Erro ao salvar: {e}")
            return False

    def buscar(self, consulta, n_results=None):
        n = n_results or config.MEMORY_TOP_K
        if self._backend.count() == 0:
            return []
        embedding = self._embed(consulta)
        if embedding is None:
            return []
        try:
            res = self._backend.search(embedding, n)
            return [r["text"] for r in res if r.get("score", 0) >= self.SCORE_THRESHOLD]
        except Exception as e:
            log.warning(f"[VectorStore] Erro na busca: {e}")
            return []

    def buscar_com_score(self, consulta, n_results=None):
        n = n_results or config.MEMORY_TOP_K
        if self._backend.count() == 0:
            return []
        embedding = self._embed(consulta)
        if embedding is None:
            return []
        try:
            return self._backend.search(embedding, n)
        except Exception as e:
            log.warning(f"[VectorStore] Erro na busca: {e}")
            return []

    def salvar_preferencia(self, chave, valor):
        self.salvar(f"Preferencia do usuario: {chave} = {valor}",
                    metadata={"tipo": "preferencia", "chave": chave})

    def deletar(self, texto):
        doc_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, texto))
        self._backend.delete(doc_id)

    def count(self):
        return self._backend.count()

    def limpar(self):
        self._backend.clear()

    @property
    def backend_name(self):
        return type(self._backend).__name__.replace("Backend", "")
