"""memory/episodic.py — Memória episódica: histórico de conversas em JSON"""

import json
import os
from datetime import datetime
from typing import Optional
import config
from utils.logger import log


class EpisodicMemory:
    """
    Armazena e recupera conversas passadas.
    Cada sessão é salva com timestamp e pode ser pesquisada por data ou texto.
    """

    def __init__(self):
        os.makedirs(config.HISTORY_DIR, exist_ok=True)
        self.arquivo = config.HISTORY_FILE
        self._sessoes: list[dict] = self._carregar_todas()

    def _carregar_todas(self) -> list[dict]:
        if not os.path.exists(self.arquivo):
            return []
        try:
            with open(self.arquivo, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []

    def _salvar(self):
        try:
            with open(self.arquivo, "w", encoding="utf-8") as f:
                json.dump(self._sessoes, f, ensure_ascii=False, indent=2)
        except IOError as e:
            log.warning(f"Erro ao salvar memória episódica: {e}")

    def salvar_sessao(self, mensagens: list[dict], resumo: str = ""):
        """Salva uma sessão de conversa completa."""
        sessao = {
            "timestamp": datetime.now().isoformat(),
            "data":      datetime.now().strftime("%d/%m/%Y %H:%M"),
            "resumo":    resumo,
            "mensagens": mensagens,
        }
        self._sessoes.append(sessao)
        # Mantém apenas as 100 últimas sessões
        if len(self._sessoes) > 100:
            self._sessoes = self._sessoes[-100:]
        self._salvar()

    def buscar_por_texto(self, consulta: str, max_resultados: int = 3) -> list[dict]:
        """Busca sessões que contenham o texto consultado."""
        consulta_lower = consulta.lower()
        encontrados    = []

        for sessao in reversed(self._sessoes):
            for msg in sessao.get("mensagens", []):
                if consulta_lower in msg.get("content", "").lower():
                    encontrados.append(sessao)
                    break
            if len(encontrados) >= max_resultados:
                break

        return encontrados

    def get_ultima_sessao(self) -> Optional[dict]:
        return self._sessoes[-1] if self._sessoes else None

    def get_resumo_recente(self, n: int = 5) -> str:
        """Retorna um resumo das últimas N sessões para contexto."""
        recentes = self._sessoes[-n:]
        if not recentes:
            return ""
        linhas = []
        for s in recentes:
            data = s.get("data", "")
            resumo = s.get("resumo", "")
            # Pega a última mensagem do usuário como fallback de resumo
            for msg in reversed(s.get("mensagens", [])):
                if msg.get("role") == "user":
                    resumo = resumo or msg["content"][:80]
                    break
            if resumo:
                linhas.append(f"[{data}] {resumo}")
        return "\n".join(linhas)

    def total_sessoes(self) -> int:
        return len(self._sessoes)

    def limpar(self):
        self._sessoes = []
        self._salvar()
        log.info("Memória episódica limpa.")
