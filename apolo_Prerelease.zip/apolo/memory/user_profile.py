"""memory/user_profile.py — Perfil persistente do usuário"""

import json
import os
import config
from utils.logger import log

PERFIL_PADRAO = {
    "nome":       "",
    "cidade":     "",
    "preferencias": {
        "estilo_resposta": "direto",  # direto | detalhado | informal
        "idioma":          "pt-BR",
    },
    "apps_favoritos": [],
    "fatos": {}
}


class UserProfile:
    def __init__(self):
        os.makedirs(config.DATA_DIR, exist_ok=True)
        self.dados = PERFIL_PADRAO.copy()
        self._carregar()

    def _carregar(self):
        if os.path.exists(config.PROFILE_FILE):
            try:
                with open(config.PROFILE_FILE, "r", encoding="utf-8") as f:
                    salvo = json.load(f)
                self.dados.update(salvo)
            except Exception:
                pass

    def _salvar(self):
        try:
            with open(config.PROFILE_FILE, "w", encoding="utf-8") as f:
                json.dump(self.dados, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log.warning(f"Erro ao salvar perfil: {e}")

    def atualizar(self, chave: str, valor):
        """Atualiza um campo do perfil e persiste."""
        self.dados[chave] = valor
        self._salvar()
        log.info(f"Perfil atualizado: {chave} = {valor}")

    def atualizar_fato(self, chave: str, valor: str):
        """Salva um fato específico sobre o usuário."""
        self.dados["fatos"][chave] = valor
        self._salvar()

    def get(self, chave: str, padrao=None):
        return self.dados.get(chave, padrao)

    def get_contexto(self) -> str:
        """Retorna string de contexto para injetar no LLM."""
        partes = []
        if self.dados.get("nome"):
            partes.append(f"O nome do usuário é {self.dados['nome']}")
        if self.dados.get("cidade"):
            partes.append(f"O usuário mora em {self.dados['cidade']}")
        for chave, valor in self.dados.get("fatos", {}).items():
            partes.append(f"{chave}: {valor}")
        return " | ".join(partes) if partes else ""
