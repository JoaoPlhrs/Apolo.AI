"""
memory/learning.py — Aprendizado contínuo por feedback

O APOLO aprende quando o usuário corrige uma resposta errada ou confirma uma boa.
As respostas aprendidas têm prioridade sobre o LLM.

Uso:
    from memory.learning import Learning
    Learning.save_feedback("como vai?", "Estou funcionando perfeitamente!")
    resposta = Learning.retrieve_learned_response("como você está?")
"""

import os
import json
import re
import time
from typing import Optional
from utils.logger import log
import config

LEARN_FILE = os.path.join(config.DATA_DIR, "learned_responses.json")
STOPWORDS  = {"o", "a", "e", "de", "do", "da", "que", "se", "em", "um", "uma",
              "é", "não", "me", "te", "eu", "tu", "ele", "ela", "nos", "para"}


def _normalizar(texto: str) -> str:
    """Normaliza texto para comparação."""
    t = texto.lower().strip()
    t = re.sub(r"[^\w\s]", "", t)
    t = re.sub(r"\s+", " ", t)
    return t


def _similaridade(a: str, b: str) -> float:
    """Similaridade de Jaccard entre dois textos (0.0 a 1.0)."""
    palavras_a = set(_normalizar(a).split()) - STOPWORDS
    palavras_b = set(_normalizar(b).split()) - STOPWORDS
    if not palavras_a or not palavras_b:
        return 0.0
    inter = palavras_a & palavras_b
    uniao = palavras_a | palavras_b
    return len(inter) / len(uniao)


class _Learning:
    """Singleton — gerencia respostas aprendidas por feedback."""

    THRESHOLD_MATCH  = 0.65   # score mínimo para considerar match
    MAX_ENTRIES      = 1000   # limite de entradas

    def __init__(self):
        self._dados: list[dict] = []
        self._load()

    def _load(self):
        os.makedirs(config.DATA_DIR, exist_ok=True)
        if os.path.exists(LEARN_FILE):
            try:
                with open(LEARN_FILE, "r", encoding="utf-8") as f:
                    self._dados = json.load(f)
                log.info(f"[Learning] {len(self._dados)} respostas aprendidas")
            except Exception as e:
                log.warning(f"[Learning] Erro ao carregar: {e}")

    def _save(self):
        try:
            with open(LEARN_FILE, "w", encoding="utf-8") as f:
                json.dump(self._dados, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log.warning(f"[Learning] Erro ao salvar: {e}")

    # ── API principal ──────────────────────────────────────────────────────────

    def save_feedback(self, input_text: str, correct_output: str,
                      score: float = 1.0, source: str = "user") -> bool:
        """
        Salva um par (entrada → saída correta).

        Args:
            input_text:     o que o usuário disse
            correct_output: a resposta que o APOLO deveria dar
            score:          confiança na resposta (0.0 a 1.0)
            source:         "user" | "auto" | "correction"

        Returns:
            True se salvo com sucesso
        """
        if not input_text.strip() or not correct_output.strip():
            return False

        entrada_norm = _normalizar(input_text)

        # Verifica se já existe entrada similar e atualiza
        for entry in self._dados:
            if _similaridade(entrada_norm, entry["input_norm"]) > 0.85:
                entry["output"]     = correct_output
                entry["score"]      = score
                entry["updated_at"] = time.time()
                entry["use_count"]  = 0
                self._save()
                log.info(f"[Learning] Atualizado: '{input_text[:40]}'")
                return True

        # Nova entrada
        self._dados.append({
            "input":       input_text,
            "input_norm":  entrada_norm,
            "output":      correct_output,
            "score":       score,
            "source":      source,
            "created_at":  time.time(),
            "updated_at":  time.time(),
            "use_count":   0,
        })

        # Limita tamanho (remove os menos usados)
        if len(self._dados) > self.MAX_ENTRIES:
            self._dados.sort(key=lambda x: x["use_count"], reverse=True)
            self._dados = self._dados[:self.MAX_ENTRIES]

        self._save()
        log.info(f"[Learning] Aprendido: '{input_text[:40]}' → '{correct_output[:40]}'")
        return True

    def retrieve_learned_response(self, input_text: str) -> Optional[str]:
        """
        Busca a melhor resposta aprendida para uma entrada.

        Returns:
            String com a resposta, ou None se não houver match suficiente
        """
        if not self._dados:
            return None

        entrada_norm = _normalizar(input_text)
        melhor_score = 0.0
        melhor_resp  = None
        melhor_idx   = -1

        for i, entry in enumerate(self._dados):
            sim = _similaridade(entrada_norm, entry["input_norm"])
            # Pondera pelo score de confiança registrado
            score_final = sim * entry["score"]
            if score_final > melhor_score:
                melhor_score = score_final
                melhor_resp  = entry["output"]
                melhor_idx   = i

        if melhor_score >= self.THRESHOLD_MATCH and melhor_resp:
            # Registra uso
            self._dados[melhor_idx]["use_count"] += 1
            self._dados[melhor_idx]["updated_at"] = time.time()
            self._save()
            log.debug(f"[Learning] Match ({melhor_score:.2f}): '{input_text[:40]}'")
            return melhor_resp

        return None

    def list_all(self) -> list[dict]:
        """Lista todas as respostas aprendidas."""
        return sorted(self._dados, key=lambda x: x["use_count"], reverse=True)

    def delete(self, input_text: str) -> bool:
        """Remove uma resposta aprendida."""
        antes = len(self._dados)
        norm  = _normalizar(input_text)
        self._dados = [
            e for e in self._dados
            if _similaridade(norm, e["input_norm"]) < 0.85
        ]
        if len(self._dados) < antes:
            self._save()
            return True
        return False

    def clear(self):
        """Apaga todo o aprendizado."""
        self._dados = []
        self._save()

    def stats(self) -> dict:
        return {
            "total":       len(self._dados),
            "mais_usados": [e["input"][:40] for e in self.list_all()[:5]],
        }


# ── Instância global ───────────────────────────────────────────────────────────
Learning = _Learning()
