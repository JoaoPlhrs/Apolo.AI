"""
memory/long_term.py — Memória de longo prazo do APOLO

Usa SQLite para persistência estruturada + ChromaDB para busca semântica.
Completamente independente dos outros módulos de memória.

Uso:
    from memory.long_term import LongTermMemory
    mem = LongTermMemory()
    mem.save("nome_usuario", "Carlos")
    mem.get("nome_usuario")          → "Carlos"
    mem.search("como o usuário se chama")  → [{"key": "nome_usuario", ...}]
"""

import os
import json
import sqlite3
from datetime import datetime
from typing import Any, Optional
import config
from utils.logger import log


DB_PATH = os.path.join(config.DATA_DIR, "long_term.db")


class LongTermMemory:
    """
    Memória persistente estruturada em chave-valor + busca semântica.

    Tabelas SQLite:
        memories   → chave/valor + tipo + timestamp + importância
        facts      → fatos específicos sobre o usuário (nome, cidade, etc.)
    """

    # Tipos de memória
    TYPE_FACT       = "fact"        # fato sobre o usuário
    TYPE_PREFERENCE = "preference"  # preferência do usuário
    TYPE_EVENT      = "event"       # evento passado
    TYPE_KNOWLEDGE  = "knowledge"   # conhecimento geral aprendido
    TYPE_COMMAND    = "command"     # padrão de comando do usuário

    def __init__(self):
        os.makedirs(config.DATA_DIR, exist_ok=True)
        self._conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._criar_tabelas()
        self._embedder = None   # lazy-load

    # ── DDL ───────────────────────────────────────────────────────────────────

    def _criar_tabelas(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS memories (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                key         TEXT NOT NULL,
                value       TEXT NOT NULL,
                type        TEXT NOT NULL DEFAULT 'knowledge',
                importance  INTEGER NOT NULL DEFAULT 5,
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL,
                access_count INTEGER NOT NULL DEFAULT 0,
                UNIQUE(key)
            );

            CREATE TABLE IF NOT EXISTS facts (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                subject    TEXT NOT NULL,
                predicate  TEXT NOT NULL,
                object     TEXT NOT NULL,
                confidence REAL NOT NULL DEFAULT 1.0,
                created_at TEXT NOT NULL,
                UNIQUE(subject, predicate)
            );

            CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type);
            CREATE INDEX IF NOT EXISTS idx_facts_subject ON facts(subject);
        """)
        self._conn.commit()

    # ── CRUD principal ────────────────────────────────────────────────────────

    def save(self, key: str, value: Any,
             type_: str = TYPE_KNOWLEDGE,
             importance: int = 5) -> bool:
        """
        Salva ou atualiza uma memória.

        Args:
            key:        identificador único (ex: "nome_usuario", "cor_favorita")
            value:      qualquer valor serializável
            type_:      categoria (fact, preference, event, knowledge, command)
            importance: 1-10 (10 = mais importante)

        Returns:
            True se salvo com sucesso
        """
        agora      = datetime.now().isoformat()
        valor_str  = json.dumps(value, ensure_ascii=False) if not isinstance(value, str) else value

        try:
            self._conn.execute("""
                INSERT INTO memories (key, value, type, importance, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value      = excluded.value,
                    type       = excluded.type,
                    importance = excluded.importance,
                    updated_at = excluded.updated_at
            """, (key, valor_str, type_, importance, agora, agora))
            self._conn.commit()
            log.info(f"[LTM] Salvo: {key} = {valor_str[:60]}")
            return True
        except Exception as e:
            log.error(f"[LTM] Erro ao salvar '{key}': {e}")
            return False

    def get(self, key: str, default: Any = None) -> Any:
        """
        Recupera uma memória pelo identificador exato.

        Returns:
            Valor desserializado ou default se não encontrar
        """
        try:
            row = self._conn.execute(
                "SELECT value FROM memories WHERE key = ?", (key,)
            ).fetchone()

            if not row:
                return default

            # Registra acesso
            self._conn.execute(
                "UPDATE memories SET access_count = access_count + 1 WHERE key = ?", (key,)
            )
            self._conn.commit()

            # Tenta desserializar JSON; se falhar, retorna string pura
            try:
                return json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                return row["value"]

        except Exception as e:
            log.error(f"[LTM] Erro ao recuperar '{key}': {e}")
            return default

    def delete(self, key: str) -> bool:
        """Remove uma memória pelo identificador."""
        try:
            self._conn.execute("DELETE FROM memories WHERE key = ?", (key,))
            self._conn.commit()
            return True
        except Exception as e:
            log.error(f"[LTM] Erro ao deletar '{key}': {e}")
            return False

    def exists(self, key: str) -> bool:
        """Verifica se uma chave existe."""
        row = self._conn.execute(
            "SELECT 1 FROM memories WHERE key = ?", (key,)
        ).fetchone()
        return row is not None

    # ── Busca semântica ───────────────────────────────────────────────────────

    def search(self, query: str, top_k: int = 5, type_filter: str = None) -> list[dict]:
        """
        Busca memórias por similaridade semântica.

        Estratégia:
          1. Busca por palavras-chave no SQLite (rápido, sem dependências)
          2. Se sentence-transformers disponível → re-rank por embedding

        Args:
            query:       texto de consulta
            top_k:       máximo de resultados
            type_filter: filtra por tipo ("fact", "preference", etc.) ou None

        Returns:
            Lista de dicts: [{"key", "value", "type", "importance", "score"}]
        """
        # ── Busca por palavras-chave (always available) ───────────────────────
        palavras  = [p.strip() for p in query.lower().split() if len(p) > 2]
        condicoes = " OR ".join(["(LOWER(key) LIKE ? OR LOWER(value) LIKE ?)"] * len(palavras))
        params    = []
        for p in palavras:
            params.extend([f"%{p}%", f"%{p}%"])

        sql = f"SELECT key, value, type, importance FROM memories"
        if palavras:
            sql += f" WHERE {condicoes}"
            if type_filter:
                sql += f" AND type = ?"
                params.append(type_filter)
        elif type_filter:
            sql += f" WHERE type = ?"
            params = [type_filter]

        sql += " ORDER BY importance DESC, access_count DESC LIMIT ?"
        params.append(top_k * 3)  # busca mais para re-rank depois

        try:
            rows = self._conn.execute(sql, params).fetchall()
        except Exception as e:
            log.error(f"[LTM] Erro na busca: {e}")
            return []

        resultados = [
            {
                "key":       r["key"],
                "value":     r["value"],
                "type":      r["type"],
                "importance":r["importance"],
                "score":     r["importance"] / 10.0,
            }
            for r in rows
        ]

        # ── Re-rank semântico (se disponível) ─────────────────────────────────
        resultados = self._rerank_semantico(query, resultados, top_k)

        return resultados[:top_k]

    def _rerank_semantico(self, query: str, candidatos: list[dict], top_k: int) -> list[dict]:
        """Re-ordena candidatos por similaridade semântica com o query."""
        if not candidatos:
            return candidatos
        try:
            if self._embedder is None:
                from sentence_transformers import SentenceTransformer
                self._embedder = SentenceTransformer(config.EMBEDDING_MODEL)

            import numpy as np

            q_vec   = self._embedder.encode(query, normalize_embeddings=True)
            textos  = [f"{r['key']}: {r['value']}" for r in candidatos]
            vetores = self._embedder.encode(textos, normalize_embeddings=True)

            scores = np.dot(vetores, q_vec)
            for i, r in enumerate(candidatos):
                r["score"] = float(scores[i])

            candidatos.sort(key=lambda x: x["score"], reverse=True)
        except Exception:
            pass  # sem embeddings, usa a ordem do SQLite
        return candidatos

    # ── Fatos estruturados (triplas) ──────────────────────────────────────────

    def save_fact(self, subject: str, predicate: str, object_: str,
                  confidence: float = 1.0):
        """
        Salva um fato como tripla (sujeito, predicado, objeto).
        Ex: save_fact("usuário", "nome", "Carlos")
            save_fact("usuário", "cidade", "São Paulo")
        """
        agora = datetime.now().isoformat()
        try:
            self._conn.execute("""
                INSERT INTO facts (subject, predicate, object, confidence, created_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(subject, predicate) DO UPDATE SET
                    object     = excluded.object,
                    confidence = excluded.confidence
            """, (subject, predicate, object_, confidence, agora))
            self._conn.commit()
        except Exception as e:
            log.error(f"[LTM] Erro ao salvar fato: {e}")

    def get_fact(self, subject: str, predicate: str) -> Optional[str]:
        """Recupera o objeto de uma tripla."""
        row = self._conn.execute(
            "SELECT object FROM facts WHERE subject = ? AND predicate = ?",
            (subject, predicate)
        ).fetchone()
        return row["object"] if row else None

    def get_all_facts(self, subject: str) -> dict:
        """Retorna todos os fatos sobre um sujeito."""
        rows = self._conn.execute(
            "SELECT predicate, object FROM facts WHERE subject = ?", (subject,)
        ).fetchall()
        return {r["predicate"]: r["object"] for r in rows}

    # ── Utilitários ───────────────────────────────────────────────────────────

    def get_by_type(self, type_: str) -> list[dict]:
        """Lista todas as memórias de um tipo específico."""
        rows = self._conn.execute(
            "SELECT key, value, importance FROM memories WHERE type = ? ORDER BY importance DESC",
            (type_,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_user_context(self) -> str:
        """
        Retorna um resumo do contexto do usuário para injetar no LLM.
        Inclui fatos, preferências e memórias mais importantes.
        """
        partes = []

        # Fatos sobre o usuário
        fatos = self.get_all_facts("usuário")
        for pred, obj in fatos.items():
            partes.append(f"{pred}: {obj}")

        # Preferências
        prefs = self.get_by_type(self.TYPE_PREFERENCE)
        for p in prefs[:5]:
            partes.append(f"Prefere {p['key']}: {p['value']}")

        # Memórias importantes (importância ≥ 8)
        rows = self._conn.execute(
            "SELECT key, value FROM memories WHERE importance >= 8 ORDER BY importance DESC LIMIT 5"
        ).fetchall()
        for r in rows:
            partes.append(f"{r['key']}: {r['value']}")

        return " | ".join(partes) if partes else ""

    def stats(self) -> dict:
        """Retorna estatísticas da memória de longo prazo."""
        total  = self._conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        fatos  = self._conn.execute("SELECT COUNT(*) FROM facts").fetchone()[0]
        by_type = {}
        for row in self._conn.execute("SELECT type, COUNT(*) as n FROM memories GROUP BY type"):
            by_type[row["type"]] = row["n"]
        return {"total_memories": total, "total_facts": fatos, "by_type": by_type}

    def close(self):
        self._conn.close()
