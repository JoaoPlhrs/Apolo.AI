"""
agents/intent_parser.py - Classifica intencao do usuario
5+ variacoes por comando | 16 tipos de intencao
"""

import re
from dataclasses import dataclass, field


@dataclass
class Intencao:
    tipo:   str
    grupos: tuple = field(default_factory=tuple)
    texto:  str   = ""
    extras: dict  = field(default_factory=dict)


PADROES = [

    # Abrir sites
    ("abrir_site", [
        r"abr[ea]\s+(?:o\s+)?(?:site\s+)?(?:do\s+|da\s+)?(youtube|instagram|chatgpt|chat\s*gpt|spotify|github|gmail|whatsapp|twitter|reddit|linkedin|google)(?:\s+.*)?",
        r"(?:vai|vai\s+no|entra\s+no?|acessa|navega\s+(?:para|ate))\s+(youtube|instagram|chatgpt|spotify|github|gmail|whatsapp|twitter|reddit|linkedin|google)",
        r"(youtube|instagram|chatgpt|spotify)\s*(?:por favor|pls|pfv)?$",
        r"(?:me\s+)?(?:leva|leve)\s+(?:ao?|para\s+o?)\s+(youtube|instagram|chatgpt|spotify|github|gmail|whatsapp|twitter|reddit|linkedin|google)",
        r"(?:quero|abre?)\s+(?:o\s+)?(youtube|instagram|chatgpt|spotify|github|gmail|whatsapp|twitter|reddit|linkedin|google)",
    ]),

    # Abrir app local
    ("abrir_app", [
        r"abr[ea]\s+(?:o\s+|a\s+)?(?!youtube|instagram|chatgpt|spotify|github|gmail|whatsapp|twitter|reddit|linkedin)(.+)",
        r"inicia[r]?\s+(?:o\s+|a\s+)?(.+)",
        r"lan[cç]a[r]?\s+(?:o\s+|a\s+)?(.+)",
        r"roda[r]?\s+(?:o\s+|a\s+)?(.+)",
        r"abre\s+o\s+programa\s+(.+)",
    ]),

    # Busca na web
    ("buscar_web", [
        r"(?:pesquisa|busca|procura)[r]?\s+(?:no\s+)?(?:google|navegador|web|internet)?\s+(.+)",
        r"(?:google|googla)\s+(.+)",
        r"busca\s+(?:no\s+)?youtube\s+(.+)",
        r"(?:me\s+)?(?:mostra|mostre)\s+resultados?\s+(?:de|sobre|para)\s+(.+)",
        r"(?:faz|faca)\s+uma\s+busca\s+(?:por|sobre|de)\s+(.+)",
    ]),

    # Hora e data
    ("hora_data", [
        r"(?:que\s+)?horas?\s+(?:s[ao]o|est[aa]|tem)",
        r"que\s+hora\s+[ee]",
        r"hora[s]?\s+agora",
        r"qual\s+(?:a|[ee])\s+hora",
        r"(?:me\s+)?(?:diz|fala|qual\s+[ee])\s+(?:a\s+)?(?:hora|horas?)\s*(?:agora|atual)?",
        r"(?:qual\s+[ee]\s+)?(?:a\s+)?(?:data|dia)\s+(?:de\s+hoje|hoje|atual)?",
        r"(?:hoje\s+[ee]\s+)?(?:que\s+dia)",
        r"que\s+dia\s+[ee]\s+hoje",
        r"(?:qual\s+[ee]\s+a\s+)?data\s+de\s+hoje",
        r"que\s+horas?\s+t[ee]m",
        r"quant[ao]s?\s+horas?",
        r"qual\s+a\s+hr",
        r"que\s+hr\s+[ee]",
        r"(?:me\s+)?diga\s+(?:as\s+)?horas?",
        r"hora\s+(?:certa|atual|exata)",
    ]),

    # Rotina agendada - padrao mais especifico primeiro
    ("rotina_agendada", [
        r"todo\s+dia\s+(?:me\s+)?(?:lembr[ae]|avise)\s+(?:de\s+)?(.+)",
        r"toda\s+(?:segunda|ter[cc]a|quarta|quinta|sexta|s[aa]bado|domingo)(?:[- ]feira)?\s*,?\s*(?:me\s+)?(?:avise|avisa|lembre|lembra)\s+(?:sobre\s+|de\s+)?(.+)",
        r"(?:todo|toda)\s+(?:dia|semana|m[ee]s)\s+(?:me\s+)?(?:avise|avisa|lembre|lembra)\s+(?:sobre\s+|de\s+)?(.+)",
        r"cria[r]?\s+(?:uma\s+)?rotina\s+(?:para\s+|de\s+)?(.+)",
        r"agenda[r]?\s+(?:uma\s+)?rotina\s+(.+)",
        r"repeti[r]?\s+(?:toda\s+semana\s+)?(?:esse\s+)?lembrete\s+(?:de\s+)?(.+)",
    ]),

    # Lembrete simples
    ("lembrete", [
        r"(?:me\s+)?lembr[ae][r]?\s+(?:de\s+)?(.+?)(?:\s+[aa]s?\s+(\d{1,2}[h:]\d{0,2}|\d{1,2}\s*(?:horas?|h)))?$",
        r"(?:me\s+)?avisa[r]?\s+(?:para\s+)?(.+?)(?:\s+[aa]s?\s+(\d{1,2}[h:]\d{0,2}))?$",
        r"coloca[r]?\s+(?:um\s+)?lembrete\s+(?:para\s+)?(.+)",
        r"cria[r]?\s+(?:um\s+)?lembrete\s+(?:de\s+|para\s+)?(.+)",
        r"nao\s+me\s+deixa?\s+esquecer\s+(?:de\s+)?(.+)",
    ]),

    # Documento / analise
    ("documento", [
        r"(?:resume|resumir|resumo\s+d[eo])\s+(?:esse\s+|o\s+|este\s+)?(.+)",
        r"(?:analisa|analisar|analise)\s+(?:esse\s+|o\s+|este\s+)?(?:documento|arquivo|pdf|texto)\s*(.+)?",
        r"(?:extrai|extrair)\s+(?:o\s+)?(?:n[uu]mero\s+de\s+protocolo|dados?|informa[cc][oo]es?)(?:\s+(.+))?",
        r"(?:l[ee]|ler|leia)\s+(?:esse\s+|o\s+|este\s+)?(?:documento|arquivo|pdf)\s*(.+)?",
        r"(?:qual\s+[eeo]\s+)?(?:n[uu]mero\s+de\s+protocolo|data|valor|nome)\s+(?:d[eo]\s+)?(.+)",
        r"(?:o\s+que\s+(?:diz|fala|est[aa])\s+(?:n[eo]|neste))\s+(.+)",
    ]),

    # Busca de arquivo
    ("buscar_arquivo", [
        r"(?:procura|encontra|acha)[r]?\s+(?:o\s+)?arquivo\s+(?:chamado\s+)?(.+)",
        r"(?:onde\s+est[aa]|acha[r]?)\s+(?:o\s+)?(?:arquivo|pasta)\s+(.+)",
        r"(?:busca|buscar)\s+(?:o\s+)?arquivo\s+(.+)",
        r"(?:localiza|localizar)\s+(?:o\s+)?(?:arquivo|pasta|documento)\s+(.+)",
        r"(?:me\s+)?mostra\s+(?:o\s+)?arquivo\s+(.+)",
    ]),

    # Clima
    ("clima", [
        r"(?:como\s+est[aa]\s+)?(?:o\s+)?(?:clima|tempo|chuva|temperatura)\s+(?:em\s+|de\s+|n[ao]\s+)?(.+)?",
        r"vai\s+chover",
        r"est[aa]\s+(?:frio|quente|calor)",
        r"(?:qual\s+[ee]\s+)?(?:a\s+)?previs[ao]o\s+(?:do\s+tempo|clim[aa]tica)?\s*(?:em\s+|para\s+)?(.+)?",
        r"preciso\s+(?:levar\s+)?guarda[- ]?chuva",
    ]),

    # Tocar musica - 10 variacoes
    ("tocar_musica", [
        r"(?:toca[r]?|play|da\s+play)\s+(?:(?:a\s+)?m[uu]sica\s+)?(.+)",
        r"(?:coloca[r]?|bota[r]?|poe|ponha)\s+(?:(?:a\s+)?m[uu]sica\s+)?(.+)",
        r"(?:quero|queria|gostaria\s+de)\s+(?:ouvir|escutar)\s+(.+)",
        r"(?:me\s+)?(?:toca|toque)\s+(?:(?:a\s+)?m[uu]sica\s+)?(.+)",
        r"executa[r]?\s+a\s+m[uu]sica\s+(.+)",
        r"(?:ativa|ativar|liga[r]?)\s+(?:(?:a\s+)?m[uu]sica\s+)?(.+)",
        r"(.+)\s+no\s+(?:youtube|spotify)\s*$",
        r"(?:passa[r]?)\s+(?:(?:a\s+)?m[uu]sica\s+)?(.+)",
        r"m[uu]sica\s+(?:de\s+|do\s+|da\s+)?(.+)",
        r"(?:pe[cc]o|pe[cc]a)\s+(?:a\s+m[uu]sica\s+)?(.+)",
        # Frases informais / gírias
        r"(?:bota|coloca|joga|manda|rola)\s+(?:um|uma|o|a)?\s*(.+?)\s+(?:pra|para)\s+(?:n[oó]is|a gente|mim|eu|r[oo]lar)(?:\s+.*)?$",
        r"(?:fala\s+(?:mano|brother|bro|cara),?\s+)?(?:que\s+)?(?:bota|coloca|joga|manda|p[oõ]e)\s+(?:um|uma)?\s*(.+?)\s+(?:pra|para)\s+(?:n[oó]is|a gente|mim|eu)(?:\s+.*)?$",
        r"(?:vai|vamo|vamos)\s+(?:ouvir|escutar|rolar)\s+(.+?)(?:\s+(?:pra|para)\s+(?:n[oó]is|a gente))?\s*$",
        r"(?:rola|bora)\s+(?:um|uma)?\s+(.+?)(?:\s+(?:pra|para)\s+(?:n[oó]is|a gente))?\s*$",
    ]),

    # Pesquisar na internet - 9 variacoes
    ("pesquisar_internet", [
        r"pesquise?\s+(?:na\s+internet|na\s+web|no\s+google)\s+(.+)",
        r"pesquise?\s+(?:sobre\s+)?(.+)\s+na\s+(?:internet|web)",
        r"busque?\s+na\s+internet\s+(.+)",
        r"procure?\s+na\s+(?:internet|web)\s+(.+)",
        r"(?:me\s+)?(?:fala|conta|explica)\s+(?:sobre|o\s+que\s+[ee])\s+(.+)",
        r"o\s+que\s+[ee]\s+(.+)",
        r"quem\s+[ee]\s+(.+)",
        r"(?:qual\s+[ee]\s+)?(?:a\s+)?(?:capital|presidente|populacao|origem)\s+(?:d[eo]\s+)?(.+)",
        r"(?:me\s+)?informa\s+(?:sobre\s+)?(?!clima|tempo|chuva)(.+)",
    ]),

    # Identidade
    ("identidade", [
        r"o\s+que\s+(?:voc[ee]|tu)\s+(?:faz|e|pode|consegue|sabe)",
        r"quem\s+[ee]\s+(?:voc[ee]|o\s+apolo)",
        r"(?:me\s+)?(?:fala|conta|diz)\s+(?:sobre\s+)?(?:voc[ee]|o\s+apolo)",
        r"(?:qual\s+[ee]\s+)?(?:sua\s+)?(?:fun[cc][ao]o|prop[oo]sito|utilidade)",
        r"para\s+que\s+(?:serve|voce\s+serve)",
        r"o\s+que\s+[ee]\s+o?\s*apolo",
        r"(?:o\s+que|quais)\s+(?:voc[ee]\s+)?(?:pode[s]?\s+)?fazer",
        r"(?:suas?\s+)?(?:funcionalidades?|recursos?|capacidades?)",
    ]),

    # Layout
    ("layout", [
        r"^layout$",
        r"^painel$",
        r"(?:mostra|exibe|ver|veja)\s+(?:o\s+)?(?:layout|painel|status)",
        r"(?:qual\s+[ee]\s+)?(?:o\s+)?status\s+(?:do\s+)?(?:sistema|apolo)",
        r"informacoes?\s+(?:do\s+)?(?:sistema|apolo)",
    ]),

    # Limpar
    ("limpar", [
        r"(?:limpa[r]?|apaga[r]?|zera[r]?)\s+(?:o\s+)?(?:hist[oo]rico|conversa|mem[oo]ria)",
        r"esquece\s+(?:tudo|nossa\s+conversa)",
        r"nova\s+conversa",
        r"(?:reinicia[r]?|reseta[r]?)\s+(?:a\s+)?conversa",
        r"(?:come[cc]a[r]?\s+)?(?:do\s+)?zero",
    ]),

    # Sair - 5 variacoes
    ("sair", [
        r"(?:sai[r]?|fecha[r]?|encerra[r]?|desliga[r]?)\s+(?:o\s+)?apolo",
        r"(?:tchau|adeus|xau|ate\s+mais|falou)\s*(?:apolo)?",
        r"para[r]?\s+(?:o\s+)?apolo",
        r"(?:pode\s+)?(?:ir\s+embora|se\s+despedir)",
        r"(?:desligo|vou\s+fechar|vou\s+sair)\s+(?:o\s+)?apolo",
    ]),
]


class IntentParser:
    def __init__(self):
        self.regras = []
        for tipo, padroes in PADROES:
            for p in padroes:
                self.regras.append(
                    (tipo, re.compile(p, re.IGNORECASE | re.UNICODE))
                )

    def analisar(self, texto: str) -> dict:
        texto_limpo = texto.strip()
        for tipo, regex in self.regras:
            match = regex.search(texto_limpo)
            if match:
                grupos = tuple(
                    g.strip() if g else "" for g in match.groups()
                )
                return {"tipo": tipo, "grupos": grupos,
                        "texto": texto_limpo, "extras": {}}
        return {"tipo": "chat", "grupos": (), "texto": texto_limpo, "extras": {}}
