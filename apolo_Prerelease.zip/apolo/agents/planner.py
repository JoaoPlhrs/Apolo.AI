"""
agents/planner.py — Executa ações com base na intenção detectada (V2.5)

Adicionados:
  - abrir_site → WebCommands.abrir_site()
  - hora_data  → utils/time_utils.py (timezone Brasil)
"""

from commands.system_commands import SystemCommands
from commands.web_commands import WebCommands
from agents.scheduler import Scheduler
from utils.logger import log
from utils.time_utils import speak_time, speak_date


class Planner:
    def __init__(self):
        self.sistema   = SystemCommands()
        self.web       = WebCommands()
        self.scheduler = Scheduler()

    def executar(self, intencao: dict) -> dict:
        """
        Executa a ação correspondente à intenção.
        Retorna: {"executado": bool, "resposta": str}
        """
        tipo   = intencao["tipo"]
        grupos = intencao.get("grupos", ())
        texto  = intencao.get("texto", "")

        try:
            # ── Abrir site (YouTube, Instagram, etc.) ─────────────────────────
            if tipo == "abrir_site":
                site = grupos[0] if grupos else texto
                site = site.replace("chat gpt", "chatgpt").strip()
                resp = self.web.abrir_site(site)
                return {"executado": True, "resposta": resp}

            # ── Abrir aplicativo local ─────────────────────────────────────────
            elif tipo == "abrir_app":
                app = grupos[0] if grupos else texto
                # Redireciona sites reconhecidos para abrir_site
                # APENAS sites sem app local — apps como spotify/discord
                # ficam no SystemCommands (abrir_app) para abrir o executável
                sites_conhecidos = [
                    "youtube", "instagram", "chatgpt",
                    "github", "gmail", "whatsapp", "twitter",
                ]
                if any(s in app.lower() for s in sites_conhecidos):
                    resp = self.web.abrir_site(app)
                    return {"executado": True, "resposta": resp}
                ok = self.sistema.abrir_app(app)
                return {
                    "executado": True,
                    "resposta":  f"Abrindo {app}." if ok
                                 else f"Não encontrei o aplicativo '{app}'.",
                }

            # ── Buscar na web ──────────────────────────────────────────────────
            elif tipo == "buscar_web":
                consulta = grupos[0] if grupos else texto
                if "youtube" in texto.lower():
                    resp = self.web.buscar_youtube(consulta)
                elif consulta:
                    resp = self.web.buscar_google(consulta)
                else:
                    self.web.abrir_navegador()
                    resp = "Abrindo o navegador."
                return {"executado": True, "resposta": resp}

            # ── Hora e data (com timezone de Brasília) ─────────────────────────
            elif tipo == "hora_data":
                t = texto.lower()
                if any(x in t for x in ["data", "dia", "hoje"]):
                    if any(x in t for x in ["hora", "horas", "que hora"]):
                        # Pede data E hora juntos
                        from utils.time_utils import speak_datetime
                        resp = speak_datetime()
                    else:
                        resp = speak_date()
                else:
                    # Padrão: só hora
                    resp = speak_time()
                return {"executado": True, "resposta": resp}

            # ── Lembrete ──────────────────────────────────────────────────────
            elif tipo == "lembrete":
                tarefa  = grupos[0] if grupos else "lembrete"
                horario = grupos[1] if len(grupos) > 1 and grupos[1] else None
                msg     = self.scheduler.adicionar_lembrete(tarefa, horario)
                return {"executado": True, "resposta": msg}

            # ── Buscar arquivo ────────────────────────────────────────────────
            elif tipo == "buscar_arquivo":
                nome     = grupos[0] if grupos else texto
                resultado = self.sistema.buscar_arquivo(nome)
                return {"executado": True, "resposta": resultado}

            # ── Clima ─────────────────────────────────────────────────────────
            elif tipo == "clima":
                cidade = grupos[0] if grupos and grupos[0] else None
                from tools.weather import WeatherTool
                resp   = WeatherTool().consultar(cidade)
                return {"executado": True, "resposta": resp}


            # ── Identidade / consciência ──────────────────────────────────────
            elif tipo == "identidade":
                from core.version import get_version
                resp = (
                    f"Sou o APOLO, seu assistente pessoal local. 😊 "
                    f"Versão {get_version()}. "
                    f"Posso abrir aplicativos e sites, informar as horas, "
                    f"tocar músicas no YouTube, pesquisar na internet, "
                    f"fazer lembretes e responder perguntas. "
                    f"Tudo isso sem precisar de internet para funcionar!"
                )
                return {"executado": True, "resposta": resp}

            # ── Layout / painel de status ──────────────────────────────────────
            elif tipo == "layout":
                return {"executado": True, "resposta": "__LAYOUT__"}

            # ── Tocar música ───────────────────────────────────────────────────
            # Tocar musica no Spotify (app ou web)
            # Tocar musica — YouTube com autoplay real via API
            elif tipo == "tocar_musica":
                from tools.youtube_music import tocar_musica
                import re as _re
                musica = grupos[0].strip() if grupos and grupos[0] else texto

                # Remove ruído semântico que não faz parte do título
                # Ex: "toque um black in black ai" → "black in black"
                NOISE_PREFIXO = (
                    r"^(?:um|uma|o|a|os|as|mais|bem|aí|ai|né|neh|lá|la|"
                    r"agora|já|ja|rápido|rapido|pra mim|para mim|"
                    r"por favor|pfv|pls|please)\s+"
                )
                NOISE_SUFIXO = (
                    r"\s+(?:aí|ai|né|neh|lá|la|agora|já|ja|por favor|"
                    r"pfv|pls|please|pra mim|para mim|obrigad[oa])$"
                )
                musica = _re.sub(NOISE_PREFIXO, "", musica, flags=_re.IGNORECASE)
                musica = _re.sub(NOISE_SUFIXO,  "", musica, flags=_re.IGNORECASE)
                musica = musica.strip()
                resp = tocar_musica(musica)
                return {"executado": True, "resposta": resp}
            elif tipo == "pesquisar_internet":
                consulta = grupos[0].strip() if grupos and grupos[0] else texto
                if not consulta:
                    return {"executado": True, "resposta": "O que voce quer que eu pesquise?"}
                from tools.search import pesquisar
                resultado = pesquisar(consulta, abrir_browser=True)
                return {"executado": True, "resposta": resultado}
            # ── Documento / análise ──────────────────────────────────────────
            elif tipo == "documento":
                from tools.document_analyzer import DocumentAnalyzer
                da = DocumentAnalyzer()
                # Tenta injetar LLM se disponível
                try:
                    from core.llm_engine import LLMEngine
                    da.set_llm(LLMEngine())
                except Exception:
                    pass
                consulta = grupos[0].strip() if grupos and grupos[0] else texto
                # Verifica se é um caminho de arquivo
                import os as _os
                if _os.path.exists(_os.path.expanduser(consulta)):
                    resp = da.analisar_arquivo(consulta)
                elif any(x in texto.lower() for x in ["extrai", "extrair", "número", "protocolo", "cpf", "valor"]):
                    resp = "Por favor, cole o texto do documento para eu extrair os dados."
                else:
                    resp = "Cole o texto ou informe o caminho do arquivo para eu analisar."
                return {"executado": True, "resposta": resp}

            # ── Rotina agendada recorrente ────────────────────────────────────
            elif tipo == "rotina_agendada":
                import re as _re
                descricao = grupos[0].strip() if grupos and grupos[0] else texto

                # Detecta frequência
                t_lower = texto.lower()
                if any(d in t_lower for d in ["segunda","terça","terca","quarta","quinta","sexta","sábado","sabado","domingo"]):
                    frequencia = "semanal"
                    dias_map = {"segunda":0,"terca":1,"terça":1,"quarta":2,"quinta":3,"sexta":4,"sabado":5,"sábado":5,"domingo":6}
                    dia_semana = next((d for d in dias_map if d in t_lower), "segunda")
                elif "todo dia" in t_lower or "diário" in t_lower or "diario" in t_lower:
                    frequencia = "diario"; dia_semana = None
                elif "todo mês" in t_lower or "mensal" in t_lower:
                    frequencia = "mensal"; dia_semana = None
                else:
                    frequencia = "semanal"; dia_semana = "segunda"

                # Detecta horário
                m_hor = _re.search(r"(\d{1,2}[h:]\d{0,2})", texto)
                horario = m_hor.group(1) if m_hor else "09:00"

                from agents.advanced_scheduler import AdvancedScheduler
                adv = AdvancedScheduler()
                adv.set_callback(self.scheduler._callback_alerta)
                adv.set_simple_scheduler(self.scheduler)

                # Verifica se é rotina complexa (múltiplas ações)
                if "lembrete" in t_lower and ("ligar" in t_lower or "verificar" in t_lower or "e " in t_lower):
                    # Rotina complexa com múltiplas ações
                    acoes = [{"tipo": "mensagem", "texto": descricao}]
                    # Detecta ações adicionais pela conjunção "e"
                    partes = _re.split(r"\se\s", descricao, flags=_re.IGNORECASE)
                    if len(partes) > 1:
                        acoes = [{"tipo": "lembrete", "texto": p.strip()} for p in partes]
                    nome = f"rotina_{abs(hash(descricao)) % 9999}"
                    resp = adv.agendar_rotina_complexa(
                        nome=nome, descricao=descricao,
                        frequencia=frequencia, dia_semana=dia_semana,
                        horario=horario, acoes=acoes
                    )
                else:
                    nome = f"lembrete_{abs(hash(descricao)) % 9999}"
                    resp = adv.agendar_recorrente(
                        nome=nome, descricao=descricao,
                        frequencia=frequencia, dia_semana=dia_semana,
                        horario=horario
                    )
                return {"executado": True, "resposta": resp}

            elif tipo == "limpar":
                return {"executado": True, "resposta": "__LIMPAR__"}

            # ── Sair ──────────────────────────────────────────────────────────
            elif tipo == "sair":
                return {"executado": True, "resposta": "__SAIR__"}

        except Exception as e:
            log.error(f"[Planner] Erro em '{tipo}': {e}")
            return {
                "executado": True,
                "resposta":  f"Tive um problema ao executar: {e}",
            }

        return {"executado": False, "resposta": ""}
