"""agents/scheduler.py — Lembretes e tarefas agendadas

Usa APScheduler se disponível. Se não instalado, cai para um
scheduler simples baseado em threading — sem dependência externa.

Instale para funcionalidade completa:
    pip install apscheduler
"""

import re
import threading
import time
from datetime import datetime, timedelta
from utils.logger import log


# ── Verifica se apscheduler está disponível ────────────────────────────────────
try:
    from apscheduler.schedulers.background import BackgroundScheduler
    _TEM_APSCHEDULER = True
except ImportError:
    _TEM_APSCHEDULER = False
    log.warning("[Scheduler] apscheduler não instalado. Usando scheduler simples.")
    log.warning("[Scheduler] Para lembretes completos: pip install apscheduler")


# ── Scheduler simples baseado em threading (fallback sem dependência) ──────────

class _SchedulerSimples:
    """
    Scheduler mínimo usando threads.
    Não requer nenhuma dependência externa.
    Funciona para lembretes básicos com data/hora.
    """
    def __init__(self):
        self._jobs: list[dict] = []
        self._rodando = True
        self._thread  = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def add_job(self, func, trigger, run_date, args=None, id=None,
                name=None, misfire_grace_time=60):
        self._jobs.append({
            "id":       id or str(len(self._jobs)),
            "func":     func,
            "args":     args or [],
            "run_date": run_date,
            "nome":     name or "",
            "disparado":False,
        })

    def _loop(self):
        while self._rodando:
            agora = datetime.now()
            for job in self._jobs:
                if not job["disparado"] and agora >= job["run_date"]:
                    job["disparado"] = True
                    try:
                        threading.Thread(
                            target=job["func"],
                            args=job["args"],
                            daemon=True
                        ).start()
                    except Exception as e:
                        log.error(f"[Scheduler] Erro ao disparar lembrete: {e}")
            time.sleep(5)  # checa a cada 5 segundos

    def shutdown(self, wait=False):
        self._rodando = False


# ══════════════════════════════════════════════════════════════════════════════
# Classe pública Scheduler
# ══════════════════════════════════════════════════════════════════════════════

class Scheduler:
    def __init__(self):
        # Usa APScheduler se disponível, senão o fallback simples
        if _TEM_APSCHEDULER:
            self.scheduler = BackgroundScheduler(timezone="America/Sao_Paulo")
            self.scheduler.start()
        else:
            self.scheduler = _SchedulerSimples()

        self._callback_alerta = None
        self.lembretes: list[dict] = []

    def definir_callback(self, fn):
        """Define a função chamada quando um lembrete disparar."""
        self._callback_alerta = fn

    def adicionar_lembrete(self, tarefa: str, horario_str: str = None) -> str:
        """
        Adiciona um lembrete.
        horario_str: "18h", "18:30", "às 9h", ou None (em 5 minutos)
        """
        agora = datetime.now()

        if horario_str:
            hora, minuto = self._parse_horario(horario_str)
            disparo = agora.replace(hour=hora, minute=minuto, second=0)
            if disparo < agora:
                disparo += timedelta(days=1)
            horario_fmt = disparo.strftime("%H:%M")
        else:
            disparo     = agora + timedelta(minutes=5)
            horario_fmt = "em 5 minutos"

        job_id = f"lembrete_{len(self.lembretes)}"
        self.scheduler.add_job(
            func               = self._disparar,
            trigger            = "date",
            run_date           = disparo,
            args               = [tarefa],
            id                 = job_id,
            name               = tarefa,
            misfire_grace_time = 60,
        )
        self.lembretes.append({"id": job_id, "tarefa": tarefa, "horario": disparo})
        log.info(f"Lembrete agendado: '{tarefa}' às {horario_fmt}")
        return f"Lembrete criado: '{tarefa}' às {horario_fmt}."

    def _disparar(self, tarefa: str):
        msg = f"🔔 LEMBRETE: {tarefa}"
        log.info(msg)
        if self._callback_alerta:
            self._callback_alerta(msg)
        else:
            print(f"\n\n{msg}\n")

    def _parse_horario(self, texto: str) -> tuple[int, int]:
        texto = texto.lower().strip()
        m = re.search(r"(\d{1,2})[h:](\d{2})?", texto)
        if m:
            return int(m.group(1)), int(m.group(2)) if m.group(2) else 0
        m = re.search(r"(\d{1,2})", texto)
        if m:
            return int(m.group(1)), 0
        return datetime.now().hour, 0

    def listar(self) -> list[dict]:
        return self.lembretes

    def parar(self):
        try:
            self.scheduler.shutdown(wait=False)
        except Exception:
            pass
