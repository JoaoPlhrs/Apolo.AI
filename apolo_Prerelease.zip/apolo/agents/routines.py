"""
agents/routines.py — Sistema de rotinas do APOLO

Uma rotina é uma sequência de ações executadas com um único comando.
Rotinas podem ser registradas via código ou por comando de voz.

Rotinas padrão:
    "bom dia"     → clima + hora + frase motivacional
    "modo estudo" → abre VSCode + Spotify + silencia notificações

Uso:
    from agents.routines import RoutineManager
    RoutineManager.run_routine("bom dia")
    RoutineManager.register_routine("meu atalho", [action1, action2])
"""

import json
import os
import time
from datetime import datetime
from typing import Callable, Any
import config
from utils.logger import log

ROUTINES_FILE = os.path.join(config.DATA_DIR, "routines.json")


# ── Tipos de ação ─────────────────────────────────────────────────────────────

class ActionType:
    FALAR      = "falar"       # TTS: falar um texto
    ABRIR_APP  = "abrir_app"   # abrir aplicativo
    ABRIR_URL  = "abrir_url"   # abrir URL no navegador
    CLIMA      = "clima"       # consultar clima
    HORA       = "hora"        # dizer a hora
    LLM        = "llm"         # perguntar algo ao LLM
    ESPERAR    = "esperar"     # aguardar N segundos
    CUSTOM     = "custom"      # função Python customizada


def _executar_acao(acao: dict, ctx: dict) -> str:
    """Executa uma ação e retorna o resultado como string."""
    tipo   = acao.get("type", "")
    params = acao.get("params", {})

    try:
        if tipo == ActionType.FALAR:
            return params.get("text", "")

        elif tipo == ActionType.ABRIR_APP:
            from commands.system_commands import SystemCommands
            sc = SystemCommands()
            nome = params.get("app", "")
            ok   = sc.abrir_app(nome)
            return f"{'Abrindo' if ok else 'Não encontrei'} {nome}."

        elif tipo == ActionType.ABRIR_URL:
            import webbrowser
            url = params.get("url", "")
            webbrowser.open(url)
            return f"Abrindo {params.get('label', url)}."

        elif tipo == ActionType.CLIMA:
            from tools.weather import WeatherTool
            cidade = params.get("cidade") or ctx.get("cidade_usuario")
            return WeatherTool().consultar(cidade)

        elif tipo == ActionType.HORA:
            agora = datetime.now()
            dias  = ["segunda","terça","quarta","quinta","sexta","sábado","domingo"]
            return f"São {agora.strftime('%H:%M')} de {dias[agora.weekday()]}."

        elif tipo == ActionType.LLM:
            # ctx["llm"] é injetado pelo RoutineManager
            if "llm" in ctx:
                prompt = params.get("prompt", "diga algo motivacional em uma frase")
                resp   = ctx["llm"].gerar(prompt)
                return resp
            return ""

        elif tipo == ActionType.ESPERAR:
            time.sleep(float(params.get("seconds", 1)))
            return ""

        elif tipo == ActionType.CUSTOM:
            fn_name = params.get("fn")
            if fn_name and fn_name in ctx.get("custom_fns", {}):
                return ctx["custom_fns"][fn_name]()
            return ""

    except Exception as e:
        log.error(f"[Rotina] Erro na ação '{tipo}': {e}")
        return ""

    return ""


# ── Rotinas padrão embutidas ──────────────────────────────────────────────────

ROTINAS_PADRAO: dict[str, list[dict]] = {
    "bom dia": [
        {"type": ActionType.HORA, "params": {}},
        {"type": ActionType.FALAR, "params": {"text": "Bom dia! Vamos ver como está o tempo..."}},
        {"type": ActionType.CLIMA, "params": {"cidade": None}},   # usa cidade do perfil
        {"type": ActionType.LLM,  "params": {"prompt": "Diga uma frase motivacional curta em português."}},
    ],
    "boa noite": [
        {"type": ActionType.HORA,  "params": {}},
        {"type": ActionType.FALAR, "params": {"text": "Boa noite! Hora de descansar."}},
        {"type": ActionType.LLM,   "params": {"prompt": "Diga uma boa noite curta e tranquila em português."}},
    ],
    "modo estudo": [
        {"type": ActionType.FALAR,     "params": {"text": "Ativando modo estudo. Foco total!"}},
        {"type": ActionType.ABRIR_APP, "params": {"app": "vscode"}},
        {"type": ActionType.ESPERAR,   "params": {"seconds": 1}},
        {"type": ActionType.ABRIR_URL, "params": {"url": "https://open.spotify.com/genre/focus-playlists",
                                                   "label": "Spotify Focus"}},
        {"type": ActionType.FALAR,     "params": {"text": "Ambiente de estudo pronto. Bons estudos!"}},
    ],
    "modo trabalho": [
        {"type": ActionType.FALAR,     "params": {"text": "Modo trabalho ativado."}},
        {"type": ActionType.ABRIR_APP, "params": {"app": "vscode"}},
        {"type": ActionType.ABRIR_URL, "params": {"url": "https://mail.google.com", "label": "Gmail"}},
        {"type": ActionType.HORA,      "params": {}},
    ],
    "notícias": [
        {"type": ActionType.FALAR, "params": {"text": "Buscando as notícias de hoje..."}},
        {"type": ActionType.LLM,   "params": {"prompt": "Resuma brevemente os principais acontecimentos do Brasil hoje, de forma concisa."}},
    ],
}


class _RoutineManager:
    """Singleton — gerencia e executa rotinas."""

    def __init__(self):
        self._rotinas: dict[str, list[dict]] = dict(ROTINAS_PADRAO)
        self._custom_fns: dict[str, Callable] = {}
        self._llm_ref = None          # referência ao LLMEngine (injetada pelo dispatcher)
        self._perfil_ref = None       # referência ao UserProfile
        self._load()

    def _load(self):
        """Carrega rotinas customizadas salvas pelo usuário."""
        if os.path.exists(ROUTINES_FILE):
            try:
                with open(ROUTINES_FILE, "r", encoding="utf-8") as f:
                    salvas = json.load(f)
                self._rotinas.update(salvas)
                log.info(f"[Rotinas] {len(salvas)} rotinas customizadas carregadas")
            except Exception as e:
                log.warning(f"[Rotinas] Erro ao carregar: {e}")

    def _save(self):
        """Salva apenas as rotinas customizadas (não as padrão)."""
        customizadas = {
            k: v for k, v in self._rotinas.items()
            if k not in ROTINAS_PADRAO
        }
        try:
            os.makedirs(config.DATA_DIR, exist_ok=True)
            with open(ROUTINES_FILE, "w", encoding="utf-8") as f:
                json.dump(customizadas, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log.warning(f"[Rotinas] Erro ao salvar: {e}")

    # ── API principal ──────────────────────────────────────────────────────────

    def run_routine(self, name: str) -> list[str]:
        """
        Executa uma rotina pelo nome.

        Args:
            name: nome da rotina (case-insensitive)

        Returns:
            Lista de strings com os resultados de cada ação.
            Strings vazias são ignoradas (ações silenciosas).
        """
        nome_norm = name.lower().strip()

        # Busca correspondência parcial
        rotina = self._rotinas.get(nome_norm)
        if not rotina:
            for chave in self._rotinas:
                if nome_norm in chave or chave in nome_norm:
                    rotina = self._rotinas[chave]
                    nome_norm = chave
                    break

        if not rotina:
            log.warning(f"[Rotinas] Rotina não encontrada: '{name}'")
            return [f"Rotina '{name}' não existe. Rotinas disponíveis: {', '.join(self.list_routines())}"]

        log.info(f"[Rotinas] Executando: '{nome_norm}' ({len(rotina)} ações)")

        # Contexto passado para cada ação
        ctx = {
            "llm":         self._llm_ref,
            "custom_fns":  self._custom_fns,
            "cidade_usuario": self._perfil_ref.get("cidade") if self._perfil_ref else None,
        }

        resultados = []
        for acao in rotina:
            resultado = _executar_acao(acao, ctx)
            if resultado:
                resultados.append(resultado)

        return resultados

    def register_routine(self, name: str, actions: list[dict],
                         persistir: bool = True) -> bool:
        """
        Registra uma nova rotina.

        Args:
            name:     nome da rotina
            actions:  lista de dicts com {"type": ..., "params": {...}}
            persistir: salva em disco (default True)

        Exemplo:
            register_routine("café", [
                {"type": "falar", "params": {"text": "Hora do café!"}},
                {"type": "abrir_url", "params": {"url": "https://youtube.com", "label": "YouTube"}},
            ])
        """
        nome_norm = name.lower().strip()
        self._rotinas[nome_norm] = actions
        if persistir:
            self._save()
        log.info(f"[Rotinas] Registrada: '{nome_norm}' ({len(actions)} ações)")
        return True

    def register_custom_fn(self, name: str, fn: Callable):
        """Registra uma função Python para usar em ações CUSTOM."""
        self._custom_fns[name] = fn

    def delete_routine(self, name: str) -> bool:
        """Remove uma rotina (não pode remover as padrão)."""
        nome_norm = name.lower().strip()
        if nome_norm in ROTINAS_PADRAO:
            log.warning(f"[Rotinas] Não é possível remover rotina padrão: '{nome_norm}'")
            return False
        if nome_norm in self._rotinas:
            del self._rotinas[nome_norm]
            self._save()
            return True
        return False

    def list_routines(self) -> list[str]:
        """Retorna lista de nomes de rotinas disponíveis."""
        return sorted(self._rotinas.keys())

    def set_llm(self, llm):
        """Injeta referência ao LLMEngine."""
        self._llm_ref = llm

    def set_perfil(self, perfil):
        """Injeta referência ao UserProfile."""
        self._perfil_ref = perfil


# ── Instância global ───────────────────────────────────────────────────────────
RoutineManager = _RoutineManager()
