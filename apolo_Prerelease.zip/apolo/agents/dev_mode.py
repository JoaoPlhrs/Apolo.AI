"""
agents/dev_mode.py — Modo desenvolvedor do APOLO

Transforma o APOLO em assistente de código:
  - Gera código a partir de prompts em linguagem natural
  - Explica código existente
  - Abre arquivos de projetos
  - Detecta linguagem automaticamente

Uso:
    from agents.dev_mode import DevMode
    DevMode.set_llm(llm_engine)
    codigo = DevMode.generate_code("crie uma função que soma dois números em Python")
    DevMode.explain_code("def foo(x): return x*2")
"""

import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional
from utils.logger import log


# Linguagens suportadas para detecção automática
LANG_PATTERNS = {
    "python":     [r"\.py$", r"\bdef\b", r"\bimport\b", r"\bprint\("],
    "javascript": [r"\.js$", r"\bconst\b", r"\blet\b", r"\bconsole\.log"],
    "typescript": [r"\.ts$", r"\binterface\b", r"\btype\b.*="],
    "java":       [r"\.java$", r"\bpublic class\b", r"\bSystem\.out"],
    "c":          [r"\.c$", r"#include", r"\bprintf\("],
    "cpp":        [r"\.(cpp|cc|cxx)$", r"#include.*<iostream>", r"\bcout\b"],
    "html":       [r"\.html?$", r"<html", r"<!DOCTYPE"],
    "css":        [r"\.css$", r"\{.*:.*;\}", r"@media"],
    "sql":        [r"\.sql$", r"\bSELECT\b", r"\bCREATE TABLE\b"],
    "bash":       [r"\.(sh|bash)$", r"^#!/bin/bash", r"\becho\b"],
    "rust":       [r"\.rs$", r"\bfn main\b", r"\blet mut\b"],
    "go":         [r"\.go$", r"\bfunc main\b", r"package main"],
}

CODE_BLOCK_RE = re.compile(r"```(?:\w+)?\n?(.*?)```", re.DOTALL)


def _extrair_codigo(texto: str) -> str:
    """Extrai código de bloco markdown ou retorna texto limpo."""
    matches = CODE_BLOCK_RE.findall(texto)
    if matches:
        return max(matches, key=len).strip()
    return texto.strip()


def _detectar_linguagem(codigo: str, path: str = "") -> str:
    """Detecta a linguagem de programação do código."""
    texto = path + "\n" + codigo
    for lang, patterns in LANG_PATTERNS.items():
        if any(re.search(p, texto, re.IGNORECASE | re.MULTILINE) for p in patterns):
            return lang
    return "código"


class _DevMode:
    """Singleton — assistente de código do APOLO."""

    def __init__(self):
        self._llm = None
        self._projeto_atual: Optional[str] = None  # pasta do projeto aberto

    def set_llm(self, llm):
        """Injeta referência ao LLMEngine."""
        self._llm = llm

    # ── API principal ──────────────────────────────────────────────────────────

    def generate_code(self, prompt: str, linguagem: str = "python") -> str:
        """
        Gera código a partir de um prompt em linguagem natural.

        Args:
            prompt:    descrição do que o código deve fazer
            linguagem: linguagem alvo (python, js, etc.)

        Returns:
            Código gerado como string
        """
        if not self._llm:
            return "Erro: LLM não disponível no modo dev."

        instrucao = (
            f"Você é um programador especialista em {linguagem}. "
            f"Gere APENAS o código, sem explicações antes ou depois. "
            f"Use comentários no código quando necessário. "
            f"Código limpo, idiomático e funcional.\n\n"
            f"Tarefa: {prompt}"
        )

        try:
            resposta = self._llm.gerar(instrucao)
            codigo   = _extrair_codigo(resposta)
            log.info(f"[DevMode] Código gerado ({linguagem}): {len(codigo)} chars")
            return codigo
        except Exception as e:
            log.error(f"[DevMode] Erro ao gerar código: {e}")
            return f"Erro ao gerar código: {e}"

    def explain_code(self, code: str, nivel: str = "medio") -> str:
        """
        Explica um trecho de código.

        Args:
            code:  código a ser explicado
            nivel: "basico" | "medio" | "avancado"

        Returns:
            Explicação em português
        """
        if not self._llm:
            return "Erro: LLM não disponível."

        lang = _detectar_linguagem(code)
        niveis = {
            "basico":   "para um iniciante, de forma simples",
            "medio":    "de forma clara e objetiva",
            "avancado": "com detalhes técnicos, padrões e possíveis otimizações",
        }
        estilo = niveis.get(nivel, niveis["medio"])

        instrucao = (
            f"Explique o seguinte código em {lang} {estilo}. "
            f"Responda em português. Seja direto.\n\n"
            f"```{lang}\n{code}\n```"
        )

        try:
            return self._llm.gerar(instrucao)
        except Exception as e:
            return f"Erro ao explicar código: {e}"

    def review_code(self, code: str) -> str:
        """Faz code review e sugere melhorias."""
        if not self._llm:
            return "LLM não disponível."

        lang = _detectar_linguagem(code)
        instrucao = (
            f"Faça um code review do seguinte código em {lang}. "
            f"Aponte: bugs, melhorias de performance, legibilidade e boas práticas. "
            f"Responda em português, de forma objetiva.\n\n"
            f"```{lang}\n{code}\n```"
        )
        return self._llm.gerar(instrucao)

    def fix_code(self, code: str, error_msg: str = "") -> str:
        """Corrige um bug no código."""
        if not self._llm:
            return "LLM não disponível."

        lang = _detectar_linguagem(code)
        contexto_erro = f"\nMensagem de erro: {error_msg}" if error_msg else ""
        instrucao = (
            f"Corrija o bug no seguinte código {lang}.{contexto_erro}\n"
            f"Retorne APENAS o código corrigido, sem explicações.\n\n"
            f"```{lang}\n{code}\n```"
        )
        resposta = self._llm.gerar(instrucao)
        return _extrair_codigo(resposta)

    def open_project_file(self, path: str) -> str:
        """
        Abre um arquivo de projeto no editor padrão (VSCode se disponível).

        Args:
            path: caminho relativo ao projeto atual ou absoluto

        Returns:
            Mensagem de status
        """
        # Resolve path
        if self._projeto_atual and not os.path.isabs(path):
            caminho = os.path.join(self._projeto_atual, path)
        else:
            caminho = path

        caminho = os.path.expanduser(caminho)

        if not os.path.exists(caminho):
            # Tenta buscar no diretório atual
            for root, dirs, files in os.walk(os.getcwd()):
                for f in files:
                    if f == os.path.basename(path):
                        caminho = os.path.join(root, f)
                        break

        if not os.path.exists(caminho):
            return f"Arquivo não encontrado: {path}"

        # Tenta abrir no VSCode, depois no editor padrão
        for editor in ["code", "code-insiders"]:
            try:
                subprocess.Popen([editor, caminho],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
                log.info(f"[DevMode] Arquivo aberto no VSCode: {caminho}")
                return f"Arquivo aberto: {os.path.basename(caminho)}"
            except FileNotFoundError:
                continue

        # Fallback: abre com programa padrão do SO
        try:
            if sys.platform == "win32":
                os.startfile(caminho)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", caminho])
            else:
                subprocess.Popen(["xdg-open", caminho])
            return f"Arquivo aberto: {os.path.basename(caminho)}"
        except Exception as e:
            return f"Erro ao abrir {path}: {e}"

    def set_project(self, path: str) -> str:
        """Define o projeto atual (pasta raiz)."""
        expandido = os.path.expanduser(path)
        if os.path.isdir(expandido):
            self._projeto_atual = expandido
            log.info(f"[DevMode] Projeto atual: {expandido}")
            return f"Projeto definido: {expandido}"
        return f"Pasta não encontrada: {path}"

    def list_project_files(self, extensao: str = None) -> list[str]:
        """Lista arquivos do projeto atual."""
        if not self._projeto_atual:
            return []
        arquivos = []
        for root, dirs, files in os.walk(self._projeto_atual):
            # Ignora pastas irrelevantes
            dirs[:] = [d for d in dirs if d not in {".git", "__pycache__",
                                                      "node_modules", ".venv", "venv"}]
            for f in files:
                if extensao is None or f.endswith(extensao):
                    rel = os.path.relpath(os.path.join(root, f), self._projeto_atual)
                    arquivos.append(rel)
        return arquivos

    def read_file(self, path: str) -> str:
        """Lê o conteúdo de um arquivo de projeto."""
        if self._projeto_atual and not os.path.isabs(path):
            caminho = os.path.join(self._projeto_atual, path)
        else:
            caminho = path
        try:
            with open(caminho, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"Erro ao ler {path}: {e}"

    @property
    def projeto(self) -> Optional[str]:
        return self._projeto_atual


# ── Instância global ───────────────────────────────────────────────────────────
DevMode = _DevMode()
