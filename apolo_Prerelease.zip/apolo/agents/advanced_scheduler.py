"""
agents/advanced_scheduler.py — Rotinas e lembretes avançados

Capacidades além do scheduler simples:
  - Lembretes recorrentes (toda segunda, todo dia, todo mês)
  - Rotinas complexas com múltiplas ações encadeadas
  - Persistência em JSON (sobrevive a reinicializações)
  - Integração com RoutineManager para executar rotinas existentes

Uso:
    from agents.advanced_scheduler import AdvancedScheduler
    sch = AdvancedScheduler()
    sch.set_callback(fn_alerta)

    # Lembrete recorrente simples
    sch.agendar_recorrente(
        nome="prazo_x",
        descricao="verificar prazo X",
        frequencia="semanal",
        dia_semana="segunda",
        horario="09:00"
    )

    # Rotina complexa: toda segunda, avisa sobre prazo E cria lembrete
    sch.agendar_rotina_complexa(
        nome="rotina_segunda",
        descricao="Rotina de segunda-feira",
        frequencia="semanal",
        dia_semana="segunda",
        horario="08:00",
        acoes=[
            {"tipo": "lembrete", "texto": "verificar prazo X"},
            {"tipo": "lembrete", "texto": "ligar para pessoa Y", "horario": "14:00"},
            {"tipo": "rotina",   "nome":  "bom dia"},
        ]
    )
"""

import os
import json
import threading
import time
from datetime import datetime, timedelta
from typing import Callable
import config
from utils.logger import log

# Arquivo de persistência
ADVANCED_SCH_FILE = os.path.join(config.DATA_DIR, "advanced_schedules.json")

# Mapeamento dia da semana PT-BR → weekday Python (0=segunda)
DIAS_SEMANA = {
    "segunda": 0, "segunda-feira": 0,
    "terca":   1, "terça": 1, "terça-feira": 1,
    "quarta":  2, "quarta-feira": 2,
    "quinta":  3, "quinta-feira": 3,
    "sexta":   4, "sexta-feira": 4,
    "sabado":  5, "sábado": 5,
    "domingo": 6,
}

# Frequências suportadas
FREQUENCIAS = {
    "diario", "diária", "diariamente",
    "semanal", "semanalmente",
    "mensal", "mensalmente",
}


def _parse_horario(horario_str: str) -> tuple[int, int]:
    """Converte string de horário em (hora, minuto)."""
    import re
    horario_str = horario_str.strip()
    # "09:00", "9h", "9h30", "14:30"
    m = re.search(r"(\d{1,2})[h:](\d{2})?", horario_str)
    if m:
        return int(m.group(1)), int(m.group(2)) if m.group(2) else 0
    m = re.search(r"(\d{1,2})", horario_str)
    if m:
        return int(m.group(1)), 0
    return 9, 0  # default 09:00


def _proximo_disparo(frequencia: str, dia_semana: str = None,
                     horario: str = "09:00") -> datetime:
    """Calcula o próximo datetime de disparo."""
    agora = datetime.now()
    hora, minuto = _parse_horario(horario)

    if frequencia in ("diario", "diária", "diariamente"):
        disparo = agora.replace(hour=hora, minute=minuto, second=0, microsecond=0)
        if disparo <= agora:
            disparo += timedelta(days=1)
        return disparo

    if frequencia in ("semanal", "semanalmente"):
        alvo_wd = DIAS_SEMANA.get((dia_semana or "").lower(), 0)
        hoje_wd  = agora.weekday()
        dias     = (alvo_wd - hoje_wd) % 7
        if dias == 0:
            # Mesmo dia — verifica se o horário já passou
            disparo_hoje = agora.replace(hour=hora, minute=minuto, second=0, microsecond=0)
            dias = 7 if disparo_hoje <= agora else 0
        disparo = (agora + timedelta(days=dias)).replace(
            hour=hora, minute=minuto, second=0, microsecond=0
        )
        return disparo

    if frequencia in ("mensal", "mensalmente"):
        try:
            disparo = agora.replace(day=1, hour=hora, minute=minuto, second=0, microsecond=0)
            if disparo <= agora:
                mes  = disparo.month % 12 + 1
                ano  = disparo.year + (1 if disparo.month == 12 else 0)
                disparo = disparo.replace(month=mes, year=ano)
        except ValueError:
            disparo = agora + timedelta(days=30)
        return disparo

    # Fallback: amanhã
    return (agora + timedelta(days=1)).replace(
        hour=hora, minute=minuto, second=0, microsecond=0
    )


class AdvancedScheduler:
    """Agendador avançado com persistência e recorrência."""

    def __init__(self):
        os.makedirs(config.DATA_DIR, exist_ok=True)
        self._agendamentos: list[dict] = []
        self._callback: Callable | None = None
        self._simple_scheduler = None   # referência ao Scheduler base (injetado)
        self._rodando = True
        self._carregar()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="advanced_scheduler"
        )
        self._thread.start()
        log.info(f"[AdvScheduler] {len(self._agendamentos)} agendamentos carregados")

    # ── Persistência ──────────────────────────────────────────────────────────

    def _carregar(self):
        if os.path.exists(ADVANCED_SCH_FILE):
            try:
                with open(ADVANCED_SCH_FILE, "r", encoding="utf-8") as f:
                    self._agendamentos = json.load(f)
                # Recalcula próximo disparo para agendamentos vencidos
                agora_iso = datetime.now().isoformat()
                for ag in self._agendamentos:
                    if ag.get("proximo_disparo", "") < agora_iso:
                        ag["proximo_disparo"] = _proximo_disparo(
                            ag["frequencia"],
                            ag.get("dia_semana"),
                            ag.get("horario", "09:00")
                        ).isoformat()
                self._salvar()
            except Exception as e:
                log.warning(f"[AdvScheduler] Erro ao carregar: {e}")
                self._agendamentos = []

    def _salvar(self):
        try:
            import tempfile
            dir_dest = config.DATA_DIR
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8",
                dir=dir_dest, suffix=".tmp", delete=False
            ) as f:
                json.dump(self._agendamentos, f, ensure_ascii=False,
                          indent=2, default=str)
                tmp = f.name
            os.replace(tmp, ADVANCED_SCH_FILE)
        except Exception as e:
            log.warning(f"[AdvScheduler] Erro ao salvar: {e}")

    # ── API pública ───────────────────────────────────────────────────────────

    def set_callback(self, fn: Callable):
        """Define a função chamada quando um agendamento disparar."""
        self._callback = fn

    def set_simple_scheduler(self, scheduler):
        """Injeta o Scheduler base para criar lembretes pontuais."""
        self._simple_scheduler = scheduler

    def agendar_recorrente(self, nome: str, descricao: str,
                           frequencia: str, horario: str = "09:00",
                           dia_semana: str = None) -> str:
        """
        Cria um lembrete recorrente simples.

        Args:
            nome:       identificador único
            descricao:  texto do lembrete
            frequencia: "diario" | "semanal" | "mensal"
            horario:    "09:00", "9h30", etc.
            dia_semana: "segunda", "terça", etc. (só para frequencia=semanal)

        Returns:
            Mensagem de confirmação
        """
        # Remove agendamento anterior com mesmo nome
        self._agendamentos = [a for a in self._agendamentos if a["nome"] != nome]

        proximo = _proximo_disparo(frequencia, dia_semana, horario)
        agendamento = {
            "nome":             nome,
            "tipo":             "lembrete_simples",
            "descricao":        descricao,
            "frequencia":       frequencia,
            "dia_semana":       dia_semana or "",
            "horario":          horario,
            "proximo_disparo":  proximo.isoformat(),
            "acoes":            [],
            "ativo":            True,
        }
        self._agendamentos.append(agendamento)
        self._salvar()

        # Formata confirmação
        freq_pt = {
            "diario": "todo dia", "diária": "todo dia",
            "semanal": f"toda {dia_semana or 'semana'}",
            "mensal": "todo mês",
        }.get(frequencia, frequencia)

        msg = (f"Lembrete recorrente criado: '{descricao}' — "
               f"{freq_pt} às {horario}. "
               f"Próximo aviso: {proximo.strftime('%d/%m às %H:%M')}.")
        log.info(f"[AdvScheduler] {msg}")
        return msg

    def agendar_rotina_complexa(self, nome: str, descricao: str,
                                frequencia: str, horario: str = "09:00",
                                dia_semana: str = None,
                                acoes: list[dict] = None) -> str:
        """
        Cria uma rotina complexa com múltiplas ações.

        Tipos de ação:
            {"tipo": "lembrete",  "texto": "...", "horario": "14:00"}
            {"tipo": "rotina",    "nome":  "bom dia"}
            {"tipo": "mensagem",  "texto": "..."}
            {"tipo": "abrir_app", "app":   "vscode"}

        Args:
            acoes: lista de ações a executar quando a rotina disparar

        Returns:
            Mensagem de confirmação
        """
        self._agendamentos = [a for a in self._agendamentos if a["nome"] != nome]

        proximo = _proximo_disparo(frequencia, dia_semana, horario)
        agendamento = {
            "nome":             nome,
            "tipo":             "rotina_complexa",
            "descricao":        descricao,
            "frequencia":       frequencia,
            "dia_semana":       dia_semana or "",
            "horario":          horario,
            "proximo_disparo":  proximo.isoformat(),
            "acoes":            acoes or [],
            "ativo":            True,
        }
        self._agendamentos.append(agendamento)
        self._salvar()

        n_acoes = len(acoes or [])
        msg = (f"Rotina complexa '{nome}' criada com {n_acoes} ação(ões). "
               f"Próxima execução: {proximo.strftime('%d/%m às %H:%M')}.")
        log.info(f"[AdvScheduler] {msg}")
        return msg

    def cancelar(self, nome: str) -> str:
        """Cancela um agendamento pelo nome."""
        antes = len(self._agendamentos)
        self._agendamentos = [a for a in self._agendamentos if a["nome"] != nome]
        if len(self._agendamentos) < antes:
            self._salvar()
            return f"Agendamento '{nome}' cancelado."
        return f"Agendamento '{nome}' não encontrado."

    def listar(self) -> list[dict]:
        """Lista todos os agendamentos ativos."""
        return [
            {
                "nome":        a["nome"],
                "descricao":   a["descricao"],
                "frequencia":  a["frequencia"],
                "dia_semana":  a.get("dia_semana", ""),
                "horario":     a.get("horario", ""),
                "proximo":     a.get("proximo_disparo", "")[:16].replace("T", " "),
                "n_acoes":     len(a.get("acoes", [])),
            }
            for a in self._agendamentos if a.get("ativo")
        ]

    def listar_formatado(self) -> str:
        """Retorna lista formatada para exibição."""
        items = self.listar()
        if not items:
            return "Nenhum agendamento ativo."
        linhas = [f"Agendamentos ativos ({len(items)}):"]
        for it in items:
            dia = f" ({it['dia_semana']})" if it["dia_semana"] else ""
            linhas.append(
                f"  • {it['nome']}: {it['descricao']} — "
                f"{it['frequencia']}{dia} às {it['horario']} "
                f"| próximo: {it['proximo']}"
            )
        return "\n".join(linhas)

    def parar(self):
        self._rodando = False

    # ── Loop de verificação ───────────────────────────────────────────────────

    def _loop(self):
        """Verifica agendamentos a cada 30 segundos."""
        while self._rodando:
            self._checar()
            time.sleep(30)

    def _checar(self):
        """Dispara agendamentos cujo próximo_disparo passou."""
        agora     = datetime.now()
        modificado = False

        for ag in self._agendamentos:
            if not ag.get("ativo"):
                continue

            try:
                proximo = datetime.fromisoformat(ag["proximo_disparo"])
            except Exception:
                continue

            if agora >= proximo:
                log.info(f"[AdvScheduler] Disparando: {ag['nome']}")
                self._executar(ag)
                # Agenda próxima ocorrência
                ag["proximo_disparo"] = _proximo_disparo(
                    ag["frequencia"],
                    ag.get("dia_semana"),
                    ag.get("horario", "09:00")
                ).isoformat()
                modificado = True

        if modificado:
            self._salvar()

    def _executar(self, ag: dict):
        """Executa um agendamento disparado."""
        tipo = ag.get("tipo", "lembrete_simples")

        if tipo == "lembrete_simples":
            msg = f"🔔 LEMBRETE RECORRENTE: {ag['descricao']}"
            if self._callback:
                threading.Thread(
                    target=self._callback, args=(msg,), daemon=True
                ).start()
            else:
                print(f"\n{msg}\n")

        elif tipo == "rotina_complexa":
            # Executa cada ação da rotina
            msg_inicio = f"🔄 Rotina '{ag['nome']}' iniciada: {ag['descricao']}"
            if self._callback:
                threading.Thread(
                    target=self._callback, args=(msg_inicio,), daemon=True
                ).start()

            for acao in ag.get("acoes", []):
                try:
                    self._executar_acao(acao)
                    time.sleep(0.5)  # pausa entre ações
                except Exception as e:
                    log.error(f"[AdvScheduler] Erro na ação {acao}: {e}")

    def _executar_acao(self, acao: dict):
        """Executa uma ação individual da rotina complexa."""
        tipo = acao.get("tipo", "mensagem")

        if tipo == "mensagem":
            msg = acao.get("texto", "")
            if msg and self._callback:
                self._callback(msg)

        elif tipo == "lembrete":
            # Cria lembrete pontual via scheduler simples
            texto   = acao.get("texto", "lembrete")
            horario = acao.get("horario")
            if self._simple_scheduler:
                self._simple_scheduler.adicionar_lembrete(texto, horario)
            elif self._callback:
                self._callback(f"🔔 {texto}")

        elif tipo == "rotina":
            # Executa rotina existente via RoutineManager
            nome_rotina = acao.get("nome", "")
            if nome_rotina:
                try:
                    from agents.routines import RoutineManager
                    resultados = RoutineManager.run_routine(nome_rotina)
                    for r in resultados:
                        if r and self._callback:
                            self._callback(r)
                except Exception as e:
                    log.error(f"[AdvScheduler] Rotina '{nome_rotina}' falhou: {e}")

        elif tipo == "abrir_app":
            app = acao.get("app", "")
            if app:
                try:
                    from commands.system_commands import SystemCommands
                    SystemCommands().abrir_app(app)
                except Exception as e:
                    log.error(f"[AdvScheduler] abrir_app '{app}' falhou: {e}")
