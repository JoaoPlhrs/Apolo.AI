#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "  ══════════════════════════════"
echo "       APOLO v2.5"
echo "    Local AI Assistant"
echo "  ══════════════════════════════"
echo ""

# Verifica Python
if ! command -v python3 &> /dev/null; then
    echo "[ERRO] Python3 não encontrado."
    exit 1
fi

# Verifica Ollama
if ! command -v ollama &> /dev/null; then
    echo "[AVISO] Ollama não encontrado. Iniciando em modo demo..."
    python3 main_web.py --demo
    exit 0
fi

# Inicia Ollama se não estiver rodando
if ! pgrep -x "ollama" > /dev/null; then
    echo "[APOLO] Iniciando Ollama..."
    ollama serve &>/dev/null &
    sleep 2
fi

echo "[APOLO] Iniciando servidor web..."
python3 main_web.py
