// APOLO Service Worker — cache versionado (atualiza automaticamente)
const VERSION = 'apolo-v3';
const ASSETS  = [
  '/apolo_4.html',
  '/manifest.json',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/icons/favicon.png'
];

// Instala e cacheia assets
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(VERSION).then(c => c.addAll(ASSETS))
  );
  // Força ativação imediata sem esperar abas fecharem
  self.skipWaiting();
});

// Remove caches antigas de versões anteriores
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== VERSION).map(k => {
        console.log('[SW] Deletando cache antigo:', k);
        return caches.delete(k);
      }))
    )
  );
  self.clients.claim();
});

// Network-first para HTML (garante sempre versão nova)
// Cache-first para assets estáticos (ícones, etc)
self.addEventListener('fetch', e => {
  if (e.request.url.startsWith('ws://') || e.request.url.startsWith('wss://')) return;
  if (e.request.url.includes('fonts.googleapis') || e.request.url.includes('cdn.jsdelivr')) return;

  const isHTML = e.request.destination === 'document' || e.request.url.endsWith('.html');

  if (isHTML) {
    // Network-first para HTML: tenta buscar novo, fallback para cache
    e.respondWith(
      fetch(e.request)
        .then(res => {
          const clone = res.clone();
          caches.open(VERSION).then(c => c.put(e.request, clone));
          return res;
        })
        .catch(() => caches.match(e.request))
    );
  } else {
    // Cache-first para outros assets
    e.respondWith(
      caches.match(e.request).then(cached => cached || fetch(e.request))
    );
  }
});
