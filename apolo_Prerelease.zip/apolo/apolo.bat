@echo off
title APOLO — IA Local
cd /d "%~dp0"

echo.
echo  ██████████████████████████████
echo  █                            █
echo  █        APOLO  v2.5         █
echo  █      Local AI Assistant    █
echo  █                            █
echo  ██████████████████████████████
echo.

:: Verifica Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado. Instale em python.org
    pause
    exit /b 1
)

:: Verifica Ollama
ollama --version >nul 2>&1
if errorlevel 1 (
    echo [AVISO] Ollama nao encontrado. Baixe em ollama.com
    echo         Iniciando em modo demo...
    python main_web.py --demo
    goto :fim
)

:: Inicia Ollama com KEEP_ALIVE de 20 minutos
tasklist /fi "imagename eq ollama.exe" 2>nul | find /i "ollama.exe" >nul
if errorlevel 1 (
    echo [APOLO] Iniciando Ollama (keep_alive=20m)...
    set OLLAMA_KEEP_ALIVE=20m
    set OLLAMA_FLASH_ATTENTION=1
    start /min cmd /c "set OLLAMA_KEEP_ALIVE=20m && set OLLAMA_FLASH_ATTENTION=1 && ollama serve"
    echo [APOLO] Aguardando Ollama iniciar...
    timeout /t 4 /nobreak >nul
) else (
    echo [APOLO] Ollama ja esta rodando.
)

echo [APOLO] Iniciando servidor web + pre-aquecendo modelo...
python main_web.py

:fim
pause
