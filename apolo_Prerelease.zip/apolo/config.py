"""
APOLO — Configurações Globais
Edite este arquivo para personalizar seu assistente.
"""

import os

# ─── DIRETÓRIOS ────────────────────────────────────────────────────────────────
BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
DATA_DIR     = os.path.join(BASE_DIR, "data")
CHROMA_DIR   = os.path.join(DATA_DIR, "chroma")
HISTORY_DIR  = os.path.join(DATA_DIR, "history")
HISTORY_FILE = os.path.join(HISTORY_DIR, "conversations.json")
PROFILE_FILE = os.path.join(DATA_DIR, "user_profile.json")

# ─── MODELO LLM (Ollama) ───────────────────────────────────────────────────────
# Escolha conforme seu hardware:
#   "gemma4:e2b"  → 2B params, roda em 4GB RAM  (mais rápido, menos capaz)
#   "gemma4:e4b"  → 4B params, roda em 6GB RAM  (recomendado para maioria)
#   "gemma4:26b"  → MoE 26B/4B ativos, 16GB RAM (melhor qualidade)
#   "gemma4:31b"  → Dense 31B, 32GB RAM          (máxima qualidade)
OLLAMA_MODEL   = "gemma4:e4b"
OLLAMA_BASE_URL = "http://localhost:11434"

# ─── VOZ ───────────────────────────────────────────────────────────────────────
# STT: "whisper" (melhor qualidade) ou "vosk" (mais leve, offline puro)
STT_ENGINE     = "whisper"
WHISPER_MODEL  = "base"       # tiny | base | small | medium
STT_LANGUAGE   = "pt"

# TTS: "piper" (melhor qualidade) | "coqui" (voz neural) | "pyttsx3" (sistema, mais rápido)
# Piper é detectado e baixado automaticamente na primeira execução
TTS_ENGINE     = "piper"      # "piper" usa voz Jarvis (pip install piper-tts)
                                    # "pyttsx3" usa voz do sistema (fallback)
TTS_RATE       = 175          # velocidade da fala (palavras por minuto) — só pyttsx3
TTS_JARVIS_VOICE = True            # True = baixa e usa voz Jarvis (en_GB); False = voz PT-BR
TTS_VOLUME     = 1.0

# ─── WAKE WORD ─────────────────────────────────────────────────────────────────
WAKE_WORD_ENABLED = False     # True requer pvporcupine instalado + access key
WAKE_WORD         = "apolo"
PORCUPINE_KEY     = ""        # Obtenha grátis em: picovoice.ai/console

# ─── ÁUDIO ─────────────────────────────────────────────────────────────────────
AUDIO_RATE        = 16000
AUDIO_CHANNELS    = 1
AUDIO_CHUNK       = 1024
LISTEN_SECONDS    = 6         # tempo de escuta após ativação

# ─── MEMÓRIA ───────────────────────────────────────────────────────────────────
EMBEDDING_MODEL   = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
MEMORY_TOP_K      = 4         # quantas memórias buscar por vez
MAX_HISTORY_TURNS = 50        # turnos de conversa mantidos no contexto (~100 msgs)

# ─── SISTEMA ───────────────────────────────────────────────────────────────────
APOLO_NAME     = "APOLO"
USER_NAME      = "usuário"    # será atualizado ao aprender o nome do usuário
LOG_LEVEL      = "INFO"       # DEBUG | INFO | WARNING | ERROR
THINK_MODE     = False        # True = Gemma 4 usa raciocínio interno (mais lento)

# ─── BANCO VETORIAL ────────────────────────────────────────────────────────────
# Backend preferido: "auto" detecta automaticamente (FAISS > ChromaDB > InMemory)
# "faiss"   → pip install faiss-cpu  (mais rápido, offline puro)
# "chroma"  → pip install chromadb   (mais features, persistente)
VECTOR_BACKEND = "auto"
