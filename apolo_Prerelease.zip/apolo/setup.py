#!/usr/bin/env python3
"""
setup.py — Instalador robusto do APOLO Beta 1

Correcoes desta versao:
  - Diagnostica e corrige erros reais do pip (mostra stderr)
  - PyAudio no Windows: usa pipwin ou wheel pre-compilado
  - PyAudio no Linux: instala portaudio19-dev antes
  - PyAudio no Mac: instala portaudio via brew antes
  - requirements.txt: instala pacote por pacote com retry
  - Todos os adicionais sao dependencias instaladas automaticamente
  - Relatorio final claro de o que funcionou e o que nao funcionou

Uso:
    python setup.py
"""

import subprocess
import sys
import os
import json
import platform
import shutil
import urllib.request
import tempfile

# ── Cores ANSI ────────────────────────────────────────────────────────────────
V = "\033[92m"; A = "\033[93m"; R = "\033[91m"
C = "\033[96m"; B = "\033[1m";  X = "\033[0m"

def ok(m):  print(f"  {V}✓{X} {m}")
def av(m):  print(f"  {A}⚠{X} {m}")
def er(m):  print(f"  {R}✗{X} {m}")
def inf(m): print(f"    {m}")
def tit(m): print(f"\n{B}{C}{'─'*56}\n  {m}\n{'─'*56}{X}")

WIN   = platform.system() == "Windows"
MAC   = platform.system() == "Darwin"
LINUX = platform.system() == "Linux"

# Registro de resultados para relatorio final
_resultados: dict[str, bool] = {}


# ══════════════════════════════════════════════════════════════════════════════
# Funcoes de instalacao
# ══════════════════════════════════════════════════════════════════════════════

def _executar(cmd: list[str], timeout: int = 300) -> tuple[bool, str, str]:
    """
    Executa comando e retorna (sucesso, stdout, stderr).
    Nunca usa shell=True — evita problemas com espacos no PATH do Windows.
    """
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return r.returncode == 0, r.stdout.strip(), r.stderr.strip()
    except subprocess.TimeoutExpired:
        return False, "", "Timeout"
    except FileNotFoundError as e:
        return False, "", str(e)
    except Exception as e:
        return False, "", str(e)


def _pip_instalar(pacote: str, extras: str = "") -> tuple[bool, str]:
    """
    Instala um pacote via pip com diagnostico de erro.
    Retorna (sucesso, mensagem_de_erro).
    """
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"]
    if extras:
        cmd.append(extras)
    cmd.append(pacote)

    ok_ret, stdout, stderr = _executar(cmd, timeout=300)

    if ok_ret:
        return True, ""

    # Extrai mensagem util do stderr
    erro = ""
    for linha in stderr.splitlines():
        linha = linha.strip()
        if any(x in linha.lower() for x in
               ["error", "could not", "no matching", "failed", "invalid"]):
            erro = linha[:120]
            break
    if not erro and stderr:
        erro = stderr.splitlines()[-1][:120] if stderr.splitlines() else stderr[:120]

    return False, erro


def _verificar_instalado(pacote: str) -> bool:
    """Verifica se um pacote ja esta instalado sem importar."""
    ok_ret, _, _ = _executar(
        [sys.executable, "-m", "pip", "show", pacote]
    )
    return ok_ret


def _instalar_com_feedback(pkg: str, nome: str, obrigatorio: bool = True,
                            pre_fn=None) -> bool:
    """
    Instala um pacote mostrando feedback claro.
    pre_fn: funcao opcional executada antes da instalacao (ex: instalar portaudio).
    """
    print(f"  Instalando {nome}...", end=" ", flush=True)

    # Ja instalado?
    if _verificar_instalado(pkg.split(">=")[0].split("==")[0]):
        print(f"{V}ja instalado{X}")
        _resultados[pkg] = True
        return True

    # Pre-requisito do sistema
    if pre_fn:
        pre_fn()

    sucesso, erro = _pip_instalar(pkg)

    if sucesso:
        print(f"{V}OK{X}")
        _resultados[pkg] = True
        return True
    else:
        marcador = R if obrigatorio else A
        print(f"{marcador}FALHOU{X}")
        if erro:
            inf(f"Erro: {erro}")
        _resultados[pkg] = False
        return False


# ══════════════════════════════════════════════════════════════════════════════
# Instalacao de pre-requisitos do sistema
# ══════════════════════════════════════════════════════════════════════════════

def _pre_pyaudio():
    """Instala pre-requisitos do sistema para PyAudio."""
    if WIN:
        _pre_pyaudio_windows()
    elif MAC:
        _pre_pyaudio_mac()
    elif LINUX:
        _pre_pyaudio_linux()


def _pre_pyaudio_windows():
    """
    No Windows, PyAudio precisa de binarios pre-compilados.
    Estrategia:
      1. Tenta pipwin (instala wheels pre-compilados)
      2. Tenta wheel do Gohlke (unofficial)
      3. Tenta pip direto (funciona no Python 3.12+ com wheels oficiais)
    """
    # Verifica se ja esta instalado
    ok_ret, _, _ = _executar([sys.executable, "-c", "import pyaudio"])
    if ok_ret:
        return

    # Estrategia 1: pip direto (Python 3.12+ tem wheel oficial)
    v = sys.version_info
    if v.minor >= 12:
        return  # pip install pyaudio vai funcionar direto

    # Estrategia 2: pipwin
    inf("Windows: instalando pipwin para obter PyAudio pre-compilado...")
    ok_pw, _ = _pip_instalar("pipwin")
    if ok_pw:
        sucesso, _, stderr = _executar(
            [sys.executable, "-m", "pipwin", "install", "pyaudio"]
        )
        if sucesso:
            inf("PyAudio instalado via pipwin")
            return
        inf(f"pipwin falhou: {stderr[:80]}")

    # Estrategia 3: wheel direto do repositorio unofficial
    inf("Tentando wheel pre-compilado...")
    py_ver = f"cp{v.major}{v.minor}"
    arch   = "win_amd64" if platform.machine().endswith("64") else "win32"
    url    = (f"https://download.lfd.uci.edu/pythonlibs/archived/"
              f"PyAudio-0.2.14-{py_ver}-{py_ver}-{arch}.whl")
    try:
        with tempfile.NamedTemporaryFile(suffix=".whl", delete=False) as f:
            urllib.request.urlretrieve(url, f.name)
            whl_path = f.name
        _executar([sys.executable, "-m", "pip", "install", whl_path])
        os.unlink(whl_path)
    except Exception:
        pass  # pip direto vai tentar depois


def _pre_pyaudio_linux():
    """No Linux, portaudio19-dev e necessario antes de compilar pyaudio."""
    # Verifica se portaudio esta instalado
    ok_ret, _, _ = _executar(["dpkg", "-l", "portaudio19-dev"])
    if ok_ret:
        return

    inf("Linux: instalando portaudio19-dev (necessario para microfone)...")
    ok_apt, _, stderr = _executar(
        ["sudo", "apt-get", "install", "-y",
         "portaudio19-dev", "python3-pyaudio"],
        timeout=120
    )
    if not ok_apt:
        # Tenta sem sudo (pode estar em container com root)
        _executar(["apt-get", "install", "-y", "portaudio19-dev"], timeout=120)


def _pre_pyaudio_mac():
    """No Mac, portaudio deve ser instalado via Homebrew."""
    # Verifica se portaudio ja esta instalado
    ok_ret, _, _ = _executar(["brew", "list", "portaudio"])
    if ok_ret:
        return
    if shutil.which("brew"):
        inf("Mac: instalando portaudio via Homebrew...")
        _executar(["brew", "install", "portaudio"], timeout=180)
    else:
        av("Homebrew nao encontrado. Instale portaudio manualmente:")
        inf("brew install portaudio")


# ══════════════════════════════════════════════════════════════════════════════
# Passos do instalador
# ══════════════════════════════════════════════════════════════════════════════

def passo_python():
    tit("1/7 — Python")
    v = sys.version_info
    if v.major == 3 and v.minor >= 10:
        ok(f"Python {v.major}.{v.minor}.{v.micro}")
        ok(f"Executavel: {sys.executable}")
    else:
        er(f"Python {v.major}.{v.minor} — requer 3.10+")
        sys.exit(1)

    # Atualiza pip antes de tudo
    print(f"  Atualizando pip...", end=" ", flush=True)
    ok_ret, _, _ = _executar([sys.executable, "-m", "pip", "install",
                               "--upgrade", "pip", "--quiet"])
    print(f"{V}OK{X}" if ok_ret else f"{A}ignorado{X}")


def passo_ollama() -> str:
    tit("2/7 — Ollama (motor de IA)")

    if shutil.which("ollama"):
        ok("Ollama encontrado no PATH")
        ok_api, _, _ = _executar(
            ["curl", "-s", "--max-time", "2",
             "http://localhost:11434/api/tags"]
        )
        if ok_api:
            ok("Ollama respondendo na porta 11434")
        else:
            av("Ollama instalado mas nao esta rodando:")
            inf(f"{B}ollama serve{X}  (execute em outro terminal)")
    else:
        av("Ollama nao encontrado:")
        if WIN:   inf(f"{C}https://ollama.ai/download/windows{X}")
        elif MAC: inf(f"{C}https://ollama.ai/download{X}")
        else:     inf(f"{C}curl -fsSL https://ollama.ai/install.sh | sh{X}")

    print(f"\n  {B}Modelos Gemma 4 disponiveis:{X}")
    modelos = [
        ("1", "gemma4:e2b",  "~3 GB",  "4 GB RAM",  "Basico, mais rapido"),
        ("2", "gemma4:e4b",  "~5 GB",  "6 GB RAM",  f"{V}Recomendado{X}"),
        ("3", "gemma4:26b",  "~16 GB", "20 GB RAM", "Alta qualidade (MoE)"),
        ("4", "gemma4:31b",  "~20 GB", "32 GB RAM", "Maxima qualidade"),
    ]
    for n, m, sz, ram, desc in modelos:
        print(f"  [{n}] {m:<16} {sz:<8} {ram:<12} {desc}")

    escolha = input(f"\n{C}  Escolha (1-4) [Enter = 2]: {X}").strip() or "2"
    mapa    = {"1":"gemma4:e2b","2":"gemma4:e4b",
               "3":"gemma4:26b","4":"gemma4:31b"}
    modelo  = mapa.get(escolha, "gemma4:e4b")

    # Atualiza config.py
    config_path = os.path.join(os.path.dirname(__file__), "config.py")
    try:
        txt = open(config_path, encoding="utf-8").read()
        # Tenta substituir qualquer valor atual
        import re
        txt = re.sub(
            r'OLLAMA_MODEL\s*=\s*"[^"]*"',
            f'OLLAMA_MODEL   = "{modelo}"',
            txt
        )
        open(config_path, "w", encoding="utf-8").write(txt)
        ok(f"config.py: OLLAMA_MODEL = {modelo}")
    except Exception as e:
        av(f"Nao foi possivel atualizar config.py: {e}")
        av(f"Edite manualmente: OLLAMA_MODEL = \"{modelo}\"")

    inf(f"Para baixar o modelo depois: {B}ollama pull {modelo}{X}")
    return modelo


def passo_deps_core():
    tit("3/7 — Dependencias core (sem audio)")

    # Pacotes que funcionam em qualquer SO sem pre-requisitos
    CORE = [
        ("ollama",                "Ollama SDK Python"),
        ("rich",                  "Rich (terminal colorido)"),
        ("colorama",              "Colorama (cores Windows)"),
        ("requests",              "Requests (HTTP)"),
        ("python-dateutil",       "python-dateutil"),
        ("numpy",                 "NumPy"),
        ("apscheduler",           "APScheduler (lembretes)"),
        ("pyttsx3",               "pyttsx3 (TTS do sistema)"),
        ("SpeechRecognition",     "SpeechRecognition"),
        ("faster-whisper",        "Faster-Whisper (STT)"),
        ("sentence-transformers", "Sentence-Transformers"),
        ("faiss-cpu",             "FAISS (banco vetorial)"),
    ]

    falhas = []
    for pkg, nome in CORE:
        sucesso = _instalar_com_feedback(pkg, nome, obrigatorio=True)
        if not sucesso:
            falhas.append(pkg)

    if falhas:
        av(f"Falhas ({len(falhas)}): {', '.join(falhas)}")
        av("Tente manualmente: pip install " + " ".join(falhas))
    else:
        ok("Todas as dependencias core instaladas!")


def passo_audio():
    tit("4/7 — Audio e microfone (PyAudio)")

    if WIN:
        inf("Windows detectado — usando estrategia especial para PyAudio")
        _pre_pyaudio_windows()

        # Tenta pip direto primeiro
        print(f"  Instalando PyAudio...", end=" ", flush=True)
        if _verificar_instalado("pyaudio"):
            print(f"{V}ja instalado{X}")
            _resultados["pyaudio"] = True
            return

        sucesso, erro = _pip_instalar("pyaudio")
        if sucesso:
            print(f"{V}OK{X}")
            _resultados["pyaudio"] = True
            ok("Microfone disponivel!")
            return

        # Fallback: pipwin
        print(f"{A}pip direto falhou, tentando pipwin...{X}")
        ok_pw, _ = _pip_instalar("pipwin")
        if ok_pw:
            ok_py, _, _ = _executar(
                [sys.executable, "-m", "pipwin", "install", "pyaudio"]
            )
            if ok_py:
                ok("PyAudio instalado via pipwin!")
                _resultados["pyaudio"] = True
                return

        # Fallback final: audioop-lts (substituto sem microfone real)
        print(f"  {A}PyAudio nao disponivel.{X}")
        inf("Instalando audioop-lts como substituto parcial...")
        _pip_instalar("audioop-lts")
        av("Microfone pode nao funcionar — instale manualmente:")
        inf(f"  pip install pyaudio")
        inf(f"  Ou baixe wheel em: https://pypi.org/project/pyaudio/#files")
        _resultados["pyaudio"] = False

    elif LINUX:
        _pre_pyaudio_linux()
        _instalar_com_feedback("pyaudio", "PyAudio (microfone)", True)

    elif MAC:
        _pre_pyaudio_mac()
        _instalar_com_feedback("pyaudio", "PyAudio (microfone)", True)

    else:
        _instalar_com_feedback("pyaudio", "PyAudio (microfone)", True)

    # Testa se o audio funciona de verdade
    ok_audio, _, _ = _executar([sys.executable, "-c", "import pyaudio; p=pyaudio.PyAudio(); p.terminate()"])
    if ok_audio:
        ok("Teste de audio: microfone acessivel!")
    else:
        av("PyAudio instalado mas audio pode ter problemas de driver")


def passo_adicionais():
    tit("5/7 — Adicionais (wake word e TTS avancado)")

    # Todos os adicionais agora sao instalados automaticamente
    ADICIONAIS = [
        ("openwakeword",  "OpenWakeWord (wake word sem conta)"),
        ("piper-tts",     "Piper TTS (voz neural PT-BR)"),
        ("chromadb",      "ChromaDB (banco vetorial alternativo)"),
    ]

    print(f"  Instalando adicionais automaticamente...\n")
    falhas = []
    for pkg, nome in ADICIONAIS:
        sucesso = _instalar_com_feedback(pkg, nome, obrigatorio=False)
        if not sucesso:
            falhas.append((pkg, nome))

    if falhas:
        print()
        av("Adicionais que falharam (opcionais, APOLO funciona sem eles):")
        for pkg, nome in falhas:
            inf(f"pip install {pkg}    ({nome})")
    else:
        ok("Todos os adicionais instalados!")


def passo_personalizacao():
    tit("6/7 — Personalizacao")

    nome   = input(f"{C}  Seu nome (Enter para pular): {X}").strip()
    cidade = input(f"{C}  Sua cidade para clima (Enter para pular): {X}").strip()

    os.makedirs("data", exist_ok=True)
    perfil = {
        "nome":         nome,
        "cidade":       cidade,
        "preferencias": {"estilo": "direto", "idioma": "pt-BR"},
        "apps_favoritos": [],
        "fatos": {},
    }
    try:
        with open(os.path.join("data", "user_profile.json"),
                  "w", encoding="utf-8") as f:
            json.dump(perfil, f, ensure_ascii=False, indent=2)
        if nome:   ok(f"Nome salvo: {nome}")
        if cidade: ok(f"Cidade salva: {cidade}")
    except Exception as e:
        av(f"Nao foi possivel salvar perfil: {e}")


def passo_tkinter():
    tit("7/7 — Interface grafica (tkinter)")
    try:
        import tkinter
        ok("tkinter disponivel — interface grafica OK")
    except ImportError:
        av("tkinter nao encontrado:")
        if LINUX: inf(f"sudo apt install python3-tk")
        elif MAC: inf(f"brew install python-tk")
        else:     inf(f"Reinstale o Python marcando 'tcl/tk and IDLE'")


def relatorio_final(modelo: str):
    """Exibe relatorio completo do que funcionou."""
    ok_pkgs  = [k for k, v in _resultados.items() if v]
    nok_pkgs = [k for k, v in _resultados.items() if not v]

    print(f"\n{'═'*56}")
    print(f"  {V}{B}APOLO Beta 1 — Instalacao Concluida{X}")
    print(f"{'═'*56}")

    print(f"\n  {V}Instalados ({len(ok_pkgs)}):{X}")
    for p in ok_pkgs:
        print(f"    ✓ {p}")

    if nok_pkgs:
        print(f"\n  {A}Nao instalados ({len(nok_pkgs)}):{X}")
        for p in nok_pkgs:
            print(f"    ⚠ {p}  →  pip install {p}")
        print()
        av("O APOLO funciona mesmo sem estes pacotes (funcionalidade reduzida)")

    print(f"\n{'─'*56}")
    print(f"  {B}Como usar:{X}")
    print(f"\n  1. Inicie o Ollama (terminal separado, deixe rodando):")
    print(f"     {B}ollama serve{X}")
    print(f"\n  2. Baixe o modelo (so uma vez, pode demorar):")
    print(f"     {B}ollama pull {modelo}{X}")
    print(f"\n  3. Inicie o APOLO:")
    print(f"     {B}python main_gui.py{X}         interface grafica")
    print(f"     {B}python main_gui.py --demo{X}  so o visual (sem Ollama)")
    print(f"     {B}python main.py{X}             modo terminal")
    print(f"{'═'*56}\n")


# ══════════════════════════════════════════════════════════════════════════════
# Entry point
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print(f"\n{B}{C}  APOLO — Instalador Beta 1{X}")
    print(f"  {platform.system()} {platform.machine()} | Python {sys.version.split()[0]}\n")

    passo_python()
    modelo = passo_ollama()
    passo_deps_core()
    passo_audio()
    passo_adicionais()
    passo_personalizacao()
    passo_tkinter()
    relatorio_final(modelo)
