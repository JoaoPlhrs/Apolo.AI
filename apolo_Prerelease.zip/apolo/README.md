# 🤖 APOLO — Assistente Inteligente Local

**A**lgoritmo de **P**rocessamento **O**perado por **L**ógica **O**peracional

Assistente pessoal offline-first, modular, com voz, memória e agentes. Powered by **Gemma 4** via Ollama.

---

## ⚡ Início Rápido

```bash
# 1. Clone / baixe o projeto
cd apolo/

# 2. Instale o Ollama
curl -fsSL https://ollama.ai/install.sh | sh   # Linux/Mac
# Windows: baixe em https://ollama.ai/download

# 3. Configure tudo automaticamente
python setup.py

# 4. Em um terminal separado, inicie o Ollama:
ollama serve

# 5. Baixe o modelo:
ollama pull gemma4:e4b

# 6. Inicie o APOLO:
python main.py           # modo texto
python main.py --voz     # modo voz (fala e ouve)
```

---

## 🎯 O que o APOLO pode fazer

| Comando de exemplo             | Ação                          |
|-------------------------------|-------------------------------|
| "Abre o Chrome"               | Abre o navegador              |
| "Pesquisa no Google Python"   | Abre busca no browser         |
| "Me lembra de estudar às 18h" | Cria lembrete com alerta      |
| "Como está o clima em SP?"    | Consulta clima (Open-Meteo)   |
| "Que horas são?"              | Responde data e hora          |
| "Procura arquivo relatorio"   | Busca no HD do usuário        |
| "Limpar"                      | Reseta o histórico            |
| "Me chamo João"               | Aprende e lembra seu nome     |
| Qualquer pergunta             | Responde via Gemma 4 local    |

---

## 🖥️ Requisitos de Hardware

| Modelo        | RAM mínima | Velocidade   | Uso recomendado        |
|--------------|------------|-------------|------------------------|
| gemma4:e2b   | 4 GB       | Muito rápido | PCs antigos, Raspberry |
| gemma4:e4b   | 6 GB       | Rápido       | **Uso geral (padrão)** |
| gemma4:26b   | 20 GB      | Moderado     | Qualidade alta         |
| gemma4:31b   | 32 GB      | Lento em CPU | Com GPU dedicada       |

---

## 📁 Estrutura do Projeto

```
apolo/
├── main.py                  # Ponto de entrada principal
├── setup.py                 # Instalador interativo
├── config.py                # Todas as configurações
├── requirements.txt         # Dependências Python
│
├── core/                    # Núcleo do sistema
│   ├── dispatcher.py        # Roteador central
│   ├── llm_engine.py        # Interface Gemma 4 / Ollama
│   └── context_manager.py   # Histórico de conversa em memória
│
├── voice/                   # Sistema de voz
│   ├── stt.py               # Fala → Texto (Whisper)
│   ├── tts.py               # Texto → Fala (pyttsx3 / Coqui)
│   ├── wake_word.py         # Detecção de "Apolo" (Porcupine)
│   └── audio_capture.py     # Captura com VAD automático
│
├── memory/                  # Sistema de memória
│   ├── vector_store.py      # ChromaDB — busca semântica
│   ├── episodic.py          # Histórico de sessões em JSON
│   ├── user_profile.py      # Perfil persistente do usuário
│   └── embedder.py          # sentence-transformers (singleton)
│
├── agents/                  # Sistema de agentes
│   ├── intent_parser.py     # Classifica intenção por regex
│   ├── planner.py           # Decide e executa ações
│   └── scheduler.py         # APScheduler para lembretes
│
├── commands/                # Execução no sistema
│   ├── system_commands.py   # Abrir apps e buscar arquivos
│   └── web_commands.py      # Navegador e buscas
│
├── tools/                   # Ferramentas externas
│   ├── weather.py           # Clima (Open-Meteo, sem API key)
│   └── calculator.py        # Calculadora e conversões
│
├── utils/                   # Utilitários
│   ├── logger.py            # Logger colorido centralizado
│   └── helpers.py           # Funções auxiliares
│
└── data/                    # Dados persistentes (gitignore)
    ├── chroma/              # Banco vetorial
    ├── history/             # Histórico de conversas
    └── user_profile.json    # Perfil do usuário
```

---

## ⚙️ Configuração (`config.py`)

```python
# Modelo LLM
OLLAMA_MODEL = "gemma4:e4b"   # troque conforme seu hardware

# Voz de saída: "pyttsx3" (rápido) ou "coqui" (mais natural)
TTS_ENGINE   = "pyttsx3"

# Voz de entrada: "whisper" (melhor) — modelo: tiny/base/small/medium
WHISPER_MODEL = "base"

# Wake word (requer conta gratuita em picovoice.ai)
WAKE_WORD_ENABLED = False
PORCUPINE_KEY     = ""

# Modo de raciocínio do Gemma 4 (mais lento, mais preciso)
THINK_MODE = False
```

---

## 🧠 Como a Memória Funciona

```
Usuário fala → Intent Parser → Planner
                                    ↓
                          [Ação direta?] → Sim → Executa (app, clima, etc.)
                                    ↓ Não
                          Busca ChromaDB (top-K semântico)
                                    ↓
                          Injeta no prompt do Gemma 4
                                    ↓
                          Resposta → Salva na memória
                                    ↓
                          TTS fala a resposta
```

---

## 🔧 Solução de Problemas

**"Ollama offline"**
```bash
ollama serve   # em um terminal separado
```

**"Modelo não encontrado"**
```bash
ollama pull gemma4:e4b
```

**Erro no pyaudio (Linux)**
```bash
sudo apt-get install portaudio19-dev python3-pyaudio
pip install pyaudio
```

**Erro no pyaudio (Windows)**
```bash
pip install pipwin
pipwin install pyaudio
```

**TTS sem voz em português**
- Instale vozes TTS: no Windows, vá em Configurações → Hora e idioma → Fala
- No Linux: `sudo apt install espeak-ng`

---

## 🚀 Expansões Futuras

- [ ] Interface gráfica (Tkinter ou web local)
- [ ] Integração com Google Calendar
- [ ] Leitura de e-mails
- [ ] Controle de smart home (Home Assistant)
- [ ] Plugin de programação (executa código Python)
- [ ] Multimodalidade (análise de imagens via Gemma 4 vision)

---

## 📄 Licença

MIT — use, modifique e distribua livremente.
